﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetOpenX.Rest.Client;
using NetOpenX.Rest.Client.Model;
using NetOpenX50;




namespace DocProje
{
    public static class Global
    {
        public static Kernel kernel = new Kernel();
        public static Sirket sirket = default(Sirket);
        public static oAuth2 _oAuth2 = new oAuth2(sirketNetOpenXREST.Default.host);
        public static string token;


        public static void SirketTanım()
        {

            try
            {
                sirket = kernel.yeniSirket(TVTTipi.vtMSSQL,
                                                 sirketNetOpenX.Default.dbName,
                                                 sirketNetOpenX.Default.vtUserName,
                                                 sirketNetOpenX.Default.vtUserPsw,
                                                 sirketNetOpenX.Default.netsisUserName,
                                                 sirketNetOpenX.Default.netsisUserPsw,
                                                 Convert.ToInt32(sirketNetOpenX.Default.branch));
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }


        }

        public static void SirketTanımRest()
        {


            try
            {
                _oAuth2.Login(new JLogin()
                {
                    BranchCode = Convert.ToInt32(sirketNetOpenXREST.Default.branch),
                    NetsisUser = sirketNetOpenXREST.Default.netsisUserName,
                    NetsisPassword = sirketNetOpenXREST.Default.netsisUserPsw,
                    DbType = JNVTTipi.vtMSSQL,
                    DbName = sirketNetOpenXREST.Default.dbName,
                    DbUser = sirketNetOpenXREST.Default.vtUserName,
                    DbPassword = sirketNetOpenXREST.Default.vtUserPsw

                });
                //token = _oAuth2.AccessToken;

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }


        }

    }

}
