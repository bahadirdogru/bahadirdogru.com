﻿namespace DocProje
{
    partial class frmAnaMenu
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.bttnNetOpenX = new System.Windows.Forms.Button();
            this.bttnNetOpenXREST = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // bttnNetOpenX
            // 
            this.bttnNetOpenX.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bttnNetOpenX.Location = new System.Drawing.Point(82, 47);
            this.bttnNetOpenX.Name = "bttnNetOpenX";
            this.bttnNetOpenX.Size = new System.Drawing.Size(157, 51);
            this.bttnNetOpenX.TabIndex = 0;
            this.bttnNetOpenX.Text = "NetOpenX";
            this.bttnNetOpenX.UseVisualStyleBackColor = true;
            this.bttnNetOpenX.Click += new System.EventHandler(this.bttnNetOpenX_Click);
            // 
            // bttnNetOpenXREST
            // 
            this.bttnNetOpenXREST.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bttnNetOpenXREST.Location = new System.Drawing.Point(82, 120);
            this.bttnNetOpenXREST.Name = "bttnNetOpenXREST";
            this.bttnNetOpenXREST.Size = new System.Drawing.Size(157, 51);
            this.bttnNetOpenXREST.TabIndex = 1;
            this.bttnNetOpenXREST.Text = "NetOpenX REST";
            this.bttnNetOpenXREST.UseVisualStyleBackColor = true;
            this.bttnNetOpenXREST.Click += new System.EventHandler(this.bttnNetOpenXREST_Click);
            // 
            // frmAnaMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(320, 212);
            this.Controls.Add(this.bttnNetOpenXREST);
            this.Controls.Add(this.bttnNetOpenX);
            this.Name = "frmAnaMenu";
            this.Text = "Ana Menü";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Button bttnNetOpenX;
        private System.Windows.Forms.Button bttnNetOpenXREST;
    }
}

