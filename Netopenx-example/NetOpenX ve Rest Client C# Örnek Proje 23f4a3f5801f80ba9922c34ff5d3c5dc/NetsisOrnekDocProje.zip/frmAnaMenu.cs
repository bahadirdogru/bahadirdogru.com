﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DocProje
{
    public partial class frmAnaMenu : Form
    {
        private void formGecis (Form frm)
        {
            this.Hide();
            frm.ShowDialog();
            this.Close();
        }
        public frmAnaMenu()
        {
            InitializeComponent();
        }

        private void bttnNetOpenX_Click(object sender, EventArgs e)
        {
            frmNetOpenX formNetOpenX = new frmNetOpenX();
            formGecis(formNetOpenX);
        }

        private void bttnNetOpenXREST_Click(object sender, EventArgs e)
        {
            grpCompantInfos formNetOpenXREST = new grpCompantInfos();
            formGecis(formNetOpenXREST);
        }
    }
}
