﻿namespace DocProje
{
    partial class frmNetOpenX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAnaMenu = new System.Windows.Forms.Button();
            this.checkBxRemember = new System.Windows.Forms.CheckBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lOJİSTİKSATIŞToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fATURAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kAYITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışFaturasıKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışİrsaliyesiKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eİrsaliyesiKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mğşteriSiparişKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışTeklifiKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ambarGirişFişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tevkifatlıFaturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.karmaKoliToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parçalıSiparişToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tahsilatlıFaturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iŞLEMLERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaSİlmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satırBazlıAçıklamaGirişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişRevizyonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBELGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eArşivOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaTaslakOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eArşivGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIrsaliyeGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eArşivGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eİrsaliyeGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retKabulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eİrsaliyeKalemKabulRetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topluEBelgeOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bASIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pdfBasimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaBasimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dizaynNoİleFaturaBasımıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rAPORLARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tALEPTEKLİFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışTalepSiparişleştirmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışTalepTeklifleştirmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokDüzenleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokSİlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokHareketKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reçeteliKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dIŞTİCARETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dİNAMİKDEPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kALİTEKONTROLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kANTARTARTIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mÜSTAHSİLFATURASIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kARGOGÖNDERİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fİNANSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cARİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEKONTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doEkleDekontKayıtSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dekomasKayıtSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muhasebeDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bANKAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHavaleEftVirmanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHesapHareketKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHesapHareketOkuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kASAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariÖdemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekÖdemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.senetÖdemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muhtelifİşlemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaTransferToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHareketKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaKalemleriOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mÜŞTERİÇEKLERİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriÇekiKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bORÇÇEKLERİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borçÇekiKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mŞTEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriSenediKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.borçSenediKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gENELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yARDIMCIPROGRAMLARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kAYITToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kuyruktakiEPostaGönderimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRETİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRETİMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.açıkReçeteAnaliziToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reçeteSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iŞEMRİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işEmriYeniKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işEmriKayıtDüzeltToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işEmriSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mRPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mGPÇalıştırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gereksinimPlanıOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLANLAMAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mAMÜLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mamulRezervasyonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mamulRezervasyonİptalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mAKİNEBAKIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRETİMAKIŞKONTROLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mUHASEBEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mUHASEBEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eNTEGREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mALİYETMUHASEBESİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDIsconnect = new System.Windows.Forms.Button();
            this.grpCompanyInfos = new System.Windows.Forms.GroupBox();
            this.txtSube = new System.Windows.Forms.TextBox();
            this.txtNetsisPassword = new System.Windows.Forms.TextBox();
            this.txtNetsisUserName = new System.Windows.Forms.TextBox();
            this.txtBranch = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDbName = new System.Windows.Forms.TextBox();
            this.txtVTuserName = new System.Windows.Forms.TextBox();
            this.txtVTPassword = new System.Windows.Forms.Label();
            this.txtVTsifre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGiris = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.grpCompanyInfos.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAnaMenu
            // 
            this.btnAnaMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAnaMenu.Location = new System.Drawing.Point(906, 550);
            this.btnAnaMenu.Name = "btnAnaMenu";
            this.btnAnaMenu.Size = new System.Drawing.Size(89, 25);
            this.btnAnaMenu.TabIndex = 1;
            this.btnAnaMenu.Text = "Ana Menü";
            this.btnAnaMenu.UseVisualStyleBackColor = true;
            this.btnAnaMenu.Click += new System.EventHandler(this.btnAnaMenu_Click);
            // 
            // checkBxRemember
            // 
            this.checkBxRemember.AutoSize = true;
            this.checkBxRemember.Location = new System.Drawing.Point(134, 203);
            this.checkBxRemember.Name = "checkBxRemember";
            this.checkBxRemember.Size = new System.Drawing.Size(98, 20);
            this.checkBxRemember.TabIndex = 16;
            this.checkBxRemember.Text = "Beni Hatırla";
            this.checkBxRemember.UseVisualStyleBackColor = true;
            this.checkBxRemember.CheckedChanged += new System.EventHandler(this.checkBxRemember_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lOJİSTİKSATIŞToolStripMenuItem,
            this.fİNANSToolStripMenuItem,
            this.gENELToolStripMenuItem,
            this.üRETİMToolStripMenuItem,
            this.mUHASEBEToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1007, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lOJİSTİKSATIŞToolStripMenuItem
            // 
            this.lOJİSTİKSATIŞToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fATURAToolStripMenuItem,
            this.tALEPTEKLİFToolStripMenuItem,
            this.sTOKToolStripMenuItem,
            this.dIŞTİCARETToolStripMenuItem,
            this.dİNAMİKDEPOToolStripMenuItem,
            this.pOSToolStripMenuItem,
            this.kALİTEKONTROLToolStripMenuItem,
            this.kANTARTARTIMToolStripMenuItem,
            this.mÜSTAHSİLFATURASIToolStripMenuItem,
            this.kARGOGÖNDERİToolStripMenuItem});
            this.lOJİSTİKSATIŞToolStripMenuItem.Name = "lOJİSTİKSATIŞToolStripMenuItem";
            this.lOJİSTİKSATIŞToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.lOJİSTİKSATIŞToolStripMenuItem.Text = "LOJİSTİK - SATIŞ";
            // 
            // fATURAToolStripMenuItem
            // 
            this.fATURAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kAYITToolStripMenuItem,
            this.iŞLEMLERToolStripMenuItem,
            this.eBELGEToolStripMenuItem,
            this.bASIMToolStripMenuItem,
            this.rAPORLARToolStripMenuItem});
            this.fATURAToolStripMenuItem.Name = "fATURAToolStripMenuItem";
            this.fATURAToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.fATURAToolStripMenuItem.Text = "FATURA";
            // 
            // kAYITToolStripMenuItem
            // 
            this.kAYITToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.satışFaturasıKaydıToolStripMenuItem,
            this.satışİrsaliyesiKaydıToolStripMenuItem,
            this.eİrsaliyesiKaydıToolStripMenuItem,
            this.mğşteriSiparişKaydıToolStripMenuItem,
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem,
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem,
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem,
            this.satışTeklifiKaydıToolStripMenuItem,
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem,
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem,
            this.ambarGirişFişiToolStripMenuItem,
            this.tevkifatlıFaturaToolStripMenuItem,
            this.karmaKoliToolStripMenuItem,
            this.parçalıSiparişToolStripMenuItem,
            this.tahsilatlıFaturaToolStripMenuItem});
            this.kAYITToolStripMenuItem.Name = "kAYITToolStripMenuItem";
            this.kAYITToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.kAYITToolStripMenuItem.Text = "KAYIT";
            // 
            // satışFaturasıKaydıToolStripMenuItem
            // 
            this.satışFaturasıKaydıToolStripMenuItem.Name = "satışFaturasıKaydıToolStripMenuItem";
            this.satışFaturasıKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.satışFaturasıKaydıToolStripMenuItem.Text = "Satış Faturası Kaydı";
            this.satışFaturasıKaydıToolStripMenuItem.Click += new System.EventHandler(this.satışFaturasıKaydıToolStripMenuItem_Click);
            // 
            // satışİrsaliyesiKaydıToolStripMenuItem
            // 
            this.satışİrsaliyesiKaydıToolStripMenuItem.Name = "satışİrsaliyesiKaydıToolStripMenuItem";
            this.satışİrsaliyesiKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.satışİrsaliyesiKaydıToolStripMenuItem.Text = "Satış İrsaliyesi Kaydı";
            this.satışİrsaliyesiKaydıToolStripMenuItem.Click += new System.EventHandler(this.satışİrsaliyesiKaydıToolStripMenuItem_Click);
            // 
            // eİrsaliyesiKaydıToolStripMenuItem
            // 
            this.eİrsaliyesiKaydıToolStripMenuItem.Name = "eİrsaliyesiKaydıToolStripMenuItem";
            this.eİrsaliyesiKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.eİrsaliyesiKaydıToolStripMenuItem.Text = "E-İrsaliyesi Kaydı";
            this.eİrsaliyesiKaydıToolStripMenuItem.Click += new System.EventHandler(this.eİrsaliyesiKaydıToolStripMenuItem_Click);
            // 
            // mğşteriSiparişKaydıToolStripMenuItem
            // 
            this.mğşteriSiparişKaydıToolStripMenuItem.Name = "mğşteriSiparişKaydıToolStripMenuItem";
            this.mğşteriSiparişKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.mğşteriSiparişKaydıToolStripMenuItem.Text = "Müşteri Sipariş Kaydı";
            this.mğşteriSiparişKaydıToolStripMenuItem.Click += new System.EventHandler(this.mğşteriSiparişKaydıToolStripMenuItem_Click);
            // 
            // şirketlerArasıFaturaKopyalamaToolStripMenuItem
            // 
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem.Name = "şirketlerArasıFaturaKopyalamaToolStripMenuItem";
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem.Text = "Şirketler Arası Fatura Kopyalama";
            this.şirketlerArasıFaturaKopyalamaToolStripMenuItem.Click += new System.EventHandler(this.şirketlerArasıFaturaKopyalamaToolStripMenuItem_Click);
            // 
            // lokalDepolarArasıTransferKAydıToolStripMenuItem
            // 
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem.Name = "lokalDepolarArasıTransferKAydıToolStripMenuItem";
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem.Text = "Lokal Depolar Arası Transfer KAydı ";
            this.lokalDepolarArasıTransferKAydıToolStripMenuItem.Click += new System.EventHandler(this.lokalDepolarArasıTransferKAydıToolStripMenuItem_Click);
            // 
            // şubelerArasıDepoTransferKaydıToolStripMenuItem
            // 
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem.Name = "şubelerArasıDepoTransferKaydıToolStripMenuItem";
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem.Text = "Şubeler Arası Depo Transfer Kaydı";
            this.şubelerArasıDepoTransferKaydıToolStripMenuItem.Click += new System.EventHandler(this.şubelerArasıDepoTransferKaydıToolStripMenuItem_Click);
            // 
            // satışTeklifiKaydıToolStripMenuItem
            // 
            this.satışTeklifiKaydıToolStripMenuItem.Name = "satışTeklifiKaydıToolStripMenuItem";
            this.satışTeklifiKaydıToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.satışTeklifiKaydıToolStripMenuItem.Text = "Satış Teklifi Kaydı";
            this.satışTeklifiKaydıToolStripMenuItem.Click += new System.EventHandler(this.satışTeklifiKaydıToolStripMenuItem_Click);
            // 
            // sipariştenİrsaliyeOluşturmaToolStripMenuItem
            // 
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem.Name = "sipariştenİrsaliyeOluşturmaToolStripMenuItem";
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem.Text = "Siparişten İrsaliye Oluşturma";
            this.sipariştenİrsaliyeOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.sipariştenİrsaliyeOluşturmaToolStripMenuItem_Click);
            // 
            // irsaliyedenFaturaOluşturmaToolStripMenuItem
            // 
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem.Name = "irsaliyedenFaturaOluşturmaToolStripMenuItem";
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem.Text = "İrsaliyeden Fatura Oluşturma";
            this.irsaliyedenFaturaOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.irsaliyedenFaturaOluşturmaToolStripMenuItem_Click);
            // 
            // ambarGirişFişiToolStripMenuItem
            // 
            this.ambarGirişFişiToolStripMenuItem.Name = "ambarGirişFişiToolStripMenuItem";
            this.ambarGirişFişiToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.ambarGirişFişiToolStripMenuItem.Text = "Ambar Giriş Fişi";
            this.ambarGirişFişiToolStripMenuItem.Click += new System.EventHandler(this.ambarGirişFişiToolStripMenuItem_Click);
            // 
            // tevkifatlıFaturaToolStripMenuItem
            // 
            this.tevkifatlıFaturaToolStripMenuItem.Name = "tevkifatlıFaturaToolStripMenuItem";
            this.tevkifatlıFaturaToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.tevkifatlıFaturaToolStripMenuItem.Text = "Tevkifatlı Fatura";
            this.tevkifatlıFaturaToolStripMenuItem.Click += new System.EventHandler(this.tevkifatlıFaturaToolStripMenuItem_Click);
            // 
            // karmaKoliToolStripMenuItem
            // 
            this.karmaKoliToolStripMenuItem.Name = "karmaKoliToolStripMenuItem";
            this.karmaKoliToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.karmaKoliToolStripMenuItem.Text = "Karma Koli";
            this.karmaKoliToolStripMenuItem.Click += new System.EventHandler(this.karmaKoliToolStripMenuItem_Click);
            // 
            // parçalıSiparişToolStripMenuItem
            // 
            this.parçalıSiparişToolStripMenuItem.Name = "parçalıSiparişToolStripMenuItem";
            this.parçalıSiparişToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.parçalıSiparişToolStripMenuItem.Text = "Parçalı Sipariş";
            this.parçalıSiparişToolStripMenuItem.Click += new System.EventHandler(this.parçalıSiparişToolStripMenuItem_Click);
            // 
            // tahsilatlıFaturaToolStripMenuItem
            // 
            this.tahsilatlıFaturaToolStripMenuItem.Name = "tahsilatlıFaturaToolStripMenuItem";
            this.tahsilatlıFaturaToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.tahsilatlıFaturaToolStripMenuItem.Text = "Tahsilatlı Fatura";
            this.tahsilatlıFaturaToolStripMenuItem.Click += new System.EventHandler(this.tahsilatlıFaturaToolStripMenuItem_Click);
            // 
            // iŞLEMLERToolStripMenuItem
            // 
            this.iŞLEMLERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faturaOkumaToolStripMenuItem,
            this.faturaSİlmeToolStripMenuItem,
            this.satırBazlıAçıklamaGirişiToolStripMenuItem,
            this.siparişRevizyonToolStripMenuItem,
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem});
            this.iŞLEMLERToolStripMenuItem.Name = "iŞLEMLERToolStripMenuItem";
            this.iŞLEMLERToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.iŞLEMLERToolStripMenuItem.Text = "İŞLEMLER";
            // 
            // faturaOkumaToolStripMenuItem
            // 
            this.faturaOkumaToolStripMenuItem.Name = "faturaOkumaToolStripMenuItem";
            this.faturaOkumaToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.faturaOkumaToolStripMenuItem.Text = "Fatura Okuma";
            this.faturaOkumaToolStripMenuItem.Click += new System.EventHandler(this.faturaOkumaToolStripMenuItem_Click);
            // 
            // faturaSİlmeToolStripMenuItem
            // 
            this.faturaSİlmeToolStripMenuItem.Name = "faturaSİlmeToolStripMenuItem";
            this.faturaSİlmeToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.faturaSİlmeToolStripMenuItem.Text = "Fatura Sİlme";
            this.faturaSİlmeToolStripMenuItem.Click += new System.EventHandler(this.faturaSİlmeToolStripMenuItem_Click);
            // 
            // satırBazlıAçıklamaGirişiToolStripMenuItem
            // 
            this.satırBazlıAçıklamaGirişiToolStripMenuItem.Name = "satırBazlıAçıklamaGirişiToolStripMenuItem";
            this.satırBazlıAçıklamaGirişiToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.satırBazlıAçıklamaGirişiToolStripMenuItem.Text = "Satır Bazlı Açıklama Girişi";
            this.satırBazlıAçıklamaGirişiToolStripMenuItem.Click += new System.EventHandler(this.satırBazlıAçıklamaGirişiToolStripMenuItem_Click);
            // 
            // siparişRevizyonToolStripMenuItem
            // 
            this.siparişRevizyonToolStripMenuItem.Name = "siparişRevizyonToolStripMenuItem";
            this.siparişRevizyonToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.siparişRevizyonToolStripMenuItem.Text = "Sipariş Revizyon";
            this.siparişRevizyonToolStripMenuItem.Click += new System.EventHandler(this.siparişRevizyonToolStripMenuItem_Click);
            // 
            // irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem
            // 
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem.Name = "irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem";
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem.Text = "İrsaliyelerin Toplu Faturalaştırılması";
            this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem.Click += new System.EventHandler(this.irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem_Click);
            // 
            // eBELGEToolStripMenuItem
            // 
            this.eBELGEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eArşivOluşturmaToolStripMenuItem,
            this.eFaturaTaslakOluşturmaToolStripMenuItem,
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem,
            this.eFaturaGörüntülemeToolStripMenuItem,
            this.eArşivGörüntülemeToolStripMenuItem,
            this.eIrsaliyeGörüntülemeToolStripMenuItem,
            this.eFaturaGöndermeToolStripMenuItem,
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem,
            this.eArşivGöndermeToolStripMenuItem,
            this.eİrsaliyeGöndermeToolStripMenuItem,
            this.retKabulToolStripMenuItem,
            this.eİrsaliyeKalemKabulRetToolStripMenuItem,
            this.topluEBelgeOluşturmaToolStripMenuItem});
            this.eBELGEToolStripMenuItem.Name = "eBELGEToolStripMenuItem";
            this.eBELGEToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.eBELGEToolStripMenuItem.Text = "E-BELGE";
            // 
            // eArşivOluşturmaToolStripMenuItem
            // 
            this.eArşivOluşturmaToolStripMenuItem.Name = "eArşivOluşturmaToolStripMenuItem";
            this.eArşivOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eArşivOluşturmaToolStripMenuItem.Text = "E-Arşiv Oluşturma";
            this.eArşivOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.eArşivOluşturmaToolStripMenuItem_Click);
            // 
            // eFaturaTaslakOluşturmaToolStripMenuItem
            // 
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Name = "eFaturaTaslakOluşturmaToolStripMenuItem";
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Text = "E-Fatura Taslak Oluşturma";
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.eFaturaTaslakOluşturmaToolStripMenuItem_Click);
            // 
            // eİrsaliyeTaslakOluşturmaToolStripMenuItem
            // 
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem.Name = "eİrsaliyeTaslakOluşturmaToolStripMenuItem";
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem.Text = "E-İrsaliye Taslak Oluşturma";
            this.eİrsaliyeTaslakOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.eİrsaliyeTaslakOluşturmaToolStripMenuItem_Click);
            // 
            // eFaturaGörüntülemeToolStripMenuItem
            // 
            this.eFaturaGörüntülemeToolStripMenuItem.Name = "eFaturaGörüntülemeToolStripMenuItem";
            this.eFaturaGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eFaturaGörüntülemeToolStripMenuItem.Text = "E-Fatura Görüntüleme";
            this.eFaturaGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.eFaturaGörüntülemeToolStripMenuItem_Click);
            // 
            // eArşivGörüntülemeToolStripMenuItem
            // 
            this.eArşivGörüntülemeToolStripMenuItem.Name = "eArşivGörüntülemeToolStripMenuItem";
            this.eArşivGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eArşivGörüntülemeToolStripMenuItem.Text = "E-Arşiv Görüntüleme";
            this.eArşivGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.eArşivGörüntülemeToolStripMenuItem_Click);
            // 
            // eIrsaliyeGörüntülemeToolStripMenuItem
            // 
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Name = "eIrsaliyeGörüntülemeToolStripMenuItem";
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Text = "E-Irsaliye Görüntüleme";
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.eIrsaliyeGörüntülemeToolStripMenuItem_Click);
            // 
            // eFaturaGöndermeToolStripMenuItem
            // 
            this.eFaturaGöndermeToolStripMenuItem.Name = "eFaturaGöndermeToolStripMenuItem";
            this.eFaturaGöndermeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eFaturaGöndermeToolStripMenuItem.Text = "E-Fatura Gönderme";
            this.eFaturaGöndermeToolStripMenuItem.Click += new System.EventHandler(this.eFaturaGöndermeToolStripMenuItem_Click);
            // 
            // ihracatKayıtlıEFaturaGöndermeToolStripMenuItem
            // 
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem.Name = "ihracatKayıtlıEFaturaGöndermeToolStripMenuItem";
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem.Text = "İhracat kayıtlı E-Fatura Gönderme";
            this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem.Click += new System.EventHandler(this.ihracatKayıtlıEFaturaGöndermeToolStripMenuItem_Click);
            // 
            // eArşivGöndermeToolStripMenuItem
            // 
            this.eArşivGöndermeToolStripMenuItem.Name = "eArşivGöndermeToolStripMenuItem";
            this.eArşivGöndermeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eArşivGöndermeToolStripMenuItem.Text = "E-Arşiv Gönderme";
            this.eArşivGöndermeToolStripMenuItem.Click += new System.EventHandler(this.eArşivGöndermeToolStripMenuItem_Click);
            // 
            // eİrsaliyeGöndermeToolStripMenuItem
            // 
            this.eİrsaliyeGöndermeToolStripMenuItem.Name = "eİrsaliyeGöndermeToolStripMenuItem";
            this.eİrsaliyeGöndermeToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eİrsaliyeGöndermeToolStripMenuItem.Text = "E-İrsaliye Gönderme";
            this.eİrsaliyeGöndermeToolStripMenuItem.Click += new System.EventHandler(this.eİrsaliyeGöndermeToolStripMenuItem_Click);
            // 
            // retKabulToolStripMenuItem
            // 
            this.retKabulToolStripMenuItem.Name = "retKabulToolStripMenuItem";
            this.retKabulToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.retKabulToolStripMenuItem.Text = "Ret-Kabul";
            this.retKabulToolStripMenuItem.Click += new System.EventHandler(this.retKabulToolStripMenuItem_Click);
            // 
            // eİrsaliyeKalemKabulRetToolStripMenuItem
            // 
            this.eİrsaliyeKalemKabulRetToolStripMenuItem.Name = "eİrsaliyeKalemKabulRetToolStripMenuItem";
            this.eİrsaliyeKalemKabulRetToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.eİrsaliyeKalemKabulRetToolStripMenuItem.Text = "E-İrsaliye Kalem Kabul-Ret";
            this.eİrsaliyeKalemKabulRetToolStripMenuItem.Click += new System.EventHandler(this.eİrsaliyeKalemKabulRetToolStripMenuItem_Click);
            // 
            // topluEBelgeOluşturmaToolStripMenuItem
            // 
            this.topluEBelgeOluşturmaToolStripMenuItem.Name = "topluEBelgeOluşturmaToolStripMenuItem";
            this.topluEBelgeOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.topluEBelgeOluşturmaToolStripMenuItem.Text = "Toplu E-Belge Oluşturma";
            this.topluEBelgeOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.topluEBelgeOluşturmaToolStripMenuItem_Click);
            // 
            // bASIMToolStripMenuItem
            // 
            this.bASIMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pdfBasimToolStripMenuItem,
            this.kasaBasimToolStripMenuItem,
            this.dizaynNoİleFaturaBasımıToolStripMenuItem,
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem,
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem,
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem});
            this.bASIMToolStripMenuItem.Name = "bASIMToolStripMenuItem";
            this.bASIMToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.bASIMToolStripMenuItem.Text = "BASIM";
            // 
            // pdfBasimToolStripMenuItem
            // 
            this.pdfBasimToolStripMenuItem.Name = "pdfBasimToolStripMenuItem";
            this.pdfBasimToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.pdfBasimToolStripMenuItem.Text = "Pdf Basim";
            this.pdfBasimToolStripMenuItem.Click += new System.EventHandler(this.pdfBasimToolStripMenuItem_Click);
            // 
            // kasaBasimToolStripMenuItem
            // 
            this.kasaBasimToolStripMenuItem.Name = "kasaBasimToolStripMenuItem";
            this.kasaBasimToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.kasaBasimToolStripMenuItem.Text = "Kasa basim";
            this.kasaBasimToolStripMenuItem.Click += new System.EventHandler(this.kasaBasimToolStripMenuItem_Click);
            // 
            // dizaynNoİleFaturaBasımıToolStripMenuItem
            // 
            this.dizaynNoİleFaturaBasımıToolStripMenuItem.Name = "dizaynNoİleFaturaBasımıToolStripMenuItem";
            this.dizaynNoİleFaturaBasımıToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.dizaynNoİleFaturaBasımıToolStripMenuItem.Text = "Dizayn No ile Fatura Basımı";
            this.dizaynNoİleFaturaBasımıToolStripMenuItem.Click += new System.EventHandler(this.dizaynNoİleFaturaBasımıToolStripMenuItem_Click);
            // 
            // irsaliyeFaturaKalemBarkodBasımToolStripMenuItem
            // 
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem.Name = "irsaliyeFaturaKalemBarkodBasımToolStripMenuItem";
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem.Text = "İrsaliye / Fatura Kalem Barkod Basım";
            this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem.Click += new System.EventHandler(this.irsaliyeFaturaKalemBarkodBasımToolStripMenuItem_Click);
            // 
            // modülDizaynıİleFaturaBasımıToolStripMenuItem
            // 
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem.Name = "modülDizaynıİleFaturaBasımıToolStripMenuItem";
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem.Text = "Modül Dizaynı ile Fatura Basımı";
            this.modülDizaynıİleFaturaBasımıToolStripMenuItem.Click += new System.EventHandler(this.modülDizaynıİleFaturaBasımıToolStripMenuItem_Click);
            // 
            // dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem
            // 
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem.Name = "dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem";
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem.Size = new System.Drawing.Size(333, 26);
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem.Text = "Dizayn No ile Yevmiye Fişi Basımı";
            this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem.Click += new System.EventHandler(this.dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem_Click);
            // 
            // rAPORLARToolStripMenuItem
            // 
            this.rAPORLARToolStripMenuItem.Name = "rAPORLARToolStripMenuItem";
            this.rAPORLARToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.rAPORLARToolStripMenuItem.Text = "RAPORLAR";
            // 
            // tALEPTEKLİFToolStripMenuItem
            // 
            this.tALEPTEKLİFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem,
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem,
            this.satışTalepSiparişleştirmeToolStripMenuItem,
            this.satışTalepTeklifleştirmeToolStripMenuItem});
            this.tALEPTEKLİFToolStripMenuItem.Name = "tALEPTEKLİFToolStripMenuItem";
            this.tALEPTEKLİFToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.tALEPTEKLİFToolStripMenuItem.Text = "TALEP - TEKLİF";
            // 
            // satınAlmaTalepTeklifleştirmeToolStripMenuItem
            // 
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem.Name = "satınAlmaTalepTeklifleştirmeToolStripMenuItem";
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem.Text = "Satın Alma Talep Teklifleştirme";
            this.satınAlmaTalepTeklifleştirmeToolStripMenuItem.Click += new System.EventHandler(this.satınAlmaTalepTeklifleştirmeToolStripMenuItem_Click);
            // 
            // satınAlmaTalepSiparişleştirmeToolStripMenuItem
            // 
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem.Name = "satınAlmaTalepSiparişleştirmeToolStripMenuItem";
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem.Text = "Satın Alma Talep Siparişleştirme";
            this.satınAlmaTalepSiparişleştirmeToolStripMenuItem.Click += new System.EventHandler(this.satınAlmaTalepSiparişleştirmeToolStripMenuItem_Click);
            // 
            // satışTalepSiparişleştirmeToolStripMenuItem
            // 
            this.satışTalepSiparişleştirmeToolStripMenuItem.Name = "satışTalepSiparişleştirmeToolStripMenuItem";
            this.satışTalepSiparişleştirmeToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.satışTalepSiparişleştirmeToolStripMenuItem.Text = "Satış Talep Siparişleştirme";
            this.satışTalepSiparişleştirmeToolStripMenuItem.Click += new System.EventHandler(this.satışTalepSiparişleştirmeToolStripMenuItem_Click);
            // 
            // satışTalepTeklifleştirmeToolStripMenuItem
            // 
            this.satışTalepTeklifleştirmeToolStripMenuItem.Name = "satışTalepTeklifleştirmeToolStripMenuItem";
            this.satışTalepTeklifleştirmeToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.satışTalepTeklifleştirmeToolStripMenuItem.Text = "Satış Talep Teklifleştirme";
            this.satışTalepTeklifleştirmeToolStripMenuItem.Click += new System.EventHandler(this.satışTalepTeklifleştirmeToolStripMenuItem_Click);
            // 
            // sTOKToolStripMenuItem
            // 
            this.sTOKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokKaydıToolStripMenuItem,
            this.stokDüzenleToolStripMenuItem,
            this.stokSİlToolStripMenuItem,
            this.stokHareketKaydıToolStripMenuItem,
            this.reçeteliKayıtToolStripMenuItem});
            this.sTOKToolStripMenuItem.Name = "sTOKToolStripMenuItem";
            this.sTOKToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.sTOKToolStripMenuItem.Text = "STOK";
            // 
            // stokKaydıToolStripMenuItem
            // 
            this.stokKaydıToolStripMenuItem.Name = "stokKaydıToolStripMenuItem";
            this.stokKaydıToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokKaydıToolStripMenuItem.Text = "Stok Kaydı";
            this.stokKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokKaydıToolStripMenuItem_Click);
            // 
            // stokDüzenleToolStripMenuItem
            // 
            this.stokDüzenleToolStripMenuItem.Name = "stokDüzenleToolStripMenuItem";
            this.stokDüzenleToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokDüzenleToolStripMenuItem.Text = "Stok Düzenle";
            this.stokDüzenleToolStripMenuItem.Click += new System.EventHandler(this.stokDüzenleToolStripMenuItem_Click);
            // 
            // stokSİlToolStripMenuItem
            // 
            this.stokSİlToolStripMenuItem.Name = "stokSİlToolStripMenuItem";
            this.stokSİlToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokSİlToolStripMenuItem.Text = "Stok Sil";
            this.stokSİlToolStripMenuItem.Click += new System.EventHandler(this.stokSİlToolStripMenuItem_Click);
            // 
            // stokHareketKaydıToolStripMenuItem
            // 
            this.stokHareketKaydıToolStripMenuItem.Name = "stokHareketKaydıToolStripMenuItem";
            this.stokHareketKaydıToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokHareketKaydıToolStripMenuItem.Text = "Stok Hareket Kaydı";
            this.stokHareketKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokHareketKaydıToolStripMenuItem_Click);
            // 
            // reçeteliKayıtToolStripMenuItem
            // 
            this.reçeteliKayıtToolStripMenuItem.Name = "reçeteliKayıtToolStripMenuItem";
            this.reçeteliKayıtToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.reçeteliKayıtToolStripMenuItem.Text = "Reçeteli Kayıt";
            this.reçeteliKayıtToolStripMenuItem.Click += new System.EventHandler(this.reçeteliKayıtToolStripMenuItem_Click);
            // 
            // dIŞTİCARETToolStripMenuItem
            // 
            this.dIŞTİCARETToolStripMenuItem.Name = "dIŞTİCARETToolStripMenuItem";
            this.dIŞTİCARETToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.dIŞTİCARETToolStripMenuItem.Text = "DIŞ TİCARET";
            // 
            // dİNAMİKDEPOToolStripMenuItem
            // 
            this.dİNAMİKDEPOToolStripMenuItem.Name = "dİNAMİKDEPOToolStripMenuItem";
            this.dİNAMİKDEPOToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.dİNAMİKDEPOToolStripMenuItem.Text = "DİNAMİK DEPO";
            // 
            // pOSToolStripMenuItem
            // 
            this.pOSToolStripMenuItem.Name = "pOSToolStripMenuItem";
            this.pOSToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.pOSToolStripMenuItem.Text = "P.O.S";
            // 
            // kALİTEKONTROLToolStripMenuItem
            // 
            this.kALİTEKONTROLToolStripMenuItem.Name = "kALİTEKONTROLToolStripMenuItem";
            this.kALİTEKONTROLToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.kALİTEKONTROLToolStripMenuItem.Text = "KALİTE KONTROL";
            // 
            // kANTARTARTIMToolStripMenuItem
            // 
            this.kANTARTARTIMToolStripMenuItem.Name = "kANTARTARTIMToolStripMenuItem";
            this.kANTARTARTIMToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.kANTARTARTIMToolStripMenuItem.Text = "KANTAR - TARTIM";
            // 
            // mÜSTAHSİLFATURASIToolStripMenuItem
            // 
            this.mÜSTAHSİLFATURASIToolStripMenuItem.Name = "mÜSTAHSİLFATURASIToolStripMenuItem";
            this.mÜSTAHSİLFATURASIToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.mÜSTAHSİLFATURASIToolStripMenuItem.Text = "MÜSTAHSİL FATURASI";
            // 
            // kARGOGÖNDERİToolStripMenuItem
            // 
            this.kARGOGÖNDERİToolStripMenuItem.Name = "kARGOGÖNDERİToolStripMenuItem";
            this.kARGOGÖNDERİToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.kARGOGÖNDERİToolStripMenuItem.Text = "KARGO GÖNDERİ";
            // 
            // fİNANSToolStripMenuItem
            // 
            this.fİNANSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cARİToolStripMenuItem,
            this.dEKONTToolStripMenuItem,
            this.bANKAToolStripMenuItem,
            this.kASAToolStripMenuItem,
            this.mÜŞTERİÇEKLERİToolStripMenuItem,
            this.bORÇÇEKLERİToolStripMenuItem,
            this.mŞTEToolStripMenuItem,
            this.toolStripMenuItem1});
            this.fİNANSToolStripMenuItem.Name = "fİNANSToolStripMenuItem";
            this.fİNANSToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.fİNANSToolStripMenuItem.Text = "FİNANS";
            // 
            // cARİToolStripMenuItem
            // 
            this.cARİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariKayıtToolStripMenuItem,
            this.cariOkumaToolStripMenuItem,
            this.cariSilmeToolStripMenuItem});
            this.cARİToolStripMenuItem.Name = "cARİToolStripMenuItem";
            this.cARİToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.cARİToolStripMenuItem.Text = "CARİ";
            // 
            // cariKayıtToolStripMenuItem
            // 
            this.cariKayıtToolStripMenuItem.Name = "cariKayıtToolStripMenuItem";
            this.cariKayıtToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.cariKayıtToolStripMenuItem.Text = "Cari Kayıt";
            this.cariKayıtToolStripMenuItem.Click += new System.EventHandler(this.cariKayıtToolStripMenuItem_Click);
            // 
            // cariOkumaToolStripMenuItem
            // 
            this.cariOkumaToolStripMenuItem.Name = "cariOkumaToolStripMenuItem";
            this.cariOkumaToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.cariOkumaToolStripMenuItem.Text = "Cari Okuma";
            this.cariOkumaToolStripMenuItem.Click += new System.EventHandler(this.cariOkumaToolStripMenuItem_Click);
            // 
            // cariSilmeToolStripMenuItem
            // 
            this.cariSilmeToolStripMenuItem.Name = "cariSilmeToolStripMenuItem";
            this.cariSilmeToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.cariSilmeToolStripMenuItem.Text = "Cari Silme";
            this.cariSilmeToolStripMenuItem.Click += new System.EventHandler(this.cariSilmeToolStripMenuItem_Click);
            // 
            // dEKONTToolStripMenuItem
            // 
            this.dEKONTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.doEkleDekontKayıtSilmeToolStripMenuItem,
            this.dekomasKayıtSilmeToolStripMenuItem,
            this.cariDekontKaydıToolStripMenuItem,
            this.stokDekontKaydıToolStripMenuItem,
            this.muhasebeDekontKaydıToolStripMenuItem,
            this.bankaDekontKaydıToolStripMenuItem});
            this.dEKONTToolStripMenuItem.Name = "dEKONTToolStripMenuItem";
            this.dEKONTToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.dEKONTToolStripMenuItem.Text = "DEKONT";
            // 
            // doEkleDekontKayıtSilmeToolStripMenuItem
            // 
            this.doEkleDekontKayıtSilmeToolStripMenuItem.Name = "doEkleDekontKayıtSilmeToolStripMenuItem";
            this.doEkleDekontKayıtSilmeToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.doEkleDekontKayıtSilmeToolStripMenuItem.Text = "DoEkle Dekont Kayıt Silme";
            this.doEkleDekontKayıtSilmeToolStripMenuItem.Click += new System.EventHandler(this.doEkleDekontKayıtSilmeToolStripMenuItem_Click);
            // 
            // dekomasKayıtSilmeToolStripMenuItem
            // 
            this.dekomasKayıtSilmeToolStripMenuItem.Name = "dekomasKayıtSilmeToolStripMenuItem";
            this.dekomasKayıtSilmeToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.dekomasKayıtSilmeToolStripMenuItem.Text = "Dekomas Kayıt Silme";
            this.dekomasKayıtSilmeToolStripMenuItem.Click += new System.EventHandler(this.dekomasKayıtSilmeToolStripMenuItem_Click);
            // 
            // cariDekontKaydıToolStripMenuItem
            // 
            this.cariDekontKaydıToolStripMenuItem.Name = "cariDekontKaydıToolStripMenuItem";
            this.cariDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.cariDekontKaydıToolStripMenuItem.Text = "Cari Dekont Kaydı";
            this.cariDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.cariDekontKaydıToolStripMenuItem_Click);
            // 
            // stokDekontKaydıToolStripMenuItem
            // 
            this.stokDekontKaydıToolStripMenuItem.Name = "stokDekontKaydıToolStripMenuItem";
            this.stokDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.stokDekontKaydıToolStripMenuItem.Text = "Stok Dekont Kaydı";
            this.stokDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokDekontKaydıToolStripMenuItem_Click);
            // 
            // muhasebeDekontKaydıToolStripMenuItem
            // 
            this.muhasebeDekontKaydıToolStripMenuItem.Name = "muhasebeDekontKaydıToolStripMenuItem";
            this.muhasebeDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.muhasebeDekontKaydıToolStripMenuItem.Text = "Muhasebe Dekont Kaydı";
            this.muhasebeDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.muhasebeDekontKaydıToolStripMenuItem_Click);
            // 
            // bankaDekontKaydıToolStripMenuItem
            // 
            this.bankaDekontKaydıToolStripMenuItem.Name = "bankaDekontKaydıToolStripMenuItem";
            this.bankaDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.bankaDekontKaydıToolStripMenuItem.Text = "Banka Dekont Kaydı";
            this.bankaDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.bankaDekontKaydıToolStripMenuItem_Click);
            // 
            // bANKAToolStripMenuItem
            // 
            this.bANKAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankaHavaleEftVirmanToolStripMenuItem,
            this.bankaHesapHareketKayıtToolStripMenuItem,
            this.bankaHesapHareketOkuToolStripMenuItem});
            this.bANKAToolStripMenuItem.Name = "bANKAToolStripMenuItem";
            this.bANKAToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.bANKAToolStripMenuItem.Text = "BANKA";
            // 
            // bankaHavaleEftVirmanToolStripMenuItem
            // 
            this.bankaHavaleEftVirmanToolStripMenuItem.Name = "bankaHavaleEftVirmanToolStripMenuItem";
            this.bankaHavaleEftVirmanToolStripMenuItem.Size = new System.Drawing.Size(271, 26);
            this.bankaHavaleEftVirmanToolStripMenuItem.Text = "Banka Havale/Eft - Virman";
            this.bankaHavaleEftVirmanToolStripMenuItem.Click += new System.EventHandler(this.bankaHavaleEftVirmanToolStripMenuItem_Click);
            // 
            // bankaHesapHareketKayıtToolStripMenuItem
            // 
            this.bankaHesapHareketKayıtToolStripMenuItem.Name = "bankaHesapHareketKayıtToolStripMenuItem";
            this.bankaHesapHareketKayıtToolStripMenuItem.Size = new System.Drawing.Size(271, 26);
            this.bankaHesapHareketKayıtToolStripMenuItem.Text = "Banka Hesap Hareket Kayıt";
            this.bankaHesapHareketKayıtToolStripMenuItem.Click += new System.EventHandler(this.bankaHesapHareketKayıtToolStripMenuItem_Click);
            // 
            // bankaHesapHareketOkuToolStripMenuItem
            // 
            this.bankaHesapHareketOkuToolStripMenuItem.Name = "bankaHesapHareketOkuToolStripMenuItem";
            this.bankaHesapHareketOkuToolStripMenuItem.Size = new System.Drawing.Size(271, 26);
            this.bankaHesapHareketOkuToolStripMenuItem.Text = "Banka Hesap Hareket Oku";
            this.bankaHesapHareketOkuToolStripMenuItem.Click += new System.EventHandler(this.bankaHesapHareketOkuToolStripMenuItem_Click);
            // 
            // kASAToolStripMenuItem
            // 
            this.kASAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariÖdemeToolStripMenuItem,
            this.faturaKaydıToolStripMenuItem,
            this.çekÖdemeToolStripMenuItem,
            this.senetÖdemeToolStripMenuItem,
            this.muhtelifİşlemToolStripMenuItem,
            this.kasaTransferToolStripMenuItem,
            this.bankaHareketKaydıToolStripMenuItem,
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem,
            this.kasaKalemleriOkumaToolStripMenuItem});
            this.kASAToolStripMenuItem.Name = "kASAToolStripMenuItem";
            this.kASAToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.kASAToolStripMenuItem.Text = "KASA";
            // 
            // cariÖdemeToolStripMenuItem
            // 
            this.cariÖdemeToolStripMenuItem.Name = "cariÖdemeToolStripMenuItem";
            this.cariÖdemeToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.cariÖdemeToolStripMenuItem.Text = "Cari Ödeme";
            this.cariÖdemeToolStripMenuItem.Click += new System.EventHandler(this.cariÖdemeToolStripMenuItem_Click);
            // 
            // faturaKaydıToolStripMenuItem
            // 
            this.faturaKaydıToolStripMenuItem.Name = "faturaKaydıToolStripMenuItem";
            this.faturaKaydıToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.faturaKaydıToolStripMenuItem.Text = "Fatura Kaydı";
            this.faturaKaydıToolStripMenuItem.Click += new System.EventHandler(this.faturaKaydıToolStripMenuItem_Click);
            // 
            // çekÖdemeToolStripMenuItem
            // 
            this.çekÖdemeToolStripMenuItem.Name = "çekÖdemeToolStripMenuItem";
            this.çekÖdemeToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.çekÖdemeToolStripMenuItem.Text = "Çek Ödeme";
            this.çekÖdemeToolStripMenuItem.Click += new System.EventHandler(this.çekÖdemeToolStripMenuItem_Click);
            // 
            // senetÖdemeToolStripMenuItem
            // 
            this.senetÖdemeToolStripMenuItem.Name = "senetÖdemeToolStripMenuItem";
            this.senetÖdemeToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.senetÖdemeToolStripMenuItem.Text = "Senet Ödeme";
            this.senetÖdemeToolStripMenuItem.Click += new System.EventHandler(this.senetÖdemeToolStripMenuItem_Click);
            // 
            // muhtelifİşlemToolStripMenuItem
            // 
            this.muhtelifİşlemToolStripMenuItem.Name = "muhtelifİşlemToolStripMenuItem";
            this.muhtelifİşlemToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.muhtelifİşlemToolStripMenuItem.Text = "Muhtelif İşlem";
            this.muhtelifİşlemToolStripMenuItem.Click += new System.EventHandler(this.muhtelifİşlemToolStripMenuItem_Click);
            // 
            // kasaTransferToolStripMenuItem
            // 
            this.kasaTransferToolStripMenuItem.Name = "kasaTransferToolStripMenuItem";
            this.kasaTransferToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.kasaTransferToolStripMenuItem.Text = "Kasa Transfer";
            this.kasaTransferToolStripMenuItem.Click += new System.EventHandler(this.kasaTransferToolStripMenuItem_Click);
            // 
            // bankaHareketKaydıToolStripMenuItem
            // 
            this.bankaHareketKaydıToolStripMenuItem.Name = "bankaHareketKaydıToolStripMenuItem";
            this.bankaHareketKaydıToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.bankaHareketKaydıToolStripMenuItem.Text = "Banka Hareket Kaydı";
            this.bankaHareketKaydıToolStripMenuItem.Click += new System.EventHandler(this.bankaHareketKaydıToolStripMenuItem_Click);
            // 
            // faturaKaydındaÇokluKalemGirişiToolStripMenuItem
            // 
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem.Name = "faturaKaydındaÇokluKalemGirişiToolStripMenuItem";
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem.Text = "Fatura Kaydında Çoklu Kalem Girişi";
            this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem.Click += new System.EventHandler(this.faturaKaydındaÇokluKalemGirişiToolStripMenuItem_Click);
            // 
            // kasaKalemleriOkumaToolStripMenuItem
            // 
            this.kasaKalemleriOkumaToolStripMenuItem.Name = "kasaKalemleriOkumaToolStripMenuItem";
            this.kasaKalemleriOkumaToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.kasaKalemleriOkumaToolStripMenuItem.Text = "Kasa Kalemleri Okuma";
            this.kasaKalemleriOkumaToolStripMenuItem.Click += new System.EventHandler(this.kasaKalemleriOkumaToolStripMenuItem_Click);
            // 
            // mÜŞTERİÇEKLERİToolStripMenuItem
            // 
            this.mÜŞTERİÇEKLERİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.müşteriÇekiKaydıToolStripMenuItem});
            this.mÜŞTERİÇEKLERİToolStripMenuItem.Name = "mÜŞTERİÇEKLERİToolStripMenuItem";
            this.mÜŞTERİÇEKLERİToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.mÜŞTERİÇEKLERİToolStripMenuItem.Text = "MÜŞTERİ ÇEKLERİ";
            // 
            // müşteriÇekiKaydıToolStripMenuItem
            // 
            this.müşteriÇekiKaydıToolStripMenuItem.Name = "müşteriÇekiKaydıToolStripMenuItem";
            this.müşteriÇekiKaydıToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.müşteriÇekiKaydıToolStripMenuItem.Text = "Müşteri Çeki Kaydı";
            this.müşteriÇekiKaydıToolStripMenuItem.Click += new System.EventHandler(this.müşteriÇekiKaydıToolStripMenuItem_Click);
            // 
            // bORÇÇEKLERİToolStripMenuItem
            // 
            this.bORÇÇEKLERİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borçÇekiKaydıToolStripMenuItem});
            this.bORÇÇEKLERİToolStripMenuItem.Name = "bORÇÇEKLERİToolStripMenuItem";
            this.bORÇÇEKLERİToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.bORÇÇEKLERİToolStripMenuItem.Text = "BORÇ ÇEKLERİ";
            // 
            // borçÇekiKaydıToolStripMenuItem
            // 
            this.borçÇekiKaydıToolStripMenuItem.Name = "borçÇekiKaydıToolStripMenuItem";
            this.borçÇekiKaydıToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.borçÇekiKaydıToolStripMenuItem.Text = "Borç Çeki Kaydı";
            this.borçÇekiKaydıToolStripMenuItem.Click += new System.EventHandler(this.borçÇekiKaydıToolStripMenuItem_Click);
            // 
            // mŞTEToolStripMenuItem
            // 
            this.mŞTEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.müşteriSenediKaydıToolStripMenuItem});
            this.mŞTEToolStripMenuItem.Name = "mŞTEToolStripMenuItem";
            this.mŞTEToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.mŞTEToolStripMenuItem.Text = "MÜŞTERİ SENETLERİ";
            this.mŞTEToolStripMenuItem.Click += new System.EventHandler(this.mŞTEToolStripMenuItem_Click);
            // 
            // müşteriSenediKaydıToolStripMenuItem
            // 
            this.müşteriSenediKaydıToolStripMenuItem.Name = "müşteriSenediKaydıToolStripMenuItem";
            this.müşteriSenediKaydıToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.müşteriSenediKaydıToolStripMenuItem.Text = "Müşteri Senedi Kaydı";
            this.müşteriSenediKaydıToolStripMenuItem.Click += new System.EventHandler(this.müşteriSenediKaydıToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borçSenediKaydıToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(227, 26);
            this.toolStripMenuItem1.Text = "BORÇ SENETLERİ";
            // 
            // borçSenediKaydıToolStripMenuItem
            // 
            this.borçSenediKaydıToolStripMenuItem.Name = "borçSenediKaydıToolStripMenuItem";
            this.borçSenediKaydıToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.borçSenediKaydıToolStripMenuItem.Text = "Borç Senedi Kaydı";
            this.borçSenediKaydıToolStripMenuItem.Click += new System.EventHandler(this.borçSenediKaydıToolStripMenuItem_Click);
            // 
            // gENELToolStripMenuItem
            // 
            this.gENELToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yARDIMCIPROGRAMLARToolStripMenuItem});
            this.gENELToolStripMenuItem.Name = "gENELToolStripMenuItem";
            this.gENELToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.gENELToolStripMenuItem.Text = "GENEL";
            // 
            // yARDIMCIPROGRAMLARToolStripMenuItem
            // 
            this.yARDIMCIPROGRAMLARToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kAYITToolStripMenuItem1});
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Name = "yARDIMCIPROGRAMLARToolStripMenuItem";
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Text = "YARDIMCI PROGRAMLAR";
            // 
            // kAYITToolStripMenuItem1
            // 
            this.kAYITToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kuyruktakiEPostaGönderimiToolStripMenuItem});
            this.kAYITToolStripMenuItem1.Name = "kAYITToolStripMenuItem1";
            this.kAYITToolStripMenuItem1.Size = new System.Drawing.Size(130, 26);
            this.kAYITToolStripMenuItem1.Text = "KAYIT";
            // 
            // kuyruktakiEPostaGönderimiToolStripMenuItem
            // 
            this.kuyruktakiEPostaGönderimiToolStripMenuItem.Name = "kuyruktakiEPostaGönderimiToolStripMenuItem";
            this.kuyruktakiEPostaGönderimiToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.kuyruktakiEPostaGönderimiToolStripMenuItem.Text = "Kuyruktaki E-Posta Gönderimi";
            this.kuyruktakiEPostaGönderimiToolStripMenuItem.Click += new System.EventHandler(this.kuyruktakiEPostaGönderimiToolStripMenuItem_Click);
            // 
            // üRETİMToolStripMenuItem
            // 
            this.üRETİMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.üRETİMToolStripMenuItem1,
            this.iŞEMRİToolStripMenuItem,
            this.mRPToolStripMenuItem,
            this.pLANLAMAToolStripMenuItem1,
            this.mAMÜLToolStripMenuItem,
            this.mAKİNEBAKIMToolStripMenuItem,
            this.üRETİMAKIŞKONTROLToolStripMenuItem});
            this.üRETİMToolStripMenuItem.Name = "üRETİMToolStripMenuItem";
            this.üRETİMToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.üRETİMToolStripMenuItem.Text = "ÜRETİM";
            // 
            // üRETİMToolStripMenuItem1
            // 
            this.üRETİMToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem,
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem,
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem,
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem,
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem,
            this.açıkReçeteAnaliziToolStripMenuItem,
            this.reçeteSilToolStripMenuItem});
            this.üRETİMToolStripMenuItem1.Name = "üRETİMToolStripMenuItem1";
            this.üRETİMToolStripMenuItem1.Size = new System.Drawing.Size(251, 26);
            this.üRETİMToolStripMenuItem1.Text = "ÜRETİM";
            // 
            // üretimAkışKontrolYeniKayıtToolStripMenuItem
            // 
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem.Name = "üretimAkışKontrolYeniKayıtToolStripMenuItem";
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem.Text = "Üretim Akış Kontrol - Yeni Kayıt";
            this.üretimAkışKontrolYeniKayıtToolStripMenuItem.Click += new System.EventHandler(this.üretimAkışKontrolYeniKayıtToolStripMenuItem_Click);
            // 
            // üretimAkışKontrolKayıtSilmeToolStripMenuItem
            // 
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem.Name = "üretimAkışKontrolKayıtSilmeToolStripMenuItem";
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem.Text = "Üretim Akış Kontrol - Kayıt Silme";
            this.üretimAkışKontrolKayıtSilmeToolStripMenuItem.Click += new System.EventHandler(this.üretimAkışKontrolKayıtSilmeToolStripMenuItem_Click);
            // 
            // üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem
            // 
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem.Name = "üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem";
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem.Text = "Üretim Akış Kontrol - Kayıt Düzeltme";
            this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem.Click += new System.EventHandler(this.üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem_Click);
            // 
            // üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem
            // 
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem.Name = "üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem";
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem.Text = "Üretim Akış Kontrol - Üretim Sonu Kaydı";
            this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem.Click += new System.EventHandler(this.üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem_Click);
            // 
            // kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem
            // 
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem.Name = "kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem";
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem.Text = "Kayıt Fiş Numarası ile Üretim Sonu Kaydı";
            this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem.Click += new System.EventHandler(this.kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem_Click);
            // 
            // açıkReçeteAnaliziToolStripMenuItem
            // 
            this.açıkReçeteAnaliziToolStripMenuItem.Name = "açıkReçeteAnaliziToolStripMenuItem";
            this.açıkReçeteAnaliziToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.açıkReçeteAnaliziToolStripMenuItem.Text = "Açık Reçete Analizi";
            this.açıkReçeteAnaliziToolStripMenuItem.Click += new System.EventHandler(this.açıkReçeteAnaliziToolStripMenuItem_Click);
            // 
            // reçeteSilToolStripMenuItem
            // 
            this.reçeteSilToolStripMenuItem.Name = "reçeteSilToolStripMenuItem";
            this.reçeteSilToolStripMenuItem.Size = new System.Drawing.Size(360, 26);
            this.reçeteSilToolStripMenuItem.Text = "Reçete Sil";
            this.reçeteSilToolStripMenuItem.Click += new System.EventHandler(this.reçeteSilToolStripMenuItem_Click);
            // 
            // iŞEMRİToolStripMenuItem
            // 
            this.iŞEMRİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işEmriYeniKayıtToolStripMenuItem,
            this.işEmriKayıtDüzeltToolStripMenuItem,
            this.işEmriSilmeToolStripMenuItem});
            this.iŞEMRİToolStripMenuItem.Name = "iŞEMRİToolStripMenuItem";
            this.iŞEMRİToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.iŞEMRİToolStripMenuItem.Text = "İŞ EMRİ";
            // 
            // işEmriYeniKayıtToolStripMenuItem
            // 
            this.işEmriYeniKayıtToolStripMenuItem.Name = "işEmriYeniKayıtToolStripMenuItem";
            this.işEmriYeniKayıtToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.işEmriYeniKayıtToolStripMenuItem.Text = "İş Emri - Yeni Kayıt";
            this.işEmriYeniKayıtToolStripMenuItem.Click += new System.EventHandler(this.işEmriYeniKayıtToolStripMenuItem_Click);
            // 
            // işEmriKayıtDüzeltToolStripMenuItem
            // 
            this.işEmriKayıtDüzeltToolStripMenuItem.Name = "işEmriKayıtDüzeltToolStripMenuItem";
            this.işEmriKayıtDüzeltToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.işEmriKayıtDüzeltToolStripMenuItem.Text = "İş Emri - Kayıt Düzelt";
            this.işEmriKayıtDüzeltToolStripMenuItem.Click += new System.EventHandler(this.işEmriKayıtDüzeltToolStripMenuItem_Click);
            // 
            // işEmriSilmeToolStripMenuItem
            // 
            this.işEmriSilmeToolStripMenuItem.Name = "işEmriSilmeToolStripMenuItem";
            this.işEmriSilmeToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.işEmriSilmeToolStripMenuItem.Text = "İş Emri Silme";
            this.işEmriSilmeToolStripMenuItem.Click += new System.EventHandler(this.işEmriSilmeToolStripMenuItem_Click);
            // 
            // mRPToolStripMenuItem
            // 
            this.mRPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mGPÇalıştırToolStripMenuItem,
            this.gereksinimPlanıOluşturmaToolStripMenuItem,
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem,
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem});
            this.mRPToolStripMenuItem.Name = "mRPToolStripMenuItem";
            this.mRPToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.mRPToolStripMenuItem.Text = "MRP";
            // 
            // mGPÇalıştırToolStripMenuItem
            // 
            this.mGPÇalıştırToolStripMenuItem.Name = "mGPÇalıştırToolStripMenuItem";
            this.mGPÇalıştırToolStripMenuItem.Size = new System.Drawing.Size(387, 26);
            this.mGPÇalıştırToolStripMenuItem.Text = "MGP Çalıştır";
            this.mGPÇalıştırToolStripMenuItem.Click += new System.EventHandler(this.mGPÇalıştırToolStripMenuItem_Click);
            // 
            // gereksinimPlanıOluşturmaToolStripMenuItem
            // 
            this.gereksinimPlanıOluşturmaToolStripMenuItem.Name = "gereksinimPlanıOluşturmaToolStripMenuItem";
            this.gereksinimPlanıOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(387, 26);
            this.gereksinimPlanıOluşturmaToolStripMenuItem.Text = "Gereksinim Planı Oluşturma";
            this.gereksinimPlanıOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.gereksinimPlanıOluşturmaToolStripMenuItem_Click);
            // 
            // malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem
            // 
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem.Name = "malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem";
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(387, 26);
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem.Text = "Malzeme Gereksiniminden İş Emri Oluşturma";
            this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem_Click);
            // 
            // malzemeGereksinimindenTalepOluşturmaToolStripMenuItem
            // 
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Name = "malzemeGereksinimindenTalepOluşturmaToolStripMenuItem";
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(387, 26);
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Text = "Malzeme Gereksiniminden Talep Oluşturma";
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem_Click);
            // 
            // pLANLAMAToolStripMenuItem1
            // 
            this.pLANLAMAToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1});
            this.pLANLAMAToolStripMenuItem1.Name = "pLANLAMAToolStripMenuItem1";
            this.pLANLAMAToolStripMenuItem1.Size = new System.Drawing.Size(251, 26);
            this.pLANLAMAToolStripMenuItem1.Text = "PLANLAMA";
            // 
            // stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1
            // 
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1.Name = "stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1";
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1.Size = new System.Drawing.Size(373, 26);
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1.Text = "Stok-Cari-Müşteri/Satıcı Planlama Kayıtları";
            this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1.Click += new System.EventHandler(this.stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1_Click);
            // 
            // mAMÜLToolStripMenuItem
            // 
            this.mAMÜLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mamulRezervasyonToolStripMenuItem,
            this.mamulRezervasyonİptalToolStripMenuItem});
            this.mAMÜLToolStripMenuItem.Name = "mAMÜLToolStripMenuItem";
            this.mAMÜLToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.mAMÜLToolStripMenuItem.Text = "MAMUL";
            // 
            // mamulRezervasyonToolStripMenuItem
            // 
            this.mamulRezervasyonToolStripMenuItem.Name = "mamulRezervasyonToolStripMenuItem";
            this.mamulRezervasyonToolStripMenuItem.Size = new System.Drawing.Size(258, 26);
            this.mamulRezervasyonToolStripMenuItem.Text = "Mamul Rezervasyon";
            this.mamulRezervasyonToolStripMenuItem.Click += new System.EventHandler(this.mamulRezervasyonToolStripMenuItem_Click);
            // 
            // mamulRezervasyonİptalToolStripMenuItem
            // 
            this.mamulRezervasyonİptalToolStripMenuItem.Name = "mamulRezervasyonİptalToolStripMenuItem";
            this.mamulRezervasyonİptalToolStripMenuItem.Size = new System.Drawing.Size(258, 26);
            this.mamulRezervasyonİptalToolStripMenuItem.Text = "Mamul Rezervasyon İptal";
            this.mamulRezervasyonİptalToolStripMenuItem.Click += new System.EventHandler(this.mamulRezervasyonİptalToolStripMenuItem_Click);
            // 
            // mAKİNEBAKIMToolStripMenuItem
            // 
            this.mAKİNEBAKIMToolStripMenuItem.Name = "mAKİNEBAKIMToolStripMenuItem";
            this.mAKİNEBAKIMToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.mAKİNEBAKIMToolStripMenuItem.Text = "MAKİNE BAKIM";
            // 
            // üRETİMAKIŞKONTROLToolStripMenuItem
            // 
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Name = "üRETİMAKIŞKONTROLToolStripMenuItem";
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Text = "ÜRETİM, AKIŞ KONTROL";
            // 
            // mUHASEBEToolStripMenuItem
            // 
            this.mUHASEBEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mUHASEBEToolStripMenuItem1,
            this.eNTEGREToolStripMenuItem,
            this.mALİYETMUHASEBESİToolStripMenuItem});
            this.mUHASEBEToolStripMenuItem.Name = "mUHASEBEToolStripMenuItem";
            this.mUHASEBEToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.mUHASEBEToolStripMenuItem.Text = "MUHASEBE";
            // 
            // mUHASEBEToolStripMenuItem1
            // 
            this.mUHASEBEToolStripMenuItem1.Name = "mUHASEBEToolStripMenuItem1";
            this.mUHASEBEToolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.mUHASEBEToolStripMenuItem1.Text = "MUHASEBE";
            // 
            // eNTEGREToolStripMenuItem
            // 
            this.eNTEGREToolStripMenuItem.Name = "eNTEGREToolStripMenuItem";
            this.eNTEGREToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.eNTEGREToolStripMenuItem.Text = "ENTEGRE";
            // 
            // mALİYETMUHASEBESİToolStripMenuItem
            // 
            this.mALİYETMUHASEBESİToolStripMenuItem.Name = "mALİYETMUHASEBESİToolStripMenuItem";
            this.mALİYETMUHASEBESİToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.mALİYETMUHASEBESİToolStripMenuItem.Text = "MALİYET MUHASEBESİ";
            // 
            // btnDIsconnect
            // 
            this.btnDIsconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDIsconnect.Location = new System.Drawing.Point(772, 547);
            this.btnDIsconnect.Name = "btnDIsconnect";
            this.btnDIsconnect.Size = new System.Drawing.Size(94, 28);
            this.btnDIsconnect.TabIndex = 18;
            this.btnDIsconnect.Text = "Çıkış";
            this.btnDIsconnect.UseVisualStyleBackColor = true;
            this.btnDIsconnect.Click += new System.EventHandler(this.btnDIsconnect_Click);
            // 
            // grpCompanyInfos
            // 
            this.grpCompanyInfos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.grpCompanyInfos.Controls.Add(this.txtSube);
            this.grpCompanyInfos.Controls.Add(this.txtNetsisPassword);
            this.grpCompanyInfos.Controls.Add(this.txtNetsisUserName);
            this.grpCompanyInfos.Controls.Add(this.txtBranch);
            this.grpCompanyInfos.Controls.Add(this.checkBxRemember);
            this.grpCompanyInfos.Controls.Add(this.label5);
            this.grpCompanyInfos.Controls.Add(this.label4);
            this.grpCompanyInfos.Controls.Add(this.txtDbName);
            this.grpCompanyInfos.Controls.Add(this.txtVTuserName);
            this.grpCompanyInfos.Controls.Add(this.txtVTPassword);
            this.grpCompanyInfos.Controls.Add(this.txtVTsifre);
            this.grpCompanyInfos.Controls.Add(this.label1);
            this.grpCompanyInfos.Controls.Add(this.label2);
            this.grpCompanyInfos.Location = new System.Drawing.Point(671, 300);
            this.grpCompanyInfos.Name = "grpCompanyInfos";
            this.grpCompanyInfos.Size = new System.Drawing.Size(324, 241);
            this.grpCompanyInfos.TabIndex = 19;
            this.grpCompanyInfos.TabStop = false;
            this.grpCompanyInfos.Text = "Şirket Bilgileri";
            // 
            // txtSube
            // 
            this.txtSube.Location = new System.Drawing.Point(144, 175);
            this.txtSube.Name = "txtSube";
            this.txtSube.Size = new System.Drawing.Size(117, 22);
            this.txtSube.TabIndex = 28;
            // 
            // txtNetsisPassword
            // 
            this.txtNetsisPassword.Location = new System.Drawing.Point(144, 147);
            this.txtNetsisPassword.Name = "txtNetsisPassword";
            this.txtNetsisPassword.PasswordChar = '*';
            this.txtNetsisPassword.Size = new System.Drawing.Size(117, 22);
            this.txtNetsisPassword.TabIndex = 27;
            // 
            // txtNetsisUserName
            // 
            this.txtNetsisUserName.Location = new System.Drawing.Point(144, 119);
            this.txtNetsisUserName.Name = "txtNetsisUserName";
            this.txtNetsisUserName.Size = new System.Drawing.Size(117, 22);
            this.txtNetsisUserName.TabIndex = 26;
            // 
            // txtBranch
            // 
            this.txtBranch.AutoSize = true;
            this.txtBranch.Location = new System.Drawing.Point(15, 175);
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.Size = new System.Drawing.Size(39, 16);
            this.txtBranch.TabIndex = 25;
            this.txtBranch.Text = "Şube";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "Netsis Şifre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Netsis Kullanıcı Adı";
            // 
            // txtDbName
            // 
            this.txtDbName.Location = new System.Drawing.Point(144, 32);
            this.txtDbName.Name = "txtDbName";
            this.txtDbName.Size = new System.Drawing.Size(116, 22);
            this.txtDbName.TabIndex = 20;
            // 
            // txtVTuserName
            // 
            this.txtVTuserName.Location = new System.Drawing.Point(144, 60);
            this.txtVTuserName.Name = "txtVTuserName";
            this.txtVTuserName.Size = new System.Drawing.Size(116, 22);
            this.txtVTuserName.TabIndex = 21;
            // 
            // txtVTPassword
            // 
            this.txtVTPassword.AutoSize = true;
            this.txtVTPassword.Location = new System.Drawing.Point(15, 92);
            this.txtVTPassword.Name = "txtVTPassword";
            this.txtVTPassword.Size = new System.Drawing.Size(55, 16);
            this.txtVTPassword.TabIndex = 14;
            this.txtVTPassword.Text = "VT Şifre";
            // 
            // txtVTsifre
            // 
            this.txtVTsifre.Location = new System.Drawing.Point(144, 88);
            this.txtVTsifre.Name = "txtVTsifre";
            this.txtVTsifre.PasswordChar = '*';
            this.txtVTsifre.Size = new System.Drawing.Size(116, 22);
            this.txtVTsifre.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "DB Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "VT Kullanıcı Adı";
            // 
            // btnGiris
            // 
            this.btnGiris.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGiris.Location = new System.Drawing.Point(672, 547);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(94, 28);
            this.btnGiris.TabIndex = 17;
            this.btnGiris.Text = "Giriş";
            this.btnGiris.UseVisualStyleBackColor = true;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            // 
            // frmNetOpenX
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1007, 603);
            this.Controls.Add(this.grpCompanyInfos);
            this.Controls.Add(this.btnDIsconnect);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnAnaMenu);
            this.Name = "frmNetOpenX";
            this.Text = "NetOpenX";
            this.Load += new System.EventHandler(this.frmNetOpenX_Load_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpCompanyInfos.ResumeLayout(false);
            this.grpCompanyInfos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAnaMenu;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lOJİSTİKSATIŞToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fATURAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kAYITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iŞLEMLERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBELGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bASIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rAPORLARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tALEPTEKLİFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dIŞTİCARETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dİNAMİKDEPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kALİTEKONTROLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kANTARTARTIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mÜSTAHSİLFATURASIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kARGOGÖNDERİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fİNANSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cARİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEKONTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bANKAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kASAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mÜŞTERİÇEKLERİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mŞTEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gENELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRETİMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mUHASEBEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bORÇÇEKLERİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yARDIMCIPROGRAMLARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRETİMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem iŞEMRİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mRPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mAKİNEBAKIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRETİMAKIŞKONTROLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mUHASEBEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eNTEGREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mALİYETMUHASEBESİToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBxRemember;
        private System.Windows.Forms.ToolStripMenuItem satışFaturasıKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışİrsaliyesiKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eİrsaliyesiKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mğşteriSiparişKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem şirketlerArasıFaturaKopyalamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lokalDepolarArasıTransferKAydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem şubelerArasıDepoTransferKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışTeklifiKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sipariştenİrsaliyeOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irsaliyedenFaturaOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ambarGirişFişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tevkifatlıFaturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karmaKoliToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parçalıSiparişToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tahsilatlıFaturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaSİlmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satırBazlıAçıklamaGirişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişRevizyonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eArşivOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaTaslakOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eİrsaliyeTaslakOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eArşivGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIrsaliyeGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ihracatKayıtlıEFaturaGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eArşivGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eİrsaliyeGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retKabulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eİrsaliyeKalemKabulRetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topluEBelgeOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pdfBasimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaBasimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dizaynNoİleFaturaBasımıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irsaliyeFaturaKalemBarkodBasımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modülDizaynıİleFaturaBasımıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satınAlmaTalepTeklifleştirmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satınAlmaTalepSiparişleştirmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışTalepSiparişleştirmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışTalepTeklifleştirmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokDüzenleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokSİlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokHareketKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reçeteliKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doEkleDekontKayıtSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dekomasKayıtSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muhasebeDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHavaleEftVirmanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHesapHareketKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHesapHareketOkuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariÖdemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekÖdemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem senetÖdemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muhtelifİşlemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaTransferToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHareketKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaKaydındaÇokluKalemGirişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaKalemleriOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriÇekiKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borçÇekiKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriSenediKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borçSenediKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kAYITToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem üretimAkışKontrolYeniKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üretimAkışKontrolKayıtSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem açıkReçeteAnaliziToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reçeteSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işEmriYeniKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işEmriKayıtDüzeltToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işEmriSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kuyruktakiEPostaGönderimiToolStripMenuItem;
        private System.Windows.Forms.Button btnDIsconnect;
        private System.Windows.Forms.GroupBox grpCompanyInfos;
        private System.Windows.Forms.TextBox txtSube;
        private System.Windows.Forms.TextBox txtNetsisPassword;
        private System.Windows.Forms.TextBox txtNetsisUserName;
        private System.Windows.Forms.Label txtBranch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDbName;
        private System.Windows.Forms.TextBox txtVTuserName;
        private System.Windows.Forms.Label txtVTPassword;
        private System.Windows.Forms.TextBox txtVTsifre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.ToolStripMenuItem pLANLAMAToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mGPÇalıştırToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gereksinimPlanıOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimindenTalepOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mAMÜLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mamulRezervasyonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mamulRezervasyonİptalToolStripMenuItem;
    }
}