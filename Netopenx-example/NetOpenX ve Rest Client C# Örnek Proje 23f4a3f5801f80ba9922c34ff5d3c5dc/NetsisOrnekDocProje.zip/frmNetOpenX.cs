﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NetOpenX50;
using NetBasimX;


namespace DocProje
{


    public partial class frmNetOpenX : Form
    {

        public frmNetOpenX()
        {
            InitializeComponent();
        }

        private void btnAnaMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAnaMenu AnaMenu = new frmAnaMenu();
            AnaMenu.ShowDialog();
            this.Close();
        }

        private void mŞTEToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkBxRemember.Checked == true)
                {
                    sirketNetOpenX.Default.dbName = txtDbName.Text;
                    sirketNetOpenX.Default.vtUserName = txtVTuserName.Text;
                    sirketNetOpenX.Default.vtUserPsw = txtVTsifre.Text;
                    sirketNetOpenX.Default.netsisUserName = txtNetsisUserName.Text;
                    sirketNetOpenX.Default.netsisUserPsw = txtNetsisPassword.Text;
                    sirketNetOpenX.Default.branch = Convert.ToInt32(txtSube.Text);
                    sirketNetOpenX.Default.Save();


                }

                Global.SirketTanım();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                MessageBox.Show("Giriş Başarılı");
            }

        }

        private void checkBxRemember_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmNetOpenX_Load_1(object sender, EventArgs e)
        {
            txtDbName.Text = sirketNetOpenX.Default.dbName;
            txtVTuserName.Text = sirketNetOpenX.Default.vtUserName;
            txtVTsifre.Text = sirketNetOpenX.Default.vtUserPsw;
            txtNetsisUserName.Text = sirketNetOpenX.Default.netsisUserName;
            txtNetsisPassword.Text = sirketNetOpenX.Default.netsisUserPsw;
            txtSube.Text = Convert.ToString(sirketNetOpenX.Default.branch);
        }

        private void cariKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Cari cari = default(Cari);
            CariTemelBilgi cariTmlBlg = default(CariTemelBilgi);
            CariEkBilgi cariEkBlg = default(CariEkBilgi);


            try
            {


                cari = Global.kernel.yeniCari(Global.sirket);
                cariTmlBlg = cari.TemelBilgi();
                cariEkBlg = cari.EkBilgi();
                cariTmlBlg.CARI_KOD = "00005";
                cariTmlBlg.CARI_ISIM = "Cari Hesap Ismi";
                cariTmlBlg.CARI_TIP = "S";
                cariTmlBlg.CARI_IL = "ANKARA";
                cariEkBlg.CARI_KOD = cariTmlBlg.CARI_KOD;
                cariEkBlg.TcKimlikNo = "Cari345lsdd";
                cari.kayitYeni();
                MessageBox.Show("Cari Kayıt İşlemi Başarılı");

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(cariEkBlg);
                Marshal.ReleaseComObject(cariTmlBlg);
                Marshal.ReleaseComObject(cari);

            }
        }

        private void cariOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Cari cari = default(Cari);
            CariTemelBilgi caritemel = default(CariTemelBilgi);

            try
            {

                cari = Global.kernel.yeniCari(Global.sirket);

                caritemel = cari.TemelBilgi();
                cari.kayitOku(TOkumaTipi.otAc, "CASABIT.CARI_KOD='00005'");
                {
                    cari.kayitOku(TOkumaTipi.otIlk);
                    MessageBox.Show(caritemel.CARI_IL);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(cari);

            }
        }

        private void cariSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Cari cari = default(Cari);


            try
            {
                cari = Global.kernel.yeniCari(Global.sirket);

                if (cari.kayitOku(TOkumaTipi.otAc, "CASABIT.CARI_KOD='00005'"))
                {
                    cari.kayitOku(TOkumaTipi.otIlk);
                    cari.kayitSil();

                }

                MessageBox.Show("Silme İşlemi Başarılı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(cari);

            }
        }

        private void doEkleDekontKayıtSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);

            try
            {


                dekont = Global.kernel.yeniDekont(Global.sirket);
                dekont.kayitOku(TOkumaTipi.otAc, "DEKONT_NO=1");
                var result = dekont.kayitOku(TOkumaTipi.otIlk);
                while (result)
                {
                    MessageBox.Show(dekont.Seri_No + "  " + dekont.Dekont_No + "" + dekont.Sira_No);
                    dekont.SDekont(TDekOpr.doSil);
                }

                MessageBox.Show("DoEkle Dekont Kayıt Silme İşlemi Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(dekont);

            }
        }

        private void dekomasKayıtSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);
            Dekomas dekomas = default(Dekomas);

            try
            {


                dekont = Global.kernel.yeniDekont(Global.sirket);
                dekomas = Global.kernel.yeniDekomas(Global.sirket);

                if (dekomas.BelgeGetir("SM", 12))
                {
                    dekomas.TumKalemleriSil();
                }
                MessageBox.Show("Dekomas Kayıt Silme İşlemi Başarılı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(dekont);

            }
        }

        private void cariDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);
            try
            {

                dekont = Global.kernel.yeniDekont(Global.sirket);

                dekont.Seri_No = "01";
                dekont.Kod = "00002";
                dekont.C_M = "C";
                dekont.Fisno = "A";
                dekont.Plasiyer = "02";
                dekont.B_A = "B";
                dekont.ValorGun = 0;
                dekont.ValorTrh = DateTime.Now;
                dekont.DovTL = "D";
                dekont.DOVTUT = 500;
                dekont.Tutar = 750;
                dekont.Tarih = DateTime.Now;
                dekont.Proje_Kodu = "033";
                dekont.CDekont(TDekOpr.doEkle);

                MessageBox.Show("Cari Dekont Kaydı Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(dekont);

            }
        }

        private void stokDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);
            try
            {


                dekont = Global.kernel.yeniDekont(Global.sirket);
                dekont.Seri_No = "01";
                dekont.Kod = "00001";
                dekont.C_M = "S";
                dekont.Fisno = "A";
                dekont.B_A = "B";
                dekont.ValorGun = 0;
                dekont.ValorTrh = DateTime.Now;
                dekont.DovTL = "D";
                dekont.DOVTUT = 500;
                dekont.Tutar = 750;
                dekont.Tarih = DateTime.Now;
                dekont.Proje_Kodu = "033";
                dekont.Plasiyer = "02";
                dekont.SDekont(TDekOpr.doEkle);

                MessageBox.Show("Stok Dekont Kaydı Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(dekont);

            }
        }

        private void muhasebeDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);
            try
            {


                dekont = Global.kernel.yeniDekont(Global.sirket);
                dekont.Seri_No = "01";
                dekont.Kod = "100-01-001";
                dekont.C_M = "M";
                dekont.Fisno = "A";
                dekont.B_A = "B";
                dekont.ValorGun = 0;
                dekont.ValorTrh = DateTime.Now;
                dekont.DovTL = "D";
                dekont.DOVTUT = 500;
                dekont.Tutar = 750;
                dekont.Tarih = DateTime.Now;
                dekont.Proje_Kodu = "033";
                dekont.Plasiyer = "02";
                dekont.MDekont(TDekOpr.doEkle);

                MessageBox.Show("Muhasebe Dekont Kaydı Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(dekont);
            }
        }

        private void bankaDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Dekont dekont = default(Dekont);
            try
            {


                dekont = Global.kernel.yeniDekont(Global.sirket);

                dekont.Seri_No = "01";
                dekont.Kod = "001015";
                dekont.C_M = "B";
                dekont.Fisno = "A";
                dekont.Plasiyer = "02";
                dekont.B_A = "B";
                dekont.ValorGun = 0;
                dekont.ValorTrh = DateTime.Now;
                dekont.DOVTIP = 1;
                dekont.DovTL = "D";
                dekont.DOVTUT = 500;
                dekont.Tutar = 750;
                dekont.Tarih = DateTime.Now;
                dekont.Proje_Kodu = "033";
                dekont.BDekont(TDekOpr.doEkle);

                MessageBox.Show("Banka Dekont Kaydı Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(dekont);

            }
        }

        private void bankaHavaleEftVirmanToolStripMenuItem_Click(object sender, EventArgs e)
        {

            BankaHavaleEftVirman bankaHavaleEftVirman = default(BankaHavaleEftVirman);
            BankaLogTra bankalogtra = default(BankaLogTra);
            try
            {


                bankaHavaleEftVirman = Global.kernel.yeniBankaHavaleEftVirman(Global.sirket, TBankaHavaleEftTip.tbCariHvl,
                    0, "001015"); // 0 Gelen 1 giden 
                bankalogtra = bankaHavaleEftVirman.EvrakYeni();
                bankalogtra.NetHesKodu = "001015";
                bankalogtra.KarsiHesKod = "320-01-048";
                bankalogtra.Tutar = 1350;
                bankalogtra.PlasiyerKodu = "1";
                bankalogtra.Sube_Kodu = 0;
                bankalogtra.YevAciklama = "Havale";

                bankaHavaleEftVirman.EvrakKaydet();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(bankaHavaleEftVirman);

            }
        }

        private void bankaHesapHareketKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {

            BankaHesTraAna bankaHesTraAna = default(BankaHesTraAna);
            BankaHesTra bankaHesTra = default(BankaHesTra);

            try
            {

                bankaHesTraAna = Global.kernel.yeniBankaHesTraAna(Global.sirket);
                bankaHesTra = bankaHesTraAna.HareketYeni();
                bankaHesTra.NetHesKodu = "YKB-01-VDSZ-2";
                bankaHesTra.Tarih = DateTime.Today;
                bankaHesTra.Tutar = 1000;
                bankaHesTra.HarTuru = 0;
                bankaHesTra.HarTipi = 0;
                bankaHesTra.Aciklama = "Test";
                bankaHesTra.BA = "B";
                bankaHesTra.PlasiyerKodu = "1";
                bankaHesTraAna.HareketKaydet();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(bankaHesTraAna);

            }
        }

        private void bankaHesapHareketOkuToolStripMenuItem_Click(object sender, EventArgs e)
        {

            BankaHesTraAna bankaHesTraAna = default(BankaHesTraAna);
            BankaHesTra bankaHesTra = default(BankaHesTra);

            try
            {



                bankaHesTraAna = Global.kernel.yeniBankaHesTraAna(Global.sirket);
                bankaHesTra = bankaHesTraAna.OkunanHesTra;
                bankaHesTraAna.kayitOku(TOkumaTipi.otAc, "NETHESKODU='YKB-01-VDSZ-2'");
                {
                    bankaHesTraAna.kayitOku(TOkumaTipi.otIlk);
                    MessageBox.Show(bankaHesTra.IncKeyNo.ToString());
                }

            }

            finally
            {
                Marshal.ReleaseComObject(bankaHesTraAna);

            }
        }

        private void cariÖdemeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "00";  //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "C";
                kasa.Kod = "00002";     //Cari Kodu
                kasa.Fisno = "99";
                kasa.Tutar = 500;
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.Islem(TKasaIslem.tkCariOdeme);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(kasa);

            }
        }

        private void faturaKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "00";      //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "F";
                kasa.Kod = "100-02-001";    //Muhasebe Karsilik Kodu
                kasa.Fisno = "x09";
                kasa.Tutar = 500;
                kasa.Kdv_Dahil = "E";
                kasa.Kdv_Oran = 18;
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.Islem(TKasaIslem.tkFaturaKayit);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasa);
                kasa = default(Kasa);
            }
        }

        private void çekÖdemeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "00";              //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "E";
                kasa.Tutar = 15;
                kasa.Fisno = "H00000000011299";     //Çek numarasi 
                kasa.Cari_Muh = "C";
                kasa.Kod = "00002";                 //Veren Cari Kodu
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.CSKOdeme(TCekSenType.csMCEK);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void senetÖdemeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);

            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "00";              //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "S";
                kasa.Tutar = 200;
                kasa.Fisno = "A70000000000051";     //Senet numarasi
                kasa.Cari_Muh = "C";
                kasa.Kod = "00002";                 //Veren Cari Kodu
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.CSKOdeme(TCekSenType.csMSEN);


                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void muhtelifİşlemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Kasa kasa = default(Kasa);

            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);

                kasa.KsMas_Kod = "00";     //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "M";
                kasa.Kod = "100-02-001";   //Muhasebe Karsilik Kodu
                kasa.Fisno = "141";
                kasa.Tutar = 500;
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.Islem(TKasaIslem.tkMuhtelif);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(kasa);

            }
        }

        private void kasaTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);

            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);

                kasa.KsMas_Kod = "01";         //Transfer Kasasi (kaynak kasa)
                kasa.Yedek1 = "00";            //Çalisilan Kasa  (hedef kasa)  
                kasa.IO = "C";
                kasa.Tip = "T";
                kasa.Fisno = "9";
                kasa.DovizTut = 300;           //Transfer Kasasi dovizli ise Doviz Tutar miktari girilir
                kasa.Tutar = 450;
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.Islem(TKasaIslem.tkKasaTransfer);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void bankaHareketKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);

                kasa.KsMas_Kod = "01";     //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "B";
                kasa.Fisno = "25";
                kasa.Kod = "001015";       //Banka Hesap Kodu
                kasa.DovizTut = 300;       //Dovizli kasa için doviz tutari girilir
                kasa.Tutar = 450;
                kasa.Plasiyer_Kodu = "02";
                kasa.Proje_Kodu = "033";
                kasa.Tarih = DateTime.Today;
                kasa.Islem(TKasaIslem.tkBankaHareket);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void faturaKaydındaÇokluKalemGirişiToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            KasaKdv kasaKdv = default(KasaKdv);

            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "1"; //Kasa Kodu
                kasa.IO = "G";
                kasa.Tip = "F";
                kasa.Kod = "600-01-001"; //Muhasebe Karsilik Kodu
                kasa.Fisno = "x10";
                kasa.Tarih = DateTime.Today;

                kasaKdv = kasa.KasaKalemYeni();
                kasaKdv.Kdv_Dahil = true;
                kasaKdv.Kod = "600-01-001";
                kasaKdv.Tutar = 200;
                kasaKdv.KdvMuhKod = "702-01-001";
                kasaKdv.Kdv_Oran = 8;
                kasaKdv.Miktar = 1;

                kasaKdv = kasa.KasaKalemYeni();
                kasaKdv.Kdv_Dahil = true;
                kasaKdv.Kod = "600-01-002";
                kasaKdv.Tutar = 400;
                kasaKdv.KdvMuhKod = "191-20-01";
                kasaKdv.Kdv_Oran = 8;
                kasaKdv.Miktar = 1;
                kasaKdv.Aciklama = "ac2";

                kasa.Islem(TKasaIslem.tkFaturaKayit);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasaKdv);
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void kasaKalemleriOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Kasa kasa = default(Kasa);
            KasaKdv kasaKdv = default(KasaKdv);
            string fisno = "";
            try
            {


                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.kayitOku(TOkumaTipi.otAc, "FISNO='" + fisno + "'");
                kasa.kayitOku(TOkumaTipi.otIlk);
                for (int i = 0; i <= kasa.KdvKalemAdedi - 1; i++)
                {
                    kasaKdv = kasa.get_KdvKalem(i);
                    MessageBox.Show(kasaKdv.Kod);
                }

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(kasaKdv);
                Marshal.ReleaseComObject(kasa);

            }
        }

        private void müşteriÇekiKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            CekSenetAna cekSenetAna = default(CekSenetAna);
            CekSenet cekSenet = default(CekSenet);
            try
            {


                cekSenetAna = Global.kernel.yeniCekSenAna(Global.sirket, TCekSenType.csMCEK);
                cekSenet = cekSenetAna.EvrakYeni();
                cekSenet.CEKSERI = "H";
                cekSenet.SC_GIRTRH = DateTime.Now;
                cekSenet.SC_VERENK = "00002";
                cekSenet.AS_C = "A";
                cekSenet.SC_YERI = "P";
                cekSenet.VADETRH = DateTime.Now.AddMonths(1);
                cekSenet.SC_ODETRH = cekSenet.VADETRH;
                cekSenet.Proje_Kodu = "033";
                cekSenet.Plasiyer_Kodu = "02";
                cekSenet.Tutar = 500;
                cekSenetAna.EvraklariKaydet(TCekSenetEvrakKaydetmeTipi.ektCekSenAlma);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(cekSenet);
                Marshal.ReleaseComObject(cekSenetAna);

            }
        }

        private void borçÇekiKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            CekSenetAna cekSenetAna = default(CekSenetAna);
            CekSenet cekSenet = default(CekSenet);
            try
            {


                cekSenetAna = Global.kernel.yeniCekSenAna(Global.sirket, TCekSenType.csBCEK);
                cekSenet = cekSenetAna.EvrakYeni();
                cekSenet.CEKSERI = "A";
                cekSenet.SC_CIKTRH = DateTime.Now;
                cekSenet.SC_VERENK = "VADESIZTL";               //Banka Hesap Kodu
                cekSenet.SC_YERI = "C";
                cekSenet.SC_VERILENK = "00002";                 //Verilen Cari Kodu
                cekSenet.VADETRH = DateTime.Now.AddMonths(1);
                cekSenet.SC_ODETRH = cekSenet.VADETRH;
                cekSenet.Proje_Kodu = "033";
                cekSenet.Plasiyer_Kodu = "02";
                cekSenet.Tutar = 500;
                cekSenetAna.EvraklariKaydet(TCekSenetEvrakKaydetmeTipi.ektCekSenVerme);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(cekSenet);
                Marshal.ReleaseComObject(cekSenetAna);

            }
        }

        private void müşteriSenediKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            CekSenetAna cekSenetAna = default(CekSenetAna);
            CekSenet cekSenet = default(CekSenet);
            try
            {


                cekSenetAna = Global.kernel.yeniCekSenAna(Global.sirket, TCekSenType.csMSEN);
                cekSenet = cekSenetAna.EvrakYeni();
                cekSenet.CEKSERI = "A";
                cekSenet.SC_GIRTRH = DateTime.Now;
                cekSenet.SC_VERENK = "00002";
                cekSenet.AS_C = "A";
                cekSenet.SC_YERI = "P";
                cekSenet.VADETRH = DateTime.Now.AddMonths(1);
                cekSenet.SC_ODETRH = cekSenet.VADETRH;
                cekSenet.Proje_Kodu = "033";
                cekSenet.Plasiyer_Kodu = "02";
                cekSenet.Tutar = 500;
                cekSenetAna.EvraklariKaydet(TCekSenetEvrakKaydetmeTipi.ektCekSenAlma);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(cekSenet);
                Marshal.ReleaseComObject(cekSenetAna);

            }
        }

        private void borçSenediKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            CekSenetAna cekSenetAna = default(CekSenetAna);
            CekSenet cekSenet = default(CekSenet);
            try
            {


                cekSenetAna = Global.kernel.yeniCekSenAna(Global.sirket, TCekSenType.csBSEN);
                cekSenet = cekSenetAna.EvrakYeni();
                cekSenet.CEKSERI = "A";
                cekSenet.YERI = "IZMIR";
                cekSenet.SC_YERI = "C";
                cekSenet.SC_CIKTRH = DateTime.Now;
                cekSenet.SC_VERILENK = "00002";                 //Verilen Cari Kodu
                cekSenet.VADETRH = DateTime.Now.AddMonths(1);
                cekSenet.SC_ODETRH = cekSenet.VADETRH;
                cekSenet.Proje_Kodu = "033";
                cekSenet.Plasiyer_Kodu = "02";
                cekSenet.Tutar = 500;
                cekSenetAna.EvraklariKaydet(TCekSenetEvrakKaydetmeTipi.ektCekSenVerme);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(cekSenet);
                Marshal.ReleaseComObject(cekSenetAna);

            }
        }

        private void satışFaturasıKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.CariKod = "00002";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_Acik;
                fatUst.Proje_Kodu = "1";
                fatUst.KDV_DAHILMI = true;

                fatKalem = fatura.kalemYeni("001");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;

                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void satışİrsaliyesiKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {

                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.CariKod = "00002";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_YurtIci;
                fatUst.PLA_KODU = "02";
                fatUst.Proje_Kodu = "033";
                fatUst.KDV_DAHILMI = true;
                fatKalem = fatura.kalemYeni("00003");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;
                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void eİrsaliyesiKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            IEIrsEkBilgi eIrsEkBilgi = default(IEIrsEkBilgi);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniEIrsaliyeNumara("EIR");  // E-irsaliye belgeleri için sıradaki numarayı getirir.
                fatUst.CariKod = "EFATA2";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.FIYATTARIHI = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_Acik;
                //fatUst.PLA_KODU = "02"; 
                //fatUst.Proje_Kodu = "033"; 
                fatUst.EIrsaliye = true;  //Bu alan temelsette satış irsaliyesi girişindeki e-irsaliye checkbox’ı gibi çalışıyor. Bu alanın true ya da false olmasına bağlı olarak numara ve cari kodu kontrolleri eklendi.
                fatUst.KDV_DAHILMI = true;
                fatKalem = fatura.kalemYeni("1");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;

                eIrsEkBilgi = fatura.EIrsaliyeEkYeni();  //E-İrsaliye ek bilgi girişi desteklendi. 
                eIrsEkBilgi.TASIYICIIL = "CARRIERCITY";
                eIrsEkBilgi.TASIYICIULKE = "TR";
                eIrsEkBilgi.TASIYICIADI = "CARRIERNAME";
                eIrsEkBilgi.TASIYICIPOSTAKODU = "34863";
                eIrsEkBilgi.TASIYICIILCE = "CARRIERSUBCITY";
                eIrsEkBilgi.TASIYICIVKN = "CARRIERVKN";
                eIrsEkBilgi.SOFOR1SOYADI = "DPERSON1FAMILYNAME";
                eIrsEkBilgi.SOFOR1ADI = "DPERSON1FIRSTNAME";
                eIrsEkBilgi.SOFOR1TCKN = "DPERSON1NID";
                eIrsEkBilgi.SOFOR1ACIKLAMA = "DPERSON1TITLE";
                eIrsEkBilgi.SOFOR1TCKN = "11223344556";
                eIrsEkBilgi.PLAKA = "35LL747";
                eIrsEkBilgi.SEVKTAR = DateTime.Now;
                eIrsEkBilgi.SOFOR2SOYADI = "DPERSON2FAMILYNAME";
                eIrsEkBilgi.SOFOR2ADI = "DPERSON2FIRSTNAME";
                eIrsEkBilgi.SOFOR2TCKN = "DPERSON2NID";
                eIrsEkBilgi.SOFOR2ACIKLAMA = "DPERSON2TITLE";
                eIrsEkBilgi.SOFOR3SOYADI = "DPERSON3FAMILYNAME";
                eIrsEkBilgi.SOFOR3ADI = "DPERSON3FIRSTNAME";
                eIrsEkBilgi.SOFOR3TCKN = "DPERSON3NID";
                eIrsEkBilgi.SOFOR3ACIKLAMA = "DPERSON3TITLE";
                eIrsEkBilgi.DORSEPLAKA1 = "DORSEPLAKA1";
                eIrsEkBilgi.DORSEPLAKA2 = "DORSEPLAKA2";
                eIrsEkBilgi.DORSEPLAKA3 = "DORSEPLAKA3";


                fatura.kayitYeni();
                MessageBox.Show(fatUst.FATIRS_NO);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            finally
            {
                Marshal.ReleaseComObject(eIrsEkBilgi);
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void mğşteriSiparişKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSSip);

                fatura.StokKartinaGoreHesapla = true;
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.CariKod = "00002";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_YurtIci;
                fatUst.PLA_KODU = "02";
                fatUst.Proje_Kodu = "033";
                fatUst.KDV_DAHILMI = true;
                fatKalem = fatura.kalemYeni("00003");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;
                fatKalem.SatirBaziAcik[1] = "satır açıklama deneme";

                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void şirketlerArasıFaturaKopyalamaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void lokalDepolarArasıTransferKAydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftLokalDepo);

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.TIPI = TFaturaTipi.ft_Bos;
                fatUst.AMBHARTUR = TAmbarHarTur.htDepolar;
                fatUst.Tarih = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.PLA_KODU = "S001";
                fatUst.Proje_Kodu = "P001";
                fatUst.KDV_DAHILMI = true;

                fatKalem = fatura.kalemYeni("S0001");
                ///Giriş Depo Kodu
                fatKalem.Gir_Depo_Kodu = 3;
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK = 20;
                fatKalem.STra_BF = 10;
                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void şubelerArasıDepoTransferKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftDepo);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.TIPI = TFaturaTipi.ft_Bos;
                fatUst.AMBHARTUR = TAmbarHarTur.htDepolar;
                ///Çıkış Şube
                fatUst.GCKOD_CIKIS = 0;
                ///Giriş Şube
                fatUst.GCKOD_GIRIS = 1;
                ///Ambar
                fatUst.CariKod = "C0001";
                ///Cari Kod
                fatUst.CARI_KOD2 = "C0002";
                fatUst.Tarih = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.PLA_KODU = "S001";
                fatUst.Proje_Kodu = "P001";
                fatUst.KDV_DAHILMI = true;

                fatKalem = fatura.kalemYeni("S0001");
                ///Giriş Depo Kodu
                fatKalem.Gir_Depo_Kodu = 2;
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK = 20;
                fatKalem.STra_BF = 10;

                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void satışTeklifiKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSatTeklif);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.CariKod = "00002";
                fatUst.Tarih = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_YurtIci;
                fatUst.PLA_KODU = "02";
                fatUst.Proje_Kodu = "033";
                fatUst.KDV_DAHILMI = true;
                fatKalem = fatura.kalemYeni("00003");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;
                fatKalem.ProjeKodu = "033";
                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void sipariştenİrsaliyeOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            Fatura irsaliye = default(Fatura);
            FatUst irsaliyeUst = default(FatUst);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSSip);
                fatura.OkuUst("M00000000000006", "00002");
                fatura.OkuKalem();

                irsaliye = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);
                irsaliyeUst = irsaliye.Ust();

                irsaliyeUst.FATIRS_NO = irsaliye.YeniNumara("A");
                fatura.Siparis2IrsFat(irsaliye);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(irsaliyeUst);
                Marshal.ReleaseComObject(irsaliye);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void irsaliyedenFaturaOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura irsaliye = default(Fatura);
            Fatura fatura = default(Fatura);
            FatUst faturaUst = default(FatUst);
            try
            {


                irsaliye = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);
                irsaliye.OkuUst("I00000000000002", "00002");
                irsaliye.OkuKalem();
                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                faturaUst = fatura.Ust();
                faturaUst.FATIRS_NO = fatura.YeniNumara("A");
                irsaliye.Irsaliye2Fatura(fatura);

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(faturaUst);
                Marshal.ReleaseComObject(fatura);
                Marshal.ReleaseComObject(irsaliye);

            }
        }

        private void ambarGirişFişiToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftAmbarG);

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("0");
                fatUst.CariKod = "00001";
                fatUst.AMBHARTUR = TAmbarHarTur.htMuhtelif;
                fatUst.CikisYeri = TCikisYeri.cyStokKod;
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.Proje_Kodu = "100";

                fatKalem = fatura.kalemYeni("01001");
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;


                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı.");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void tevkifatlıFaturaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = "F00000000000012";
                fatUst.CariKod = "00001";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_Acik;
                fatUst.KDV_DAHILMI = false;
                fatUst.Proje_Kodu = "1";

                fatKalem = fatura.kalemYeni("STK01");
                fatKalem.STra_GCMIK = 1;
                fatKalem.STra_NF = 100;
                fatKalem.STra_BF = 100;
                fatKalem.STra_KDV = 18;
                fatKalem.DEPO_KODU = 1;

                fatura.HesaplamalariYap();

                fatUst.FAT_ALTM2 = -1;

                fatura.kayitYeni();
                MessageBox.Show(fatUst.FATIRS_NO);

            }

            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void karmaKoliToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("I");
                fatUst.CariKod = "00001";
                fatUst.Tarih = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_YurtIci;
                fatUst.Proje_Kodu = "1";
                fatUst.KDV_DAHILMI = true;

                fatKalem = fatura.kalemYeni("K1");
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK2 = 1;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;
                fatKalem.KarmaKoliIsle();

                fatura.kayitYeni();

                MessageBox.Show(fatUst.FATIRS_NO);

            }

            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void parçalıSiparişToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);

            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = "R00000000002108";
                fatUst.TIPI = TFaturaTipi.ft_Acik;
                fatUst.CariKod = "120-01-014";
                fatUst.Tarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.Proje_Kodu = "b";

                fatKalem = fatura.kalemYeni("SB1");
                fatKalem.STra_GCMIK = 1;
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_BF = 21;

                fatKalem.STra_SIPNUM = "R00000000000356";
                fatKalem.STra_SIPKONT = 1;
                fatKalem.STra_SIP_TURU = "S";

                fatura.kayitYeni();

                MessageBox.Show(fatUst.FATIRS_NO);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void tahsilatlıFaturaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            HizliTahsilatAna hizliTahsilatAna = default(HizliTahsilatAna);
            HizliTahsilat tahsil = default(HizliTahsilat);

            try
            {


                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                fatura.TahsilatKayitKullan = true;
                fatura.FiyatSistemineGoreHesapla = false;
                fatura.StokKartinaGoreHesapla = false;

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("R");
                fatUst.CariKod = "120-01-014";
                fatUst.Tarih = DateTime.Now;
                fatUst.SIPARIS_TEST = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_Kapali;
                fatUst.KDV_DAHILMI = false;

                fatKalem = fatura.kalemYeni("barkod1");
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK = 1;
                fatKalem.STra_NF = 100;
                fatKalem.STra_BF = 100;
                fatKalem.STra_testar = new DateTime(2021, 5, 27);

                fatura.HesaplamalariYap();
                tahsil = fatura.tahsilatYeni();
                tahsil.TahsilatTipi = TTahsilatTipi.ttNakit;
                tahsil.SozKodu = "NAKİT";
                tahsil.Tutar = 50;
                tahsil.PLA_KODU = "1";
                tahsil.Referans_Kodu = "1";
                tahsil.Proje_Kodu = "b";

                tahsil = fatura.tahsilatYeni();
                tahsil.TahsilatTipi = TTahsilatTipi.ttKrediKarti;
                tahsil.SozKodu = "1";
                tahsil.Tutar = 50;
                tahsil.PLA_KODU = "1";
                tahsil.Referans_Kodu = "1";
                tahsil.TaksitSay = 1;
                tahsil.Proje_Kodu = "b";

                fatura.kayitYeni();

                MessageBox.Show("KAYIT OLUŞTURULDU " + fatUst.FATIRS_NO);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(hizliTahsilatAna);
                Marshal.ReleaseComObject(tahsil);
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);

            }
        }

        private void faturaOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fatura kaynakFatura = default(Fatura);
            FatUst kaynakFatUst = default(FatUst);
            FatKalem kaynakFatKalem = default(FatKalem);

            try
            {
                kaynakFatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);



                kaynakFatura.OkuUst("R00000000001298", "120-01-014");
                kaynakFatUst = kaynakFatura.Ust();



                kaynakFatura.OkuKalem();
                MessageBox.Show(Convert.ToString(kaynakFatura.KalemAdedi));



                for (int i = 0; i < kaynakFatura.KalemAdedi; i++)
                {
                    kaynakFatKalem = kaynakFatura.get_Kalem(i);
                    MessageBox.Show(kaynakFatKalem.StokKodu);
                }
            }

            finally
            {
                Marshal.ReleaseComObject(kaynakFatura);
                Marshal.ReleaseComObject(kaynakFatUst);

            }
        }
    

        private void faturaSİlmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            try
            {
 
                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                fatura.OkuUst("A00000000000005", "00007");
                fatura.OkuKalem();
                fatura.kayitSil();

                MessageBox.Show("KAYIT OLUŞTURULDU " + fatUst.FATIRS_NO);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);
                
            }
        }

        private void satırBazlıAçıklamaGirişiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);
            try
            {
                

                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);

                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = fatura.YeniNumara("A");
                fatUst.CariKod = "00002";
                fatUst.Tarih = DateTime.Now;
                fatUst.ENTEGRE_TRH = DateTime.Now;
                fatUst.FiiliTarih = DateTime.Now;
                fatUst.TIPI = TFaturaTipi.ft_Acik;
                fatUst.PLA_KODU = "02";
                fatUst.Proje_Kodu = "033";
                fatUst.KDV_DAHILMI = true;

                fatKalem = fatura.kalemYeni("00003");
                fatKalem.DEPO_KODU = 2;
                fatKalem.STra_GCMIK = 5;
                fatKalem.STra_NF = 12;
                fatKalem.STra_BF = 12;
                fatKalem.SatirBaziAcik[1] = "satır açıklama deneme 1";
                fatKalem.SatirBaziAcik[1] = "satır açıklama deneme 2";

                fatura.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);
                
            }
        }

        private void siparişRevizyonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            FatKalem fatKalem = default(FatKalem);

            try
            {
                

                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSSip);
                fatUst = fatura.Ust();
                fatUst.FATIRS_NO = "AK0000000000072";
                fatUst.CariKod = "M0000000024";
                fatUst.Tarih = DateTime.Today;
                fatUst.TIPI = TFaturaTipi.ft_YurtIci;
                fatKalem = fatura.kalemYeni("stk038");
                fatKalem.Gir_Depo_Kodu = 2;
                fatKalem.DEPO_KODU = 1;
                fatKalem.STra_GCMIK = 1;
                fatKalem.STra_BF = 1;
                fatura.SiparisRevizyon("AK0000000000071", DateTime.Today);
                MessageBox.Show(fatUst.FATIRS_NO);

            }

            finally
            {
                Marshal.ReleaseComObject(fatKalem);
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);
                
            }
        }

        private void irsaliyelerinTopluFaturalaştırılmasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Fatura irsaliye = default(Fatura);
            Fatura fatura = default(Fatura);
            FatUst faturaUst = default(FatUst);
            try
            {
               
                irsaliye = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSIrs);
                irsaliye.OkuUst("I00000000000002", "00002");
                irsaliye.OkuKalem();
                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                faturaUst = fatura.Ust();
                faturaUst.FATIRS_NO = fatura.YeniNumara("A");
                irsaliye.Irsaliye2Fatura(fatura);

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(faturaUst);
                Marshal.ReleaseComObject(fatura);
                Marshal.ReleaseComObject(irsaliye);
                
            }
        }

        private void eArşivOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);

            try
            {
                

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtArsiv);
                eBelge.BelgeNo = "000000000000001";//Fatura no
                eBelge.DizaynNo = 2697;
                eBelge.DovizliOlustur = true;
                eBelge.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eFaturaTaslakOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            EBelge eBelge = default(EBelge);


            try
            {
               

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEFatura);
                eBelge.BelgeNo = "CLK000000000041";//Fatura no
                eBelge.DizaynKontrol = false;
                eBelge.DovizliOlustur = false;
                eBelge.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eİrsaliyeTaslakOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            EBelge eBelge = default(EBelge);


            try
            {
                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEIrs);
                eBelge.KaynakTip = TEBelgeKaynakTipi.eitIrs;
                eBelge.BelgeNo = "000000000000001";//Fatura no
                eBelge.DizaynNo = 2697;
                eBelge.FiyatBilgileriBasilsin = true;
                eBelge.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eFaturaGörüntülemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);


            try
            {

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEFatura);
                eBelge.BelgeNo = "CLK000000000041";//Fatura no
                eBelge.DizaynKontrol = false;
                eBelge.DovizliOlustur = false;
                eBelge.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eArşivGörüntülemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            EBelge eBelge = default(EBelge);



            try
            {
             


                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtArsiv);
                eBelge.EBelgeGoruntuleme("EAR2018000000041", @"C:\temp", TEBelgeBoxType.ebAll, "");

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eIrsaliyeGörüntülemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            EBelge eBelge = default(EBelge);

            try
            {
              

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEIrs);
                eBelge.EBelgeGoruntuleme("EIR2020000000008", @"C:\temp", TEBelgeBoxType.ebOutbox, "");

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eFaturaGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);


            try
            {
              

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEFatura);
                eBelge.BelgeNo = "CLK000000000066";
                eBelge.EBelgeGonderme("CLK000000000066", "Z001", TFaturaTip.ftSFat);
                eBelge.DizaynKontrol = false; eBelge.DovizliOlustur = false;

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();

            }
        }

        private void ihracatKayıtlıEFaturaGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);


            try
            {
               

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEFatura);
                eBelge.BelgeNo = "IHR000000000002";
                eBelge.Ihracat = true; // dış ticaretten girilen belgelerde set edilmeli
                eBelge.EBelgeGonderme("IHR000000000002", "E-FATDOV", TFaturaTip.ftSProforma); // dış ticaretten girilen belgelerde set edilmeli
                eBelge.DizaynKontrol = false;
                eBelge.DovizliOlustur = false;


                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eArşivGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);


            try
            {
                

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtArsiv); eBelge.BelgeNo = "EAR000000000048";
                eBelge.EBelgeGonderme("EAR000000000048", "320-01-041", TFaturaTip.ftSFat);
                eBelge.DizaynKontrol = false;
                eBelge.DovizliOlustur = false;


                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eİrsaliyeGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);


            try
            {
               
                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEIrs);
                eBelge.BelgeNo = "EIR000000000019";
                eBelge.EBelgeGonderme("EIR000000000019", "E-FAT", TFaturaTip.ftSIrs);
                eBelge.DizaynKontrol = false;
                eBelge.DovizliOlustur = false;

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {


                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                


            }
        }

        private void retKabulToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);

            try
            {
                

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEIrs);
                eBelge.EBelgeKabulRet("EIR2021000000231", TEBelgeYanitTipi.ytRet);

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void eİrsaliyeKalemKabulRetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            EBelge eBelge = default(EBelge);
            EBelgeYanitKalem eBelgeYanitKalem = default(EBelgeYanitKalem);

            try
            {
          
                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEIrs);
                eBelgeYanitKalem = eBelge.EBelgeYanitKalemYeni();
                eBelgeYanitKalem.YanitKalemSiraNo = 1;
                eBelgeYanitKalem.YanitRetMiktar = 1;
                eBelgeYanitKalem.YanitRetOlcuBr = "AD";
                eBelgeYanitKalem.YanitKalemAciklama = "test";

                eBelgeYanitKalem = eBelge.EBelgeYanitKalemYeni();
                eBelgeYanitKalem.YanitKalemSiraNo = 2;
                eBelgeYanitKalem.YanitRetMiktar = 1;
                eBelgeYanitKalem.YanitRetOlcuBr = "AD";
                eBelgeYanitKalem.YanitKalemAciklama = "test2";

                eBelge.EBelgeKalemKabul("EIR2021000000233");

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(eBelgeYanitKalem);
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void topluEBelgeOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Toplu e-fatura, e-irsaliye, e-arşiv ve e-müstahsil oluşturma desteği eklenmiştir. TopluEBelgeOlusturPrm nesnesine temelsette görünen tüm parametreler eklenmiştir. İhtiyaç olanlara aktarım yapılabilir //olarak düzenlenmiştir. Ek olarak TaslakOlustur ve TaslakGonder özelliği eklendi. 
            //TopluEBelgeOlustur methodu çalıştırıldığında ikisi de false olursa TopluEBelgeSonucGetir methoduyla sadece listeyi geri dönüyor. TaslakOlustur true olursa listedeki belgeleri için taslak oluşturuyor. //Aynı anda TaslakGonder de true gönderilirse taslak oluşturduktan sonra gönderimi de yapılıyor. Sadece zaten oluşmuş taslakları görmek ve göndermek için TopluEBelgeGonder methodunun çalıştırılması //yeterli. 

           
            EBelge eBelge = default(EBelge);
            try
            {
                

                TopluEBelgeOlusturPrm param = new TopluEBelgeOlusturPrm();
                List<TopluEBelgeSonuc> sonuc = new List<TopluEBelgeSonuc>();

                eBelge = Global.kernel.yeniEBelge(Global.sirket, TEBelgeTip.ebtEFatura);
                param.EFatBelgeTip = TEFatBelgeTip.efYurtici;
                param.EBelgeTip = TEBelgeTip.ebtEFatura;
                param.SiparisBas = true;
                //param.BasBelgeNo = "EIR000000000676";
                //param.BitBelgeNo = "EIR000000000676";
                param.BasTarihi = Convert.ToDateTime("13.11.2021");
                param.BitTarihi = Convert.ToDateTime("19.11.2021");
                param.TaslakOlustur = true;
                param.TaslakGonder = true;
                //param.DizaynSor = false;
                //param.DizaynNo = "";

                bool result = eBelge.TopluEBelgeOlustur(param);
                //bool result = eBelge.TopluEBelgeGonder(param);
                for (int i = 0; i < eBelge.TopluEBelgeSonucAdedi(); i++)
                {
                    sonuc.Add(eBelge.TopluEBelgeSonucGetir(i));
                }

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                //Marshal.ReleaseComObject(param);
                Marshal.ReleaseComObject(eBelge);
                Global.sirket.LogOff();
                
            }
        }

        private void pdfBasimToolStripMenuItem_Click(object sender, EventArgs e)
        {
           /* Kernel kernel = new Kernel();
            Sirket sirket = default(Sirket);
            Kasa kasa = default(Kasa);
            Basim netbasim = new Basim();
            string pdfName = "";
            

            try
            {
                sirket = kernel.yeniSirket(TVTTipi.vtMSSQL,
                                                sirketNetOpenX.Default.dbName,
                                                sirketNetOpenX.Default.vtUserName,
                                                sirketNetOpenX.Default.vtUserPsw,
                                                sirketNetOpenX.Default.netsisUserName,
                                                sirketNetOpenX.Default.netsisUserPsw,
                                                Convert.ToInt32(sirketNetOpenX.Default.branch));

              
                netbasim.init(kernel.yeniNetsisCore(sirket));
                pdfName = netbasim.PdfBasimYap((int)2, "FATIRS_NO='W00000000000001'", "C:\\TEMP\\PDF");

            }
            finally
            {
                Marshal.ReleaseComObject(netbasim);
                Marshal.ReleaseComObject(kasa);
                Marshal.ReleaseComObject(sirket);
                kernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(kernel); 
            } */
        }

        private void kasaBasimToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Kasa kasa = default(Kasa);
            Basim basim = default(Basim);
            try
            {
                
                basim = Global.kernel.yeniBasim(Global.sirket);
                kasa = Global.kernel.yeniKasa(Global.sirket);
                kasa.KsMas_Kod = "10"; // Kasa Kodu
                kasa.Kod = "120-04"; //Cari Kodu

                if (kasa.kayitOku(TOkumaTipi.otAc, "FISNO='24'"))
                {
                    kasa.kayitOku(TOkumaTipi.otIlk);
                }

                basim.KasaBasim(kasa, 136, TKasaBasimTipi.kbDiger);
                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
            finally
            {
                Marshal.ReleaseComObject(basim);
                Marshal.ReleaseComObject(kasa);
                
            }
        }

        private void dizaynNoİleFaturaBasımıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Basim basim = default(Basim);
            try
            {
                

                basim = Global.kernel.yeniBasim(Global.sirket);
                string faturaNo = "000000000001E39";
                string cariKod = "00002";
                basim.FaturaBasimDizaynNo(TFaturaTip.ftSSip, faturaNo, cariKod, 88);

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(basim);
                
            }
        }

        private void irsaliyeFaturaKalemBarkodBasımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Basim basim = default(Basim);
            Fatura fatura = default(Fatura);
            FatUst fatUst = default(FatUst);
            try
            {
                
                fatura = Global.kernel.yeniFatura(Global.sirket, TFaturaTip.ftSFat);
                fatura.OkuUst("R00000000002130");
                fatUst = fatura.Ust();
                fatura.OkuKalem();

                basim = Global.kernel.yeniBasim(Global.sirket);
                for (int i = 0; i <= fatura.KalemAdedi - 1; i++)
                {
                    basim.PDFPath = @"C:\temp";
                    basim.IrsFatBarkodKalemBas(fatura, 2, "BRKD1", 1);
                    MessageBox.Show(basim.PDFPath);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(fatUst);
                Marshal.ReleaseComObject(fatura);
                
            }
        }

        private void modülDizaynıİleFaturaBasımıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Basim basim = default(Basim);
            try
            {
                

                basim = Global.kernel.yeniBasim(Global.sirket);
                string faturaNo = "Z00000000000005";
                string cariKod = "00002";
                basim.FaturaBasim(TFaturaTip.ftSIrs, faturaNo, cariKod);

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(basim);
                
            }
        }

        private void dizaynNoİleYevmiyeFişiBasımıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Basim basim = default(Basim);
            try
            {
             
                basim = Global.kernel.yeniBasim(Global.sirket);
                basim.YevmiyeFisBasimDizaynNo("000000000000001", 8, 1007);

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(basim);
                
            }
        }

        private void satınAlmaTalepTeklifleştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            TalepTeklifIslem siparis = default(TalepTeklifIslem);
            MessageBox.Show(Global.kernel.Version);
            try
            {
                
                siparis = Global.kernel.YeniTalepTeklifIslem(Global.sirket, TFaturaTip.ftAlTalep);
                siparis.BelgeTipi = TFaturaTip.ftAlTeklif;
                siparis.BelgeNo = siparis.YeniNumara("R");
                //siparis.BelgelerKapatilsin = true;
                siparis.ProjeKirilimiYapilsin = true;
                siparis.kalemYeni("000000000000041", "320-01-041", 1);
                siparis.kalemYeni("000000000000041", "320-01-041", 2);

                siparis.Tekliflestir();

                MessageBox.Show(siparis.BelgeNo);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(siparis);
                
            }
        }

        private void satınAlmaTalepSiparişleştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            TalepTeklifIslem siparis = default(TalepTeklifIslem);
            MessageBox.Show(Global.kernel.Version);
            try
            {
                

                siparis = Global.kernel.YeniTalepTeklifIslem(Global.sirket, TFaturaTip.ftAlTalep);
                siparis.BelgeTipi = TFaturaTip.ftASip;
                siparis.BelgeNo = siparis.YeniNumara("R");
                //siparis.BelgelerKapatilsin = true;
                siparis.ProjeKirilimiYapilsin = true;
                siparis.kalemYeni("000000000000041", "320-01-041", 1);
                siparis.kalemYeni("000000000000041", "320-01-041", 2);

                siparis.Siparislestir();

                MessageBox.Show(siparis.BelgeNo);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(siparis);
                
            }
        }

        private void satışTalepSiparişleştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            TalepTeklifIslem siparis = default(TalepTeklifIslem);
            MessageBox.Show(Global.kernel.Version);
            try
            {
                

                siparis = Global.kernel.YeniTalepTeklifIslem(Global.sirket, TFaturaTip.ftSatTalep);
                siparis.BelgeTipi = TFaturaTip.ftSSip;
                siparis.BelgeNo = siparis.YeniNumara("R");
                //siparis.BelgelerKapatilsin = true;
                siparis.ProjeKirilimiYapilsin = true;
                siparis.kalemYeni("000000000000041", "320-01-041", 1);
                siparis.kalemYeni("000000000000041", "320-01-041", 2);

                siparis.Siparislestir();

                MessageBox.Show(siparis.BelgeNo);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(siparis);
            }
        }

        private void satışTalepTeklifleştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            TalepTeklifIslem siparis = default(TalepTeklifIslem);
            MessageBox.Show(Global.kernel.Version);
            try
            {
                

                siparis = Global.kernel.YeniTalepTeklifIslem(Global.sirket, TFaturaTip.ftSatTalep);
                siparis.BelgeTipi = TFaturaTip.ftSatTeklif;
                siparis.BelgeNo = siparis.YeniNumara("R");
                //siparis.BelgelerKapatilsin = true;
                siparis.ProjeKirilimiYapilsin = true;
                siparis.kalemYeni("000000000000041", "320-01-041", 1);
                siparis.kalemYeni("000000000000041", "320-01-041", 2);

                siparis.Tekliflestir();

                MessageBox.Show(siparis.BelgeNo);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {

                Marshal.ReleaseComObject(siparis);
               
            }
        }

        private void stokKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
            Kernel kernel = new Kernel();
            Sirket sirket = default(Sirket);
            */
            Stok StokKarti = default(Stok);
            StokTemelBilgi StokTmlBlg = default(StokTemelBilgi);
            StokEkBilgi StokEkBlg = default(StokEkBilgi);
            try
            {
                /*
                sirket = kernel.yeniSirket(TVTTipi.vtMSSQL,
                                             sirketNetOpenX.Default.dbName,
                                             sirketNetOpenX.Default.vtUserName,
                                             sirketNetOpenX.Default.vtUserPsw,
                                             sirketNetOpenX.Default.netsisUserName,
                                             sirketNetOpenX.Default.netsisUserPsw,
                                             Convert.ToInt32(sirketNetOpenX.Default.branch));
            */
                StokKarti = Global.kernel.yeniStok(Global.sirket);
                StokTmlBlg = StokKarti.TemelBilgi();
                StokEkBlg = StokKarti.EkBilgi();
                StokTmlBlg.Stok_Kodu = "STA100";
                StokTmlBlg.Stok_Adi = "Stok Adi 3";
                StokTmlBlg.KDV_Orani = 18;
                StokTmlBlg.Alis_Kdv_Kodu = 18;
                StokTmlBlg.Satis_Fiat1 = 120;
                StokTmlBlg.Satis_Fiat2 = 125;
                StokTmlBlg.Alis_Fiat1 = 110;
                StokTmlBlg.Alis_Fiat2 = 115;
                StokTmlBlg.Giris_Seri = "E";
                StokTmlBlg.Cikis_Seri = "E";
                StokTmlBlg.Pay_1 = 1;
                StokTmlBlg.Payda_1 = 1;
                StokTmlBlg.Pay2 = 1;
                StokTmlBlg.Payda2 = 1;
                StokEkBlg.Stok_Kodu = StokTmlBlg.Stok_Kodu;
                StokEkBlg.Ingisim = "Stok Name";
                StokKarti.kayitYeni();

                MessageBox.Show("Kayıt basarılı");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Marshal.ReleaseComObject(StokEkBlg);
                Marshal.ReleaseComObject(StokTmlBlg);
                Marshal.ReleaseComObject(StokKarti);
            }
        }

        private void stokDüzenleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Stok StokKarti = default(Stok);
            StokTemelBilgi StokTmlBlg = default(StokTemelBilgi);
            StokEkBilgi StokEkBlg = default(StokEkBilgi);
            try
            {
                

                StokKarti = Global.kernel.yeniStok(Global.sirket);
                StokTmlBlg = StokKarti.TemelBilgi();
                StokEkBlg = StokKarti.EkBilgi();
                StokKarti.kayitOku(TOkumaTipi.otAc, " stsabit.STOK_KODU = 'STA1004'");
                StokKarti.kayitOku(TOkumaTipi.otIlk);
                MessageBox.Show(StokTmlBlg.Stok_Kodu);
                StokTmlBlg.Satis_Fiat1 = 100;
                StokTmlBlg.Satis_Fiat2 = 105;
                StokTmlBlg.Alis_Fiat1 = 100;
                StokTmlBlg.Alis_Fiat2 = 115;
                StokKarti.kayitDuzelt();
                // StokKarti.kayitYeni();
                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                Marshal.ReleaseComObject(StokEkBlg);
                Marshal.ReleaseComObject(StokTmlBlg);
                Marshal.ReleaseComObject(StokKarti);
                
            }
        }

        private void stokSİlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Stok StokKarti = default(Stok);
            StokTemelBilgi StokTmlBlg = default(StokTemelBilgi);
            StokEkBilgi StokEkBlg = default(StokEkBilgi);
            try
            {
              
                StokKarti = Global.kernel.yeniStok(Global.sirket);
                StokTmlBlg = StokKarti.TemelBilgi();
                StokEkBlg = StokKarti.EkBilgi();
                StokKarti.kayitOku(TOkumaTipi.otAc, " stsabit.STOK_KODU = 'STA1004'");
                StokKarti.kayitOku(TOkumaTipi.otIlk);
                StokKarti.kayitSil();
                MessageBox.Show("Silme İşlemi Başarılı");
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                Marshal.ReleaseComObject(StokEkBlg);
                Marshal.ReleaseComObject(StokTmlBlg);
                Marshal.ReleaseComObject(StokKarti);
                
            }
        }

        private void stokHareketKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            StokHareket StHar = default(StokHareket);

            try
            {
                
                StHar = Global.kernel.yeniStokHareket(Global.sirket);
                StHar.Stok_Kodu = "00003";
                StHar.Sthar_Tarih = DateTime.Now;
                StHar.Sthar_Htur = "M";
                StHar.Sthar_Bf = 12;
                StHar.Sthar_Gckod = "G";
                StHar.DEPO_KODU = 1;
                StHar.Sthar_Gcmik = 6;
                StHar.Plasiyer_Kodu = "02";
                StHar.Proje_Kodu = "033";
                StHar.kayitYeni();

                MessageBox.Show("İşlem Başarılı");
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                Marshal.ReleaseComObject(StHar);
                
            }
        }

        private void reçeteliKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            StokHareket StHar = default(StokHareket);
            try
            {
                
                StHar = Global.kernel.yeniStokHareket(Global.sirket);
                StHar.Fisno = "C";
                StHar.Stok_Kodu = "MAM01";
                StHar.DEPO_KODU = 2;
                StHar.GirisDepoKodu = 2;
                StHar.Sthar_Gcmik = 2;
                StHar.Plasiyer_Kodu = "02";
                StHar.Proje_Kodu = "033";
                StHar.Sthar_Tarih = DateTime.Now;
                StHar.ReceteliKayit(TUretSonDepo.usdAktif, false, false);

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                Marshal.ReleaseComObject(StHar);
                
            }
        }

        private void kuyruktakiEPostaGönderimiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Kernel fKernel = new Kernel();
            Sirket fSirket = default(Sirket);

            try
            {
                fSirket = fKernel.yeniSirket(TVTTipi.vtMSSQL,
                                             sirketNetOpenX.Default.dbName,
                                             sirketNetOpenX.Default.vtUserName,
                                             sirketNetOpenX.Default.vtUserPsw,
                                             sirketNetOpenX.Default.netsisUserName,
                                             sirketNetOpenX.Default.netsisUserPsw,
                                             Convert.ToInt32(sirketNetOpenX.Default.branch));

                fSirket.KuyruktakiEPostalariGonder();

                MessageBox.Show("İşlem Başarılı");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

                Marshal.ReleaseComObject(fSirket);
                fKernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(fKernel);
            }
        }

        private void btnDIsconnect_Click(object sender, EventArgs e)
        {
            try
            {
                Marshal.ReleaseComObject(Global.sirket);
                Global.kernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(Global.kernel);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                MessageBox.Show("Çıkış yapıldı");
            }
        }

        private void üretimAkışKontrolYeniKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            UAK Uak = default(UAK);
            try
            {
              
                Uak = Global.kernel.yeniUAK(Global.sirket);
                Uak.UAKYeniKayit("000000000000001"); // İş emri no
                Uak.OpKodu = "MONTAJ";
                Uak.AKTIVITEKODU = "A1";
                Uak.BASLANGICTARIH = Convert.ToDateTime("2015-01-01 08:00");
                Uak.BITISTARIHSAAT = Convert.ToDateTime("2015-01-01 10:00");
                Uak.URETILENMIKTAR = 10;
                Uak.FIREMIKTAR = 1;
                Uak.IstasyonKodu = "MONTA";
                Uak.USKDEPOKODU = 100;
                Uak.MRPMAKINENO = 1;                // Makine inckeyno (TBLMRPMAKINE)
                Uak.MRPISCINO = 1;                  // Personel inckeyno (TBLMRPISCI)
                Uak.UAKKaydet();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(Uak);
                
            }
        }

        private void üretimAkışKontrolKayıtSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            UAK Uak = default(UAK);
            try
            {
               

                Uak = Global.kernel.yeniUAK(Global.sirket);
                Uak.UAKOku("000000000000001", "00000001");  // UAK kaydini getirmek icin isemri numarasi ve sira numarasi veriliyor. 
                Uak.UAKSil();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(Uak);
                
            }
        }

        private void üretimAkışKontrolKayıtDüzeltmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            UAK Uak = default(UAK);
            try
            {
                

                Uak = Global.kernel.yeniUAK(Global.sirket);
                Uak.UAKOku("000000000000001", "00000001");     // UAK kaydini getirmek icin isemri numarasi ve sira numarasi veriliyor. 
                // Bitiş tarih bilgisi düzeltiliyor
                Uak.BITISTARIHSAAT = Convert.ToDateTime("2015-01-02 12:00");
                Uak.UAKKaydet();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(Uak);
                
            }
        }

        private void üretimAkışKontrolÜretimSonuKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // incele //
            UakToUsk UAKtoUSK = default(UakToUsk);
            UretimSonuKayitPrm Param = default(UretimSonuKayitPrm);
            try
            {
                

                UAKtoUSK = Global.kernel.yeniUakToUsk(Global.sirket);

                // İslem için parametreler ayarlanıyor.
                Param = new UretimSonuKayitPrm();

                Param.FisNoSerisi = "A";
                Param.TarihAralikAlt = DateTime.Parse("21.05.2016");
                Param.TarihAralikUst = DateTime.Parse("06.06.2018");
                Param.GirisDepo = 1;
                Param.CikisDepo = 1;
                Param.HataliKayitlarPolitikasi = THataliKayitPolitikasi.hkAtla;
                Param.KayitTarihi = DateTime.Parse("13.06.2017");
                Param.VardiyaAralikAlt = 1;
                Param.VardiyaAralikUst = 4;
                Param.FislerOtomatikUretilsin = true;
                Param.IsEmriNoAralikAlt = "";
                Param.IsEmriNoAralikUst = "";
                Param.DepoOnceligi = TUAKDepoOncelik.dponHicbiri;
                Param.Oncelik = 0;
                Param.FislerIsEmriBazindaTekTekOlusturulsun = false;
                Param.OtoYariMamullerdeGirdiCikti = true;
                Param.OtoYariMamullerdeStoktanKullan = false;
                Param.MamullerOlcuBirimi = TMamulOlcuBirimi.mobOlcuBirimi1;
                Param.Bakiye = TBakiye.bkVerilenDepo;

                Boolean result = UAKtoUSK.UretimSonuKayitlariOlustur(Param);

                // Uretilen veya hata sonucu üretilemeyen USK kayıtları dolaşılıyor..
                for (int i = 0; i < UAKtoUSK.UretimSonuKayitCount(); i++)
                {
                    UretimSonuKayitSonuc UskSonuc = new UretimSonuKayitSonuc();
                    UskSonuc = UAKtoUSK.UretimSonuKayitGetir(i);
                }
                MessageBox.Show("İşlem Tamamlandı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (Param != null)
                    Marshal.ReleaseComObject(Param);
                if (UAKtoUSK != null)
                    Marshal.ReleaseComObject(UAKtoUSK);
                if (Global.sirket != null)
                    Marshal.ReleaseComObject(Global.sirket);
                Global.kernel.FreeNetsisLibrary();
                if (Global.kernel != null)
                    Marshal.ReleaseComObject(Global.kernel);
            }
        }

        private void kayıtFişNumarasıİleÜretimSonuKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Uretim uretim = default(Uretim);
            try
            {
               

                uretim = Global.kernel.yeniUretim(Global.sirket);
                uretim.UretSon_FisNo = uretim.SonFisNumarasi("C");
                uretim.UretSon_Mamul = "MAM01";
                uretim.UretSon_Tarih = DateTime.Now;
                uretim.Proje_Kodu = "033";
                uretim.UretSon_Miktar = 9;
                uretim.UretSon_Depo = 2;        //Local Depo Kodu
                uretim.I_Yedek1 = 1;            //Çikis Depo Kodu
                                                //Üretim kaydi atiliyor
                uretim.kayitYeni();
                //Stok hareketleri gerçeklestiriliyor
                uretim.kayitFisNoIleUretimSonu(uretim.UretSon_FisNo, TUretSonDepo.usdAktif, false, false);
            }
            finally
            {
                Marshal.ReleaseComObject(uretim);
               
            }
        }

        private void açıkReçeteAnaliziToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            try
            {
                

                Global.sirket.AcikReceteAnaliziCalistir("Başlangıç_Mamul", "Bitiş_Mamul", "Revizyon_Numarası", TAcikReceteBilesenSirasi.arbsKodSirasi);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
               
            }
        }

        private void reçeteSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            IReceteAna receteAna = default(IReceteAna);
            try
            {
                

                receteAna = Global.kernel.yeniReceteAna(Global.sirket);
                receteAna.kayitOku(TOkumaTipi.otAc, "ESNSTMAS.STOKKODU='MAMUL1'");
                receteAna.kayitSil();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(receteAna);
                
            }
        }

        private void işEmriYeniKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            IsEmri Isemri = default(IsEmri);
            try
            {
               
                Isemri = Global.kernel.yeniIsEmri(Global.sirket);
                Isemri.IsEmriNo = "X00000000000018";
                Isemri.Tarih = Convert.ToDateTime("2015-01-01");
                Isemri.StokKodu = "M1";
                Isemri.Miktar = 100;
                Isemri.SiparisNo = "A00000000001162";  // Müşteri sipariş no
                Isemri.SipKont = 2;                    // Müşteri sipariş sıra no
                Isemri.TeslimTarihi = Convert.ToDateTime("2015-01-02");
                Isemri.kayitYeni();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(Isemri);
                
            }
        }

        private void işEmriKayıtDüzeltToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            IIsEmri isEmri = default(IIsEmri);
            try
            {
                

                isEmri = Global.kernel.yeniIsEmri(Global.sirket);
                isEmri.kayitOku(TOkumaTipi.otAc, "ISEMRINO = \'000000000000001\'");
                isEmri.Miktar = 1000;
                isEmri.Aciklama = "test1";
                isEmri.kayitDuzelt();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(isEmri);
              
            }
        }

        private void işEmriSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            IsEmri Isemri = default(IsEmri);

            try
            {
                
                Isemri = Global.kernel.yeniIsEmri(Global.sirket);
                Isemri.kayitOku(TOkumaTipi.otAc, "ISEMRINO='000000000000001'");
                string isemrino = Isemri.IsEmriNo;
                Isemri.kayitSil();

                MessageBox.Show(isemrino + " nolu isemri silindi");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(Isemri);
               
            }
        }

        private void stokCariMüşteriSatıcıPlanlamaKayıtlarıToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           
            PlanlamaKayitlari planlamaKayit = default(PlanlamaKayitlari);
            try
            {
              
                //Planlama Tipleri: tpCari, tpStok, tpMusteriSatici
                planlamaKayit = Global.kernel.yeniPlanlamaKayitlari(Global.sirket, TStokPlanlamaKayitTip.tpStok);
                planlamaKayit.Stok_Kodu = "SER1X";
                planlamaKayit.SIPARISKARSILAMA = "M";
                planlamaKayit.SIPARISTAKIP = "H";
                planlamaKayit.PlanlamaTipi = "P";
                planlamaKayit.TEDARIKCITERCIH = "K";
                planlamaKayit.REZERV_BAK_TAKIP = "E";
                planlamaKayit.ONEMSIZ_STOK = "H";
                planlamaKayit.KESINLESEN_GUNCELLENMESIN = "H";
                planlamaKayit.SIPARIS_ONAYLI = "V";
                planlamaKayit.REC_ISEM_OLUS = "E";
                planlamaKayit.kayitYeni();
            }
            finally
            {
                Marshal.ReleaseComObject(planlamaKayit);
                
            }
        }

        private void mGPÇalıştırToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Mrp mrp = default(Mrp);
            NetStrList netStrList = new NetStrList();
            try
            {
               
                mrp = Global.kernel.yeniMrp(Global.sirket);
                
                mrp.BASTAR = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
                mrp.BITTAR = Convert.ToDateTime(DateTime.Now.AddDays(2).ToString("dd/MM/yyyy"));
                mrp.Detayli = true;
                mrp.BakKont = true;
                mrp.GnlYapKodDestek = false;
                mrp.YapKodKontrol = false;
                mrp.IsEmrHaricNoBas = string.Empty;
                mrp.IsEmrHaricNoBit = string.Empty;
                mrp.IsEmriKont = true;
                mrp.MamKont = true;
                mrp.MinStokBak = true;
                mrp.SipKont = true;
                netStrList.Add("MRP");
                mrp.SirketListesi = netStrList;
                mrp.MGPCalistir();
            }
            finally
            {
                Marshal.ReleaseComObject(netStrList);
                Marshal.ReleaseComObject(mrp);
                
            }
        }

        private void gereksinimPlanıOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Mrp mrp = new Mrp();
            mrp = Global.kernel.yeniMrp(Global.sirket);
            MrpGereksinimPlanOlusturPrm MrpParam = new MrpGereksinimPlanOlusturPrm();


            try
            {
                MrpParam.BaslangicTarihi = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
                MrpParam.BitisTarihi = Convert.ToDateTime(DateTime.Now.AddYears(1).ToString("dd/MM/yyyy"));
                MrpParam.BazTarihi = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
                MrpParam.BaslangicOncesiSipTarih = Convert.ToDateTime(DateTime.Now.AddYears(-1).ToString("dd/MM/yyyy"));
                MrpParam.PlanlamaTipi = 0;
                MrpParam.UrunTipi = TMrpUrunTipi.mutSiparisBakiye;
                MrpParam.Aciklama = "Test";
                MrpParam.BaslangicSiparisNo = "";
                MrpParam.SadeceOnayliSiparisler = false;
                MrpParam.SiparisBazindaAyrim = true;
                MrpParam.BaslangicSiparisNo = String.Empty;
                MrpParam.BitisSiparisNo = String.Empty;
                MrpParam.FabrikaKodu = "ISTANBUL";
                MrpParam.Siparis = TMrpSiparis.msHepsi;
                mrp.GereksinimPlanlamaOlustur(MrpParam);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            finally
            {

                if (mrp != null)
                    Marshal.ReleaseComObject(mrp);
                if (Global.sirket != null)
                    Marshal.ReleaseComObject(Global.sirket);
                if (Global.kernel != null)
                    Global.kernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(Global.kernel);


            }
        }

        private void malzemeGereksinimindenİşEmriOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            
            Mrp mrp = new Mrp();
            mrp = Global.kernel.yeniMrp(Global.sirket);
            IsEmriDengelemePrm IsEmrPrm = new IsEmriDengelemePrm();


          
            IsEmrPrm.CikisDepoKodu = 1;
            IsEmrPrm.GirisDepoKodu = 2;
            IsEmrPrm.CikisIcinStokDepoKullan = true;
            IsEmrPrm.GirisIcinStokDepoKullan = true;
            //IsEmrPrm.FabrikaKodu = "ISTANBUL";
            IsEmrPrm.FasonSeriKodu = String.Empty;
            IsEmrPrm.KayitTarihi = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
            IsEmrPrm.Oturum = "1";
            IsEmrPrm.ReceteSaklansin = false;
            IsEmrPrm.SiparisleriBildirimTarihineAc = false;
            IsEmrPrm.StokKodu = String.Empty;
            IsEmrPrm.YapKod = String.Empty;
            IsEmrPrm.IsEmriSeriKodu = "X";
            IsEmrPrm.MevcutMrpYedeklensin = false;
            mrp.IsEmirleriniDengele(IsEmrPrm);
            List<IsEmriDengelemeSonuc> IsEmrSonuc = new List<IsEmriDengelemeSonuc>();
            int counter = mrp.IsEmriDengelemeSonucCount();
            //Ortaya cikacak sonuc datasi dolasiliyor.
            for (int i = 0; i < counter - 1; i++)
            {
                IsEmriDengelemeSonuc Sonuc = mrp.IsEmriDengelemeSonucGetir(i);
                IsEmrSonuc.Add(Sonuc);

            }
            try
            {

            }

       finally
            {
                if (mrp != null)
                    Marshal.ReleaseComObject(mrp);
                if (Global.sirket != null)
                    Marshal.ReleaseComObject(Global.sirket);
                if (Global.kernel != null)
                    Global.kernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(Global.kernel);
            }
        }

        private void malzemeGereksinimindenTalepOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
          Mrp mrp = new Mrp();
            TalepDengelemePrm tlpdng = new TalepDengelemePrm();
            try
            {
                
                mrp = Global.kernel.yeniMrp(Global.sirket);

                tlpdng.Oturum = "1";
                tlpdng.SaticiKoduBosIhtiyaclar = TSaticiKoduBosIhtiyaclar.biBosOlanGetirilsin;
                tlpdng.TalepBaslangicNo = "T00000000000040";
                tlpdng.TalepKayitTarihi = DateTime.Now;
                tlpdng.SaticiKodu = "320-01-044";
                tlpdng.MalKabulDepoKodu = 1;

                tlpdng.MevcutMrpYedeklensin = false;

                mrp.TalepleriDengele(tlpdng);
                List<TalepDengelemeSonuc> SatSipSonuc = new List<TalepDengelemeSonuc>();
                int counter = mrp.TalepDengelemeSonucCount();

                //Ortaya cikacak sonuc datasi dolasiliyor.
                for (int i = 0; i <= counter - 1; i++)
                {
                    TalepDengelemeSonuc Sonuc = mrp.TalepDengelemeSonucGetir(i);
                    SatSipSonuc.Add(Sonuc);
                    MessageBox.Show(Sonuc.EskiMusSipNo + " " + Sonuc.EskiMusSipKont);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (mrp != null)
                    Marshal.ReleaseComObject(mrp);
                if (Global.sirket != null)
                    Marshal.ReleaseComObject(Global.sirket);
                if (Global.kernel != null)
                    Global.kernel.FreeNetsisLibrary();
                Marshal.ReleaseComObject(Global.kernel);
            }
        }

        private void mamulRezervasyonToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            MamulRezervasyonu tmpMamRez = default(MamulRezervasyonu);

            try
            {

               

                tmpMamRez = Global.kernel.yeniMamulRezervasyonu(Global.sirket, TMamulRezervasyonuIslemTipi.mritMusteriSiparisineMamRez);
                tmpMamRez.DatTarih = DateTime.Today;
                tmpMamRez.DatFiiliTarih = DateTime.Today;
                tmpMamRez.KendiDeposunaRezerveEt = true;
                tmpMamRez.GirisDepoListesi.TumunuSecVeyaKaldir(true);
                tmpMamRez.CikisDepoListesi.TumunuSecVeyaKaldir(true);


                tmpMamRez.SipTeslimTarBaslangic = DateTime.Parse("01.01.2000");
                tmpMamRez.SipTeslimTarBitis = DateTime.Parse("31.12.2020");
                tmpMamRez.SiparisSecimListesiHazirla();

                //tmpMamRez.SiparisSecimList.TumunuSecVeyaKaldir(true);

                for (int i = 0; i < tmpMamRez.SiparisSecimList.Count; i++)
                {
                    MamulRezervasyonuSiparisSecim tmpSiparis = tmpMamRez.SiparisSecimList.Get(i);
                    if (tmpSiparis.SiparisNo == "C00000000000010")
                    {
                        tmpSiparis.Secim = true;
                        tmpSiparis.RezerveEdilecekMiktar = 134;
                    }

                }
                tmpMamRez.RezervasyonOlustur();


                for (int i = 0; i < tmpMamRez.OlusanBelgelerList.Count; i++)
                {
                    MamulRezervasyonuOlusanBelge tmpOlusanBelge = tmpMamRez.OlusanBelgelerList.Get(i);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(tmpMamRez);
                
            }
        }

        private void mamulRezervasyonİptalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            MamulRezervasyonu tmpMamRez = default(MamulRezervasyonu);

            try
            {
               
                tmpMamRez = Global.kernel.yeniMamulRezervasyonu(Global.sirket, TMamulRezervasyonuIslemTipi.mritMamulRezervasyonIptali);
                tmpMamRez.DatTarih = DateTime.Today;
                tmpMamRez.DatFiiliTarih = DateTime.Today;
                tmpMamRez.KendiDeposunaRezerveEt = true;
                tmpMamRez.GirisDepoListesi.TumunuSecVeyaKaldir(true);
                //tmpMamRez.CikisDepoListesi.TumunuSecVeyaKaldir(true);
                //for (int i = 0; i < tmpMamRez.CikisDepoListesi.Count; i++)
                //{
                // MamulRezervasyonuDeposu tmpDepo = tmpMamRez.CikisDepoListesi.Get(i);
                // if (i>0)
                // tmpDepo.Secim = false;
                //}
                tmpMamRez.SipTeslimTarBaslangic = DateTime.Parse("01.01.2000");
                tmpMamRez.SipTeslimTarBitis = DateTime.Parse("31.12.2020");
                tmpMamRez.SiparisSecimListesiHazirla();
                //tmpMamRez.SiparisSecimList.TumunuSecVeyaKaldir(true);

                for (int i = 0; i < tmpMamRez.SiparisSecimList.Count; i++)
                {
                    MamulRezervasyonuSiparisSecim tmpSiparis = tmpMamRez.SiparisSecimList.Get(i);
                    if (tmpSiparis.SiparisNo == "C00000000000010")
                    {
                        tmpSiparis.Secim = true;
                    }

                }
                tmpMamRez.RezervasyonIptalEt();
                for (int i = 0; i < tmpMamRez.OlusanBelgelerList.Count; i++)
                {
                    MamulRezervasyonuOlusanBelge tmpOlusanBelge = tmpMamRez.OlusanBelgelerList.Get(i);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                Marshal.ReleaseComObject(tmpMamRez);
            }
        }

 
    }
}
