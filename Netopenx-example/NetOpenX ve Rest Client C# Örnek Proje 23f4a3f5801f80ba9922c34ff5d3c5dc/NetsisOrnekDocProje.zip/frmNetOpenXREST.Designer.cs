﻿namespace DocProje
{
    partial class grpCompantInfos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lOJİSTİKSATIŞToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fATURAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iŞLEMLERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ambarGirişFişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ambarÇıkışFişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaNumaraDeğişikliğiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dövizliFaturaKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışFaturasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışİrsaliyeKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışTeklifKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sipariştenFaturaOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.talepTeklifOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parçalıSiparişTeslimatıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFATURAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaKaydetmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaTaslakOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eFaturaGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eİRSALİYEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIrsaliyeKaydetmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIrsaliyeGöndermeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIrsaliyeGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBELGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBelgeCariGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBelgeKabulRetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBelgeKalemKabulRetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniEArsivNumaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bASIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irsaliyeFaturaBasımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irsaliyeFaturaKalemBasımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rAPORLARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tALEPTEKLİFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokHareketKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokDüzenlemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dİNAMİKDEPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dATToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.depolarArasıTransferKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hIZLITAHSİLATToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hızlıTahsilatKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hızlıTahsilatOluşturToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hızlıTahsilatSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hızlıTahsilatGetirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dIŞTİCARETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kALİTEKONTROLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kANTARTARTIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mÜHTAHSİLFATURASIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kARGOGÖNDERİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fİNANSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cARİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariBağlantıAnaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariÇağırmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cARİHAREKETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariHareketOluşturToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariHareketGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.belirliBirCariHareketiGetirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tümCariHareketleriGetirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariHareketiSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEKONTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniNumaraAlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokDekontKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bANKAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bANKAHAREKETKAYITLARIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHareketKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHareketGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHareketSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHareketGetirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bANKAHAVALEEFTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHavaleEftKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHavaleEftGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaHavaleEftSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kURToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kurKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kASAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaCariÖdemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaÇekÖdemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaÇokluKalemGirişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaMuhtelifİşlemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaTransferToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kasaBankaHareketKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çEKSENETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetOluşturToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetÇağırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetParametrelereGöreSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borçÇekiÖdentisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çekSenetTahsilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gENELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.şİRKETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kERNELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hataKoduYorumlamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tOKENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tokenAlmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yARDIMCIPROGRAMLARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kAYITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRETİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iŞEMRİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işEmriKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mRPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimPlanlamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRETİMAKIŞKONTROLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEÇETEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reçeteKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reçetedenİşEmriOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rAPORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raporÇalıştırVeKaydetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROSESKONTROLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prosesKontrolGirişiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prosesKontrolGirişiOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLANLAMAKAYITLARIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokPlanlamaKayıtlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokPlanlamaKayıtOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariPlanlamaKayıtlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sERBESTSUSKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suskKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suskKayıtOkumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suskKayıtSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suskKalemSilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ürünMaliyetOluşturmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mAKİNEBAKIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mUHASEBEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mUHASEBEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aydanAyaFişAktarımı9037ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dÖVİZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dövizKaydıOkuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dövizKaydıOluşturToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dövizKaydıSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dövizKaydıGüncellemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eNTEGREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mALİYETMUHASEBESİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAnaMenu = new System.Windows.Forms.Button();
            this.btnCıkıs = new System.Windows.Forms.Button();
            this.chkRemember = new System.Windows.Forms.CheckBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.txtServisCalismaAdresi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBranch = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtVTPassword = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSube = new System.Windows.Forms.TextBox();
            this.txtNetsisPassword = new System.Windows.Forms.TextBox();
            this.txtNetsisUserName = new System.Windows.Forms.TextBox();
            this.txtVTsifre = new System.Windows.Forms.TextBox();
            this.txtVTuserName = new System.Windows.Forms.TextBox();
            this.txtDbName = new System.Windows.Forms.TextBox();
            this.grpCompanyInfos = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.grpCompanyInfos.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lOJİSTİKSATIŞToolStripMenuItem,
            this.fİNANSToolStripMenuItem,
            this.gENELToolStripMenuItem,
            this.üRETİMToolStripMenuItem,
            this.mUHASEBEToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1275, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lOJİSTİKSATIŞToolStripMenuItem
            // 
            this.lOJİSTİKSATIŞToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fATURAToolStripMenuItem,
            this.tALEPTEKLİFToolStripMenuItem,
            this.sTOKToolStripMenuItem,
            this.dİNAMİKDEPOToolStripMenuItem,
            this.dATToolStripMenuItem,
            this.hIZLITAHSİLATToolStripMenuItem,
            this.dIŞTİCARETToolStripMenuItem,
            this.pOSToolStripMenuItem,
            this.kALİTEKONTROLToolStripMenuItem,
            this.kANTARTARTIMToolStripMenuItem,
            this.mÜHTAHSİLFATURASIToolStripMenuItem,
            this.kARGOGÖNDERİToolStripMenuItem});
            this.lOJİSTİKSATIŞToolStripMenuItem.Name = "lOJİSTİKSATIŞToolStripMenuItem";
            this.lOJİSTİKSATIŞToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.lOJİSTİKSATIŞToolStripMenuItem.Text = "LOJİSTİK - SATIŞ";
            // 
            // fATURAToolStripMenuItem
            // 
            this.fATURAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iŞLEMLERToolStripMenuItem,
            this.eFATURAToolStripMenuItem,
            this.eİRSALİYEToolStripMenuItem,
            this.eBELGEToolStripMenuItem,
            this.bASIMToolStripMenuItem,
            this.rAPORLARToolStripMenuItem});
            this.fATURAToolStripMenuItem.Name = "fATURAToolStripMenuItem";
            this.fATURAToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.fATURAToolStripMenuItem.Text = "FATURA";
            // 
            // iŞLEMLERToolStripMenuItem
            // 
            this.iŞLEMLERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faturaSilmeToolStripMenuItem,
            this.ambarGirişFişiToolStripMenuItem,
            this.ambarÇıkışFişiToolStripMenuItem,
            this.faturaNumaraDeğişikliğiToolStripMenuItem,
            this.dövizliFaturaKaydıToolStripMenuItem,
            this.satışFaturasıToolStripMenuItem,
            this.satışİrsaliyeKaydıToolStripMenuItem,
            this.satışTeklifKaydıToolStripMenuItem,
            this.sipariştenFaturaOluşturmaToolStripMenuItem,
            this.talepTeklifOkumaToolStripMenuItem,
            this.parçalıSiparişTeslimatıToolStripMenuItem,
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem,
            this.faturaOkumaToolStripMenuItem,
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem,
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem,
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem});
            this.iŞLEMLERToolStripMenuItem.Name = "iŞLEMLERToolStripMenuItem";
            this.iŞLEMLERToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.iŞLEMLERToolStripMenuItem.Text = "İŞLEMLER";
            // 
            // faturaSilmeToolStripMenuItem
            // 
            this.faturaSilmeToolStripMenuItem.Name = "faturaSilmeToolStripMenuItem";
            this.faturaSilmeToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.faturaSilmeToolStripMenuItem.Text = "Fatura Silme";
            this.faturaSilmeToolStripMenuItem.Click += new System.EventHandler(this.faturaSilmeToolStripMenuItem_Click);
            // 
            // ambarGirişFişiToolStripMenuItem
            // 
            this.ambarGirişFişiToolStripMenuItem.Name = "ambarGirişFişiToolStripMenuItem";
            this.ambarGirişFişiToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.ambarGirişFişiToolStripMenuItem.Text = "Ambar Giriş Fişi";
            this.ambarGirişFişiToolStripMenuItem.Click += new System.EventHandler(this.ambarGirişFişiToolStripMenuItem_Click);
            // 
            // ambarÇıkışFişiToolStripMenuItem
            // 
            this.ambarÇıkışFişiToolStripMenuItem.Name = "ambarÇıkışFişiToolStripMenuItem";
            this.ambarÇıkışFişiToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.ambarÇıkışFişiToolStripMenuItem.Text = "Ambar Çıkış Fişi";
            this.ambarÇıkışFişiToolStripMenuItem.Click += new System.EventHandler(this.ambarÇıkışFişiToolStripMenuItem_Click);
            // 
            // faturaNumaraDeğişikliğiToolStripMenuItem
            // 
            this.faturaNumaraDeğişikliğiToolStripMenuItem.Name = "faturaNumaraDeğişikliğiToolStripMenuItem";
            this.faturaNumaraDeğişikliğiToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.faturaNumaraDeğişikliğiToolStripMenuItem.Text = "Fatura Numara Değişikliği";
            this.faturaNumaraDeğişikliğiToolStripMenuItem.Click += new System.EventHandler(this.faturaNumaraDeğişikliğiToolStripMenuItem_Click);
            // 
            // dövizliFaturaKaydıToolStripMenuItem
            // 
            this.dövizliFaturaKaydıToolStripMenuItem.Name = "dövizliFaturaKaydıToolStripMenuItem";
            this.dövizliFaturaKaydıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.dövizliFaturaKaydıToolStripMenuItem.Text = "Dövizli Fatura Kaydı";
            this.dövizliFaturaKaydıToolStripMenuItem.Click += new System.EventHandler(this.dövizliFaturaKaydıToolStripMenuItem_Click);
            // 
            // satışFaturasıToolStripMenuItem
            // 
            this.satışFaturasıToolStripMenuItem.Name = "satışFaturasıToolStripMenuItem";
            this.satışFaturasıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.satışFaturasıToolStripMenuItem.Text = "Satış Faturası";
            this.satışFaturasıToolStripMenuItem.Click += new System.EventHandler(this.satışFaturasıToolStripMenuItem_Click);
            // 
            // satışİrsaliyeKaydıToolStripMenuItem
            // 
            this.satışİrsaliyeKaydıToolStripMenuItem.Name = "satışİrsaliyeKaydıToolStripMenuItem";
            this.satışİrsaliyeKaydıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.satışİrsaliyeKaydıToolStripMenuItem.Text = "Satış İrsaliye Kaydı";
            this.satışİrsaliyeKaydıToolStripMenuItem.Click += new System.EventHandler(this.satışİrsaliyeKaydıToolStripMenuItem_Click);
            // 
            // satışTeklifKaydıToolStripMenuItem
            // 
            this.satışTeklifKaydıToolStripMenuItem.Name = "satışTeklifKaydıToolStripMenuItem";
            this.satışTeklifKaydıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.satışTeklifKaydıToolStripMenuItem.Text = "Satış Teklif Kaydı";
            this.satışTeklifKaydıToolStripMenuItem.Click += new System.EventHandler(this.satışTeklifKaydıToolStripMenuItem_Click);
            // 
            // sipariştenFaturaOluşturmaToolStripMenuItem
            // 
            this.sipariştenFaturaOluşturmaToolStripMenuItem.Name = "sipariştenFaturaOluşturmaToolStripMenuItem";
            this.sipariştenFaturaOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.sipariştenFaturaOluşturmaToolStripMenuItem.Text = "Siparişten Fatura Oluşturma";
            this.sipariştenFaturaOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.sipariştenFaturaOluşturmaToolStripMenuItem_Click);
            // 
            // talepTeklifOkumaToolStripMenuItem
            // 
            this.talepTeklifOkumaToolStripMenuItem.Name = "talepTeklifOkumaToolStripMenuItem";
            this.talepTeklifOkumaToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.talepTeklifOkumaToolStripMenuItem.Text = "Talep -Teklif Okuma";
            this.talepTeklifOkumaToolStripMenuItem.Click += new System.EventHandler(this.talepTeklifOkumaToolStripMenuItem_Click);
            // 
            // parçalıSiparişTeslimatıToolStripMenuItem
            // 
            this.parçalıSiparişTeslimatıToolStripMenuItem.Name = "parçalıSiparişTeslimatıToolStripMenuItem";
            this.parçalıSiparişTeslimatıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.parçalıSiparişTeslimatıToolStripMenuItem.Text = "Parçalı Sipariş Teslimatı";
            this.parçalıSiparişTeslimatıToolStripMenuItem.Click += new System.EventHandler(this.parçalıSiparişTeslimatıToolStripMenuItem_Click);
            // 
            // değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem
            // 
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem.Name = "değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem";
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem.Text = "Değişken Ölçü Birimlerinin Kullanılması";
            this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem.Click += new System.EventHandler(this.değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem_Click);
            // 
            // faturaOkumaToolStripMenuItem
            // 
            this.faturaOkumaToolStripMenuItem.Name = "faturaOkumaToolStripMenuItem";
            this.faturaOkumaToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.faturaOkumaToolStripMenuItem.Text = "Fatura Okuma";
            this.faturaOkumaToolStripMenuItem.Click += new System.EventHandler(this.faturaOkumaToolStripMenuItem_Click);
            // 
            // siparişKopyalamaVers9037VeSonrasıToolStripMenuItem
            // 
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem.Name = "siparişKopyalamaVers9037VeSonrasıToolStripMenuItem";
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem.Text = "Sipariş Kopyalama - vers. 9.0.37 ve sonrası";
            this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.siparişKopyalamaVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // siparişRevizyonVers9037VeSonrasıToolStripMenuItem
            // 
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem.Name = "siparişRevizyonVers9037VeSonrasıToolStripMenuItem";
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem.Text = "Sipariş Revizyon - vers. 9.0.37 ve sonrası";
            this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.siparişRevizyonVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // halFaturasıVers9037VeSonrasıToolStripMenuItem
            // 
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem.Name = "halFaturasıVers9037VeSonrasıToolStripMenuItem";
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(369, 26);
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem.Text = "Hal Faturası - vers. 9.0.37 ve sonrası";
            this.halFaturasıVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.halFaturasıVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // eFATURAToolStripMenuItem
            // 
            this.eFATURAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eFaturaKaydetmeToolStripMenuItem,
            this.eFaturaTaslakOluşturmaToolStripMenuItem,
            this.eFaturaGöndermeToolStripMenuItem,
            this.eFaturaGörüntülemeToolStripMenuItem});
            this.eFATURAToolStripMenuItem.Name = "eFATURAToolStripMenuItem";
            this.eFATURAToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.eFATURAToolStripMenuItem.Text = "E-FATURA";
            // 
            // eFaturaKaydetmeToolStripMenuItem
            // 
            this.eFaturaKaydetmeToolStripMenuItem.Name = "eFaturaKaydetmeToolStripMenuItem";
            this.eFaturaKaydetmeToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.eFaturaKaydetmeToolStripMenuItem.Text = "E-Fatura Kaydetme";
            this.eFaturaKaydetmeToolStripMenuItem.Click += new System.EventHandler(this.eFaturaKaydetmeToolStripMenuItem_Click);
            // 
            // eFaturaTaslakOluşturmaToolStripMenuItem
            // 
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Name = "eFaturaTaslakOluşturmaToolStripMenuItem";
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Text = "E-Fatura Taslak Oluşturma";
            this.eFaturaTaslakOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.eFaturaTaslakOluşturmaToolStripMenuItem_Click);
            // 
            // eFaturaGöndermeToolStripMenuItem
            // 
            this.eFaturaGöndermeToolStripMenuItem.Name = "eFaturaGöndermeToolStripMenuItem";
            this.eFaturaGöndermeToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.eFaturaGöndermeToolStripMenuItem.Text = "E-Fatura Gönderme";
            this.eFaturaGöndermeToolStripMenuItem.Click += new System.EventHandler(this.eFaturaGöndermeToolStripMenuItem_Click);
            // 
            // eFaturaGörüntülemeToolStripMenuItem
            // 
            this.eFaturaGörüntülemeToolStripMenuItem.Name = "eFaturaGörüntülemeToolStripMenuItem";
            this.eFaturaGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.eFaturaGörüntülemeToolStripMenuItem.Text = "E-Fatura Görüntüleme";
            this.eFaturaGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.eFaturaGörüntülemeToolStripMenuItem_Click);
            // 
            // eİRSALİYEToolStripMenuItem
            // 
            this.eİRSALİYEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eIrsaliyeKaydetmeToolStripMenuItem,
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem,
            this.eIrsaliyeGöndermeToolStripMenuItem,
            this.eIrsaliyeGörüntülemeToolStripMenuItem});
            this.eİRSALİYEToolStripMenuItem.Name = "eİRSALİYEToolStripMenuItem";
            this.eİRSALİYEToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.eİRSALİYEToolStripMenuItem.Text = "E-İRSALİYE";
            // 
            // eIrsaliyeKaydetmeToolStripMenuItem
            // 
            this.eIrsaliyeKaydetmeToolStripMenuItem.Name = "eIrsaliyeKaydetmeToolStripMenuItem";
            this.eIrsaliyeKaydetmeToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.eIrsaliyeKaydetmeToolStripMenuItem.Text = "E-Irsaliye Kaydetme";
            this.eIrsaliyeKaydetmeToolStripMenuItem.Click += new System.EventHandler(this.eIrsaliyeKaydetmeToolStripMenuItem_Click);
            // 
            // eIrsaliyeTaslakOluşturmaToolStripMenuItem
            // 
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem.Name = "eIrsaliyeTaslakOluşturmaToolStripMenuItem";
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem.Text = "E-Irsaliye Taslak Oluşturma";
            this.eIrsaliyeTaslakOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.eIrsaliyeTaslakOluşturmaToolStripMenuItem_Click);
            // 
            // eIrsaliyeGöndermeToolStripMenuItem
            // 
            this.eIrsaliyeGöndermeToolStripMenuItem.Name = "eIrsaliyeGöndermeToolStripMenuItem";
            this.eIrsaliyeGöndermeToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.eIrsaliyeGöndermeToolStripMenuItem.Text = "E-Irsaliye Gönderme";
            this.eIrsaliyeGöndermeToolStripMenuItem.Click += new System.EventHandler(this.eIrsaliyeGöndermeToolStripMenuItem_Click);
            // 
            // eIrsaliyeGörüntülemeToolStripMenuItem
            // 
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Name = "eIrsaliyeGörüntülemeToolStripMenuItem";
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Text = "E-Irsaliye Görüntüleme";
            this.eIrsaliyeGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.eIrsaliyeGörüntülemeToolStripMenuItem_Click);
            // 
            // eBELGEToolStripMenuItem
            // 
            this.eBELGEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eBelgeCariGüncelleToolStripMenuItem,
            this.eBelgeKabulRetToolStripMenuItem,
            this.eBelgeKalemKabulRetToolStripMenuItem,
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem,
            this.yeniEArsivNumaraToolStripMenuItem});
            this.eBELGEToolStripMenuItem.Name = "eBELGEToolStripMenuItem";
            this.eBELGEToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.eBELGEToolStripMenuItem.Text = "E-BELGE";
            // 
            // eBelgeCariGüncelleToolStripMenuItem
            // 
            this.eBelgeCariGüncelleToolStripMenuItem.Name = "eBelgeCariGüncelleToolStripMenuItem";
            this.eBelgeCariGüncelleToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.eBelgeCariGüncelleToolStripMenuItem.Text = "E-Belge Cari Güncelle";
            this.eBelgeCariGüncelleToolStripMenuItem.Click += new System.EventHandler(this.eBelgeCariGüncelleToolStripMenuItem_Click);
            // 
            // eBelgeKabulRetToolStripMenuItem
            // 
            this.eBelgeKabulRetToolStripMenuItem.Name = "eBelgeKabulRetToolStripMenuItem";
            this.eBelgeKabulRetToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.eBelgeKabulRetToolStripMenuItem.Text = "E-Belge Kabul/Ret";
            this.eBelgeKabulRetToolStripMenuItem.Click += new System.EventHandler(this.eBelgeKabulRetToolStripMenuItem_Click);
            // 
            // eBelgeKalemKabulRetToolStripMenuItem
            // 
            this.eBelgeKalemKabulRetToolStripMenuItem.Name = "eBelgeKalemKabulRetToolStripMenuItem";
            this.eBelgeKalemKabulRetToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.eBelgeKalemKabulRetToolStripMenuItem.Text = "E-Belge Kalem Kabul/Ret";
            this.eBelgeKalemKabulRetToolStripMenuItem.Click += new System.EventHandler(this.eBelgeKalemKabulRetToolStripMenuItem_Click);
            // 
            // eBelgeİptalFaturasıOluşturToolStripMenuItem
            // 
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem.Name = "eBelgeİptalFaturasıOluşturToolStripMenuItem";
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem.Text = "E-Belge İptal Faturası Oluştur";
            this.eBelgeİptalFaturasıOluşturToolStripMenuItem.Click += new System.EventHandler(this.eBelgeİptalFaturasıOluşturToolStripMenuItem_Click);
            // 
            // yeniEArsivNumaraToolStripMenuItem
            // 
            this.yeniEArsivNumaraToolStripMenuItem.Name = "yeniEArsivNumaraToolStripMenuItem";
            this.yeniEArsivNumaraToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.yeniEArsivNumaraToolStripMenuItem.Text = "Yeni EArsiv Numara";
            this.yeniEArsivNumaraToolStripMenuItem.Click += new System.EventHandler(this.yeniEArsivNumaraToolStripMenuItem_Click);
            // 
            // bASIMToolStripMenuItem
            // 
            this.bASIMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.irsaliyeFaturaBasımToolStripMenuItem,
            this.irsaliyeFaturaKalemBasımToolStripMenuItem});
            this.bASIMToolStripMenuItem.Name = "bASIMToolStripMenuItem";
            this.bASIMToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.bASIMToolStripMenuItem.Text = "BASIM";
            // 
            // irsaliyeFaturaBasımToolStripMenuItem
            // 
            this.irsaliyeFaturaBasımToolStripMenuItem.Name = "irsaliyeFaturaBasımToolStripMenuItem";
            this.irsaliyeFaturaBasımToolStripMenuItem.Size = new System.Drawing.Size(282, 26);
            this.irsaliyeFaturaBasımToolStripMenuItem.Text = "İrsaliye / Fatura Basım";
            this.irsaliyeFaturaBasımToolStripMenuItem.Click += new System.EventHandler(this.irsaliyeFaturaBasımToolStripMenuItem_Click);
            // 
            // irsaliyeFaturaKalemBasımToolStripMenuItem
            // 
            this.irsaliyeFaturaKalemBasımToolStripMenuItem.Name = "irsaliyeFaturaKalemBasımToolStripMenuItem";
            this.irsaliyeFaturaKalemBasımToolStripMenuItem.Size = new System.Drawing.Size(282, 26);
            this.irsaliyeFaturaKalemBasımToolStripMenuItem.Text = "İrsaliye / Fatura Kalem Basım";
            this.irsaliyeFaturaKalemBasımToolStripMenuItem.Click += new System.EventHandler(this.irsaliyeFaturaKalemBasımToolStripMenuItem_Click);
            // 
            // rAPORLARToolStripMenuItem
            // 
            this.rAPORLARToolStripMenuItem.Name = "rAPORLARToolStripMenuItem";
            this.rAPORLARToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.rAPORLARToolStripMenuItem.Text = "RAPORLAR";
            // 
            // tALEPTEKLİFToolStripMenuItem
            // 
            this.tALEPTEKLİFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem,
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem,
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem});
            this.tALEPTEKLİFToolStripMenuItem.Name = "tALEPTEKLİFToolStripMenuItem";
            this.tALEPTEKLİFToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.tALEPTEKLİFToolStripMenuItem.Text = "TALEP - TEKLİF";
            // 
            // talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem
            // 
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem.Name = "talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem";
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(496, 26);
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem.Text = "Talep/Teklif Yeni Numara - Vers. 9.0.37 ve sonrası";
            this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem
            // 
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem.Name = "satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem";
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(496, 26);
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem.Text = "Satış/Satın Alma Talep Teklifleştirme - Vers. 9.0.37 ve sonrası";
            this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem
            // 
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem.Name = "satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem";
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(496, 26);
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem.Text = "Satış/Satın Alma Teklif Siparişleştirme - Vers. 9.0.37 ve sonrası";
            this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // sTOKToolStripMenuItem
            // 
            this.sTOKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokKaydıToolStripMenuItem,
            this.stokHareketKaydıToolStripMenuItem,
            this.stokDüzenlemeToolStripMenuItem});
            this.sTOKToolStripMenuItem.Name = "sTOKToolStripMenuItem";
            this.sTOKToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.sTOKToolStripMenuItem.Text = "STOK";
            // 
            // stokKaydıToolStripMenuItem
            // 
            this.stokKaydıToolStripMenuItem.Name = "stokKaydıToolStripMenuItem";
            this.stokKaydıToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokKaydıToolStripMenuItem.Text = "Stok Kaydı";
            this.stokKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokKaydıToolStripMenuItem_Click);
            // 
            // stokHareketKaydıToolStripMenuItem
            // 
            this.stokHareketKaydıToolStripMenuItem.Name = "stokHareketKaydıToolStripMenuItem";
            this.stokHareketKaydıToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokHareketKaydıToolStripMenuItem.Text = "Stok Hareket Kaydı";
            this.stokHareketKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokHareketKaydıToolStripMenuItem_Click);
            // 
            // stokDüzenlemeToolStripMenuItem
            // 
            this.stokDüzenlemeToolStripMenuItem.Name = "stokDüzenlemeToolStripMenuItem";
            this.stokDüzenlemeToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.stokDüzenlemeToolStripMenuItem.Text = "Stok Düzenleme";
            this.stokDüzenlemeToolStripMenuItem.Click += new System.EventHandler(this.stokDüzenlemeToolStripMenuItem_Click);
            // 
            // dİNAMİKDEPOToolStripMenuItem
            // 
            this.dİNAMİKDEPOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem,
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem});
            this.dİNAMİKDEPOToolStripMenuItem.Name = "dİNAMİKDEPOToolStripMenuItem";
            this.dİNAMİKDEPOToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.dİNAMİKDEPOToolStripMenuItem.Text = "DİNAMİK DEPO";
            // 
            // dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem
            // 
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem.Name = "dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem";
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem.Size = new System.Drawing.Size(390, 26);
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem.Text = "Dinamik Depo Hareket Girişinde Seri Desteği";
            this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem.Click += new System.EventHandler(this.dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem_Click);
            // 
            // dinamikDepoHücreYerleştirmeToolStripMenuItem
            // 
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem.Name = "dinamikDepoHücreYerleştirmeToolStripMenuItem";
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem.Size = new System.Drawing.Size(390, 26);
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem.Text = "Dinamik Depo Hücre Yerleştirme";
            this.dinamikDepoHücreYerleştirmeToolStripMenuItem.Click += new System.EventHandler(this.dinamikDepoHücreYerleştirmeToolStripMenuItem_Click);
            // 
            // dATToolStripMenuItem
            // 
            this.dATToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.depolarArasıTransferKaydıToolStripMenuItem,
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem});
            this.dATToolStripMenuItem.Name = "dATToolStripMenuItem";
            this.dATToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.dATToolStripMenuItem.Text = "DAT";
            // 
            // depolarArasıTransferKaydıToolStripMenuItem
            // 
            this.depolarArasıTransferKaydıToolStripMenuItem.Name = "depolarArasıTransferKaydıToolStripMenuItem";
            this.depolarArasıTransferKaydıToolStripMenuItem.Size = new System.Drawing.Size(319, 26);
            this.depolarArasıTransferKaydıToolStripMenuItem.Text = "Depolar Arası Transfer Kaydı";
            this.depolarArasıTransferKaydıToolStripMenuItem.Click += new System.EventHandler(this.depolarArasıTransferKaydıToolStripMenuItem_Click);
            // 
            // lokalDepolarArasıTransferKaydıToolStripMenuItem
            // 
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem.Name = "lokalDepolarArasıTransferKaydıToolStripMenuItem";
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem.Size = new System.Drawing.Size(319, 26);
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem.Text = "Lokal Depolar Arası Transfer Kaydı";
            this.lokalDepolarArasıTransferKaydıToolStripMenuItem.Click += new System.EventHandler(this.lokalDepolarArasıTransferKaydıToolStripMenuItem_Click);
            // 
            // hIZLITAHSİLATToolStripMenuItem
            // 
            this.hIZLITAHSİLATToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hızlıTahsilatKaydıToolStripMenuItem,
            this.hızlıTahsilatOluşturToolStripMenuItem,
            this.hızlıTahsilatSilToolStripMenuItem,
            this.hızlıTahsilatGetirToolStripMenuItem});
            this.hIZLITAHSİLATToolStripMenuItem.Name = "hIZLITAHSİLATToolStripMenuItem";
            this.hIZLITAHSİLATToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.hIZLITAHSİLATToolStripMenuItem.Text = "HIZLI TAHSİLAT";
            // 
            // hızlıTahsilatKaydıToolStripMenuItem
            // 
            this.hızlıTahsilatKaydıToolStripMenuItem.Name = "hızlıTahsilatKaydıToolStripMenuItem";
            this.hızlıTahsilatKaydıToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.hızlıTahsilatKaydıToolStripMenuItem.Text = "Hızlı Tahsilat Kaydı";
            this.hızlıTahsilatKaydıToolStripMenuItem.Click += new System.EventHandler(this.hızlıTahsilatKaydıToolStripMenuItem_Click);
            // 
            // hızlıTahsilatOluşturToolStripMenuItem
            // 
            this.hızlıTahsilatOluşturToolStripMenuItem.Name = "hızlıTahsilatOluşturToolStripMenuItem";
            this.hızlıTahsilatOluşturToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.hızlıTahsilatOluşturToolStripMenuItem.Text = "Hızlı Tahsilat oluştur";
            this.hızlıTahsilatOluşturToolStripMenuItem.Click += new System.EventHandler(this.hızlıTahsilatOluşturToolStripMenuItem_Click);
            // 
            // hızlıTahsilatSilToolStripMenuItem
            // 
            this.hızlıTahsilatSilToolStripMenuItem.Name = "hızlıTahsilatSilToolStripMenuItem";
            this.hızlıTahsilatSilToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.hızlıTahsilatSilToolStripMenuItem.Text = "Hızlı Tahsilat Sil";
            this.hızlıTahsilatSilToolStripMenuItem.Click += new System.EventHandler(this.hızlıTahsilatSilToolStripMenuItem_Click);
            // 
            // hızlıTahsilatGetirToolStripMenuItem
            // 
            this.hızlıTahsilatGetirToolStripMenuItem.Name = "hızlıTahsilatGetirToolStripMenuItem";
            this.hızlıTahsilatGetirToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.hızlıTahsilatGetirToolStripMenuItem.Text = "Hızlı Tahsilat Getir";
            this.hızlıTahsilatGetirToolStripMenuItem.Click += new System.EventHandler(this.hızlıTahsilatGetirToolStripMenuItem_Click);
            // 
            // dIŞTİCARETToolStripMenuItem
            // 
            this.dIŞTİCARETToolStripMenuItem.Name = "dIŞTİCARETToolStripMenuItem";
            this.dIŞTİCARETToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.dIŞTİCARETToolStripMenuItem.Text = "DIŞ TİCARET";
            // 
            // pOSToolStripMenuItem
            // 
            this.pOSToolStripMenuItem.Name = "pOSToolStripMenuItem";
            this.pOSToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.pOSToolStripMenuItem.Text = "P.O.S";
            // 
            // kALİTEKONTROLToolStripMenuItem
            // 
            this.kALİTEKONTROLToolStripMenuItem.Name = "kALİTEKONTROLToolStripMenuItem";
            this.kALİTEKONTROLToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.kALİTEKONTROLToolStripMenuItem.Text = "KALİTE KONTROL";
            // 
            // kANTARTARTIMToolStripMenuItem
            // 
            this.kANTARTARTIMToolStripMenuItem.Name = "kANTARTARTIMToolStripMenuItem";
            this.kANTARTARTIMToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.kANTARTARTIMToolStripMenuItem.Text = "KANTAR - TARTIM";
            // 
            // mÜHTAHSİLFATURASIToolStripMenuItem
            // 
            this.mÜHTAHSİLFATURASIToolStripMenuItem.Name = "mÜHTAHSİLFATURASIToolStripMenuItem";
            this.mÜHTAHSİLFATURASIToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.mÜHTAHSİLFATURASIToolStripMenuItem.Text = "MÜHTAHSİL FATURASI";
            // 
            // kARGOGÖNDERİToolStripMenuItem
            // 
            this.kARGOGÖNDERİToolStripMenuItem.Name = "kARGOGÖNDERİToolStripMenuItem";
            this.kARGOGÖNDERİToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.kARGOGÖNDERİToolStripMenuItem.Text = "KARGO GÖNDERİ";
            // 
            // fİNANSToolStripMenuItem
            // 
            this.fİNANSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cARİToolStripMenuItem,
            this.cARİHAREKETToolStripMenuItem,
            this.dEKONTToolStripMenuItem,
            this.bANKAToolStripMenuItem,
            this.kASAToolStripMenuItem,
            this.çEKSENETToolStripMenuItem});
            this.fİNANSToolStripMenuItem.Name = "fİNANSToolStripMenuItem";
            this.fİNANSToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.fİNANSToolStripMenuItem.Text = "FİNANS";
            // 
            // cARİToolStripMenuItem
            // 
            this.cARİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariBağlantıAnaToolStripMenuItem,
            this.cariÇağırmaToolStripMenuItem,
            this.cariGüncelleToolStripMenuItem,
            this.cariKayıtToolStripMenuItem,
            this.cariSilToolStripMenuItem,
            this.cariOkumaToolStripMenuItem});
            this.cARİToolStripMenuItem.Name = "cARİToolStripMenuItem";
            this.cARİToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cARİToolStripMenuItem.Text = "CARİ";
            // 
            // cariBağlantıAnaToolStripMenuItem
            // 
            this.cariBağlantıAnaToolStripMenuItem.Name = "cariBağlantıAnaToolStripMenuItem";
            this.cariBağlantıAnaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariBağlantıAnaToolStripMenuItem.Text = "Cari-Bağlantı ana";
            this.cariBağlantıAnaToolStripMenuItem.Click += new System.EventHandler(this.cariBağlantıAnaToolStripMenuItem_Click);
            // 
            // cariÇağırmaToolStripMenuItem
            // 
            this.cariÇağırmaToolStripMenuItem.Name = "cariÇağırmaToolStripMenuItem";
            this.cariÇağırmaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariÇağırmaToolStripMenuItem.Text = "Cari Çağırma";
            this.cariÇağırmaToolStripMenuItem.Click += new System.EventHandler(this.cariÇağırmaToolStripMenuItem_Click);
            // 
            // cariGüncelleToolStripMenuItem
            // 
            this.cariGüncelleToolStripMenuItem.Name = "cariGüncelleToolStripMenuItem";
            this.cariGüncelleToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariGüncelleToolStripMenuItem.Text = "Cari Güncelle";
            this.cariGüncelleToolStripMenuItem.Click += new System.EventHandler(this.cariGüncelleToolStripMenuItem_Click);
            // 
            // cariKayıtToolStripMenuItem
            // 
            this.cariKayıtToolStripMenuItem.Name = "cariKayıtToolStripMenuItem";
            this.cariKayıtToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariKayıtToolStripMenuItem.Text = "Cari Kayıt";
            this.cariKayıtToolStripMenuItem.Click += new System.EventHandler(this.cariKayıtToolStripMenuItem_Click);
            // 
            // cariSilToolStripMenuItem
            // 
            this.cariSilToolStripMenuItem.Name = "cariSilToolStripMenuItem";
            this.cariSilToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariSilToolStripMenuItem.Text = "Cari Sil";
            this.cariSilToolStripMenuItem.Click += new System.EventHandler(this.cariSilToolStripMenuItem_Click);
            // 
            // cariOkumaToolStripMenuItem
            // 
            this.cariOkumaToolStripMenuItem.Name = "cariOkumaToolStripMenuItem";
            this.cariOkumaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cariOkumaToolStripMenuItem.Text = "Cari Okuma";
            this.cariOkumaToolStripMenuItem.Click += new System.EventHandler(this.cariOkumaToolStripMenuItem_Click);
            // 
            // cARİHAREKETToolStripMenuItem
            // 
            this.cARİHAREKETToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariHareketOluşturToolStripMenuItem,
            this.cariHareketGüncelleToolStripMenuItem,
            this.belirliBirCariHareketiGetirToolStripMenuItem,
            this.tümCariHareketleriGetirToolStripMenuItem,
            this.cariHareketiSilToolStripMenuItem});
            this.cARİHAREKETToolStripMenuItem.Name = "cARİHAREKETToolStripMenuItem";
            this.cARİHAREKETToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cARİHAREKETToolStripMenuItem.Text = "CARİ HAREKET";
            // 
            // cariHareketOluşturToolStripMenuItem
            // 
            this.cariHareketOluşturToolStripMenuItem.Name = "cariHareketOluşturToolStripMenuItem";
            this.cariHareketOluşturToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.cariHareketOluşturToolStripMenuItem.Text = "Cari Hareket Oluştur";
            this.cariHareketOluşturToolStripMenuItem.Click += new System.EventHandler(this.cariHareketOluşturToolStripMenuItem_Click);
            // 
            // cariHareketGüncelleToolStripMenuItem
            // 
            this.cariHareketGüncelleToolStripMenuItem.Name = "cariHareketGüncelleToolStripMenuItem";
            this.cariHareketGüncelleToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.cariHareketGüncelleToolStripMenuItem.Text = "Cari Hareket Güncelle";
            this.cariHareketGüncelleToolStripMenuItem.Click += new System.EventHandler(this.cariHareketGüncelleToolStripMenuItem_Click);
            // 
            // belirliBirCariHareketiGetirToolStripMenuItem
            // 
            this.belirliBirCariHareketiGetirToolStripMenuItem.Name = "belirliBirCariHareketiGetirToolStripMenuItem";
            this.belirliBirCariHareketiGetirToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.belirliBirCariHareketiGetirToolStripMenuItem.Text = "Belirli bir Cari Hareketi Getir";
            this.belirliBirCariHareketiGetirToolStripMenuItem.Click += new System.EventHandler(this.belirliBirCariHareketiGetirToolStripMenuItem_Click);
            // 
            // tümCariHareketleriGetirToolStripMenuItem
            // 
            this.tümCariHareketleriGetirToolStripMenuItem.Name = "tümCariHareketleriGetirToolStripMenuItem";
            this.tümCariHareketleriGetirToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.tümCariHareketleriGetirToolStripMenuItem.Text = "Tüm Cari Hareketleri Getir";
            this.tümCariHareketleriGetirToolStripMenuItem.Click += new System.EventHandler(this.tümCariHareketleriGetirToolStripMenuItem_Click);
            // 
            // cariHareketiSilToolStripMenuItem
            // 
            this.cariHareketiSilToolStripMenuItem.Name = "cariHareketiSilToolStripMenuItem";
            this.cariHareketiSilToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.cariHareketiSilToolStripMenuItem.Text = "Cari Hareketi Sil";
            this.cariHareketiSilToolStripMenuItem.Click += new System.EventHandler(this.cariHareketiSilToolStripMenuItem_Click);
            // 
            // dEKONTToolStripMenuItem
            // 
            this.dEKONTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yeniNumaraAlToolStripMenuItem,
            this.cariDekontKaydıToolStripMenuItem,
            this.stokDekontKaydıToolStripMenuItem});
            this.dEKONTToolStripMenuItem.Name = "dEKONTToolStripMenuItem";
            this.dEKONTToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.dEKONTToolStripMenuItem.Text = "DEKONT";
            // 
            // yeniNumaraAlToolStripMenuItem
            // 
            this.yeniNumaraAlToolStripMenuItem.Name = "yeniNumaraAlToolStripMenuItem";
            this.yeniNumaraAlToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.yeniNumaraAlToolStripMenuItem.Text = "Yeni Numara Al";
            this.yeniNumaraAlToolStripMenuItem.Click += new System.EventHandler(this.yeniNumaraAlToolStripMenuItem_Click);
            // 
            // cariDekontKaydıToolStripMenuItem
            // 
            this.cariDekontKaydıToolStripMenuItem.Name = "cariDekontKaydıToolStripMenuItem";
            this.cariDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.cariDekontKaydıToolStripMenuItem.Text = "Cari Dekont Kaydı";
            this.cariDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.cariDekontKaydıToolStripMenuItem_Click);
            // 
            // stokDekontKaydıToolStripMenuItem
            // 
            this.stokDekontKaydıToolStripMenuItem.Name = "stokDekontKaydıToolStripMenuItem";
            this.stokDekontKaydıToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.stokDekontKaydıToolStripMenuItem.Text = "Stok Dekont Kaydı";
            this.stokDekontKaydıToolStripMenuItem.Click += new System.EventHandler(this.stokDekontKaydıToolStripMenuItem_Click);
            // 
            // bANKAToolStripMenuItem
            // 
            this.bANKAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bANKAHAREKETKAYITLARIToolStripMenuItem,
            this.bANKAHAVALEEFTToolStripMenuItem,
            this.kURToolStripMenuItem});
            this.bANKAToolStripMenuItem.Name = "bANKAToolStripMenuItem";
            this.bANKAToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.bANKAToolStripMenuItem.Text = "BANKA";
            // 
            // bANKAHAREKETKAYITLARIToolStripMenuItem
            // 
            this.bANKAHAREKETKAYITLARIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankaHareketKayıtToolStripMenuItem,
            this.bankaHareketGüncelleToolStripMenuItem,
            this.bankaHareketSilToolStripMenuItem,
            this.bankaHareketGetirToolStripMenuItem});
            this.bANKAHAREKETKAYITLARIToolStripMenuItem.Name = "bANKAHAREKETKAYITLARIToolStripMenuItem";
            this.bANKAHAREKETKAYITLARIToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.bANKAHAREKETKAYITLARIToolStripMenuItem.Text = "BANKA HAREKET KAYITLARI";
            // 
            // bankaHareketKayıtToolStripMenuItem
            // 
            this.bankaHareketKayıtToolStripMenuItem.Name = "bankaHareketKayıtToolStripMenuItem";
            this.bankaHareketKayıtToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.bankaHareketKayıtToolStripMenuItem.Text = "Banka Hareket Kayıt";
            // 
            // bankaHareketGüncelleToolStripMenuItem
            // 
            this.bankaHareketGüncelleToolStripMenuItem.Name = "bankaHareketGüncelleToolStripMenuItem";
            this.bankaHareketGüncelleToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.bankaHareketGüncelleToolStripMenuItem.Text = "Banka Hareket Güncelle";
            // 
            // bankaHareketSilToolStripMenuItem
            // 
            this.bankaHareketSilToolStripMenuItem.Name = "bankaHareketSilToolStripMenuItem";
            this.bankaHareketSilToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.bankaHareketSilToolStripMenuItem.Text = "Banka Hareket Sil";
            // 
            // bankaHareketGetirToolStripMenuItem
            // 
            this.bankaHareketGetirToolStripMenuItem.Name = "bankaHareketGetirToolStripMenuItem";
            this.bankaHareketGetirToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.bankaHareketGetirToolStripMenuItem.Text = "Banka Hareket Getir";
            // 
            // bANKAHAVALEEFTToolStripMenuItem
            // 
            this.bANKAHAVALEEFTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankaHavaleEftKayıtToolStripMenuItem,
            this.bankaHavaleEftGüncelleToolStripMenuItem,
            this.bankaHavaleEftSilToolStripMenuItem});
            this.bANKAHAVALEEFTToolStripMenuItem.Name = "bANKAHAVALEEFTToolStripMenuItem";
            this.bANKAHAVALEEFTToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.bANKAHAVALEEFTToolStripMenuItem.Text = "BANKA HAVALE - EFT";
            // 
            // bankaHavaleEftKayıtToolStripMenuItem
            // 
            this.bankaHavaleEftKayıtToolStripMenuItem.Name = "bankaHavaleEftKayıtToolStripMenuItem";
            this.bankaHavaleEftKayıtToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.bankaHavaleEftKayıtToolStripMenuItem.Text = "Banka Havale/Eft Kayıt";
            this.bankaHavaleEftKayıtToolStripMenuItem.Click += new System.EventHandler(this.bankaHavaleEftKayıtToolStripMenuItem_Click);
            // 
            // bankaHavaleEftGüncelleToolStripMenuItem
            // 
            this.bankaHavaleEftGüncelleToolStripMenuItem.Name = "bankaHavaleEftGüncelleToolStripMenuItem";
            this.bankaHavaleEftGüncelleToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.bankaHavaleEftGüncelleToolStripMenuItem.Text = "Banka Havale/Eft Güncelle";
            this.bankaHavaleEftGüncelleToolStripMenuItem.Click += new System.EventHandler(this.bankaHavaleEftGüncelleToolStripMenuItem_Click);
            // 
            // bankaHavaleEftSilToolStripMenuItem
            // 
            this.bankaHavaleEftSilToolStripMenuItem.Name = "bankaHavaleEftSilToolStripMenuItem";
            this.bankaHavaleEftSilToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.bankaHavaleEftSilToolStripMenuItem.Text = "Banka Havale/Eft Sil";
            this.bankaHavaleEftSilToolStripMenuItem.Click += new System.EventHandler(this.bankaHavaleEftSilToolStripMenuItem_Click);
            // 
            // kURToolStripMenuItem
            // 
            this.kURToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kurKaydıToolStripMenuItem});
            this.kURToolStripMenuItem.Name = "kURToolStripMenuItem";
            this.kURToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.kURToolStripMenuItem.Text = "KUR";
            // 
            // kurKaydıToolStripMenuItem
            // 
            this.kurKaydıToolStripMenuItem.Name = "kurKaydıToolStripMenuItem";
            this.kurKaydıToolStripMenuItem.Size = new System.Drawing.Size(155, 26);
            this.kurKaydıToolStripMenuItem.Text = "Kur Kaydı";
            this.kurKaydıToolStripMenuItem.Click += new System.EventHandler(this.kurKaydıToolStripMenuItem_Click);
            // 
            // kASAToolStripMenuItem
            // 
            this.kASAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kasaCariÖdemeToolStripMenuItem,
            this.kasaÇekÖdemeToolStripMenuItem,
            this.kasaÇokluKalemGirişiToolStripMenuItem,
            this.kasaMuhtelifİşlemToolStripMenuItem,
            this.kasaTransferToolStripMenuItem,
            this.kasaBankaHareketKaydıToolStripMenuItem});
            this.kASAToolStripMenuItem.Name = "kASAToolStripMenuItem";
            this.kASAToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.kASAToolStripMenuItem.Text = "KASA";
            // 
            // kasaCariÖdemeToolStripMenuItem
            // 
            this.kasaCariÖdemeToolStripMenuItem.Name = "kasaCariÖdemeToolStripMenuItem";
            this.kasaCariÖdemeToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaCariÖdemeToolStripMenuItem.Text = "Kasa Cari Ödeme";
            this.kasaCariÖdemeToolStripMenuItem.Click += new System.EventHandler(this.kasaCariÖdemeToolStripMenuItem_Click);
            // 
            // kasaÇekÖdemeToolStripMenuItem
            // 
            this.kasaÇekÖdemeToolStripMenuItem.Name = "kasaÇekÖdemeToolStripMenuItem";
            this.kasaÇekÖdemeToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaÇekÖdemeToolStripMenuItem.Text = "Kasa Çek Ödeme";
            this.kasaÇekÖdemeToolStripMenuItem.Click += new System.EventHandler(this.kasaÇekÖdemeToolStripMenuItem_Click);
            // 
            // kasaÇokluKalemGirişiToolStripMenuItem
            // 
            this.kasaÇokluKalemGirişiToolStripMenuItem.Name = "kasaÇokluKalemGirişiToolStripMenuItem";
            this.kasaÇokluKalemGirişiToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaÇokluKalemGirişiToolStripMenuItem.Text = "Kasa Çoklu Kalem Girişi";
            this.kasaÇokluKalemGirişiToolStripMenuItem.Click += new System.EventHandler(this.kasaÇokluKalemGirişiToolStripMenuItem_Click);
            // 
            // kasaMuhtelifİşlemToolStripMenuItem
            // 
            this.kasaMuhtelifİşlemToolStripMenuItem.Name = "kasaMuhtelifİşlemToolStripMenuItem";
            this.kasaMuhtelifİşlemToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaMuhtelifİşlemToolStripMenuItem.Text = "Kasa Muhtelif İşlem";
            this.kasaMuhtelifİşlemToolStripMenuItem.Click += new System.EventHandler(this.kasaMuhtelifİşlemToolStripMenuItem_Click);
            // 
            // kasaTransferToolStripMenuItem
            // 
            this.kasaTransferToolStripMenuItem.Name = "kasaTransferToolStripMenuItem";
            this.kasaTransferToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaTransferToolStripMenuItem.Text = "Kasa Transfer";
            this.kasaTransferToolStripMenuItem.Click += new System.EventHandler(this.kasaTransferToolStripMenuItem_Click);
            // 
            // kasaBankaHareketKaydıToolStripMenuItem
            // 
            this.kasaBankaHareketKaydıToolStripMenuItem.Name = "kasaBankaHareketKaydıToolStripMenuItem";
            this.kasaBankaHareketKaydıToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.kasaBankaHareketKaydıToolStripMenuItem.Text = "Kasa Banka Hareket Kaydı";
            this.kasaBankaHareketKaydıToolStripMenuItem.Click += new System.EventHandler(this.kasaBankaHareketKaydıToolStripMenuItem_Click);
            // 
            // çEKSENETToolStripMenuItem
            // 
            this.çEKSENETToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.çekSenetOluşturToolStripMenuItem,
            this.çekSenetÇağırToolStripMenuItem,
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem,
            this.çekSenetParametrelereGöreSilToolStripMenuItem,
            this.çekSenetSilToolStripMenuItem,
            this.borçÇekiÖdentisiToolStripMenuItem,
            this.çekSenetTahsilToolStripMenuItem});
            this.çEKSENETToolStripMenuItem.Name = "çEKSENETToolStripMenuItem";
            this.çEKSENETToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.çEKSENETToolStripMenuItem.Text = "ÇEK - SENET";
            // 
            // çekSenetOluşturToolStripMenuItem
            // 
            this.çekSenetOluşturToolStripMenuItem.Name = "çekSenetOluşturToolStripMenuItem";
            this.çekSenetOluşturToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetOluşturToolStripMenuItem.Text = "Çek senet oluştur";
            this.çekSenetOluşturToolStripMenuItem.Click += new System.EventHandler(this.çekSenetOluşturToolStripMenuItem_Click);
            // 
            // çekSenetÇağırToolStripMenuItem
            // 
            this.çekSenetÇağırToolStripMenuItem.Name = "çekSenetÇağırToolStripMenuItem";
            this.çekSenetÇağırToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetÇağırToolStripMenuItem.Text = "Çek senet çağır";
            this.çekSenetÇağırToolStripMenuItem.Click += new System.EventHandler(this.çekSenetÇağırToolStripMenuItem_Click);
            // 
            // çekSenetParametrelereGöreÇağırToolStripMenuItem
            // 
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem.Name = "çekSenetParametrelereGöreÇağırToolStripMenuItem";
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem.Text = "Çek senet parametrelere göre çağır";
            this.çekSenetParametrelereGöreÇağırToolStripMenuItem.Click += new System.EventHandler(this.çekSenetParametrelereGöreÇağırToolStripMenuItem_Click);
            // 
            // çekSenetParametrelereGöreSilToolStripMenuItem
            // 
            this.çekSenetParametrelereGöreSilToolStripMenuItem.Name = "çekSenetParametrelereGöreSilToolStripMenuItem";
            this.çekSenetParametrelereGöreSilToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetParametrelereGöreSilToolStripMenuItem.Text = "Çek senet parametrelere göre sil";
            this.çekSenetParametrelereGöreSilToolStripMenuItem.Click += new System.EventHandler(this.çekSenetParametrelereGöreSilToolStripMenuItem_Click);
            // 
            // çekSenetSilToolStripMenuItem
            // 
            this.çekSenetSilToolStripMenuItem.Name = "çekSenetSilToolStripMenuItem";
            this.çekSenetSilToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetSilToolStripMenuItem.Text = "Çek senet sil";
            this.çekSenetSilToolStripMenuItem.Click += new System.EventHandler(this.çekSenetSilToolStripMenuItem_Click);
            // 
            // borçÇekiÖdentisiToolStripMenuItem
            // 
            this.borçÇekiÖdentisiToolStripMenuItem.Name = "borçÇekiÖdentisiToolStripMenuItem";
            this.borçÇekiÖdentisiToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.borçÇekiÖdentisiToolStripMenuItem.Text = "Borç Çeki Ödentisi";
            this.borçÇekiÖdentisiToolStripMenuItem.Click += new System.EventHandler(this.borçÇekiÖdentisiToolStripMenuItem_Click);
            // 
            // çekSenetTahsilToolStripMenuItem
            // 
            this.çekSenetTahsilToolStripMenuItem.Name = "çekSenetTahsilToolStripMenuItem";
            this.çekSenetTahsilToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.çekSenetTahsilToolStripMenuItem.Text = "Çek-Senet Tahsil";
            this.çekSenetTahsilToolStripMenuItem.Click += new System.EventHandler(this.çekSenetTahsilToolStripMenuItem_Click);
            // 
            // gENELToolStripMenuItem
            // 
            this.gENELToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.şİRKETToolStripMenuItem,
            this.kERNELToolStripMenuItem,
            this.tOKENToolStripMenuItem,
            this.yARDIMCIPROGRAMLARToolStripMenuItem});
            this.gENELToolStripMenuItem.Name = "gENELToolStripMenuItem";
            this.gENELToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.gENELToolStripMenuItem.Text = "GENEL";
            // 
            // şİRKETToolStripMenuItem
            // 
            this.şİRKETToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem,
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem,
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem,
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem,
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem,
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1,
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem,
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem,
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem,
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem,
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem,
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem,
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem,
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem,
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem});
            this.şİRKETToolStripMenuItem.Name = "şİRKETToolStripMenuItem";
            this.şİRKETToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.şİRKETToolStripMenuItem.Text = "ŞİRKET";
            // 
            // cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem
            // 
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem.Name = "cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem";
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem.Text = "Cari Döviz Farkı Kapama - Vers. 9.0.37 ve sonrası";
            this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem
            // 
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem.Name = "muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem";
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem.Text = "Muhasebe Aydan Aya Fiş Aktarımı - Vers. 9.0.37 ve sonrası";
            this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem
            // 
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem.Name = "muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem";
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem.Text = "Muhasebe Hesap Kodu Aktarımı - Vers. 9.0.37 ve sonrası";
            this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem
            // 
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem.Name = "açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem";
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem.Text = "Açık Reçete Analizi Çalıştır - Vers. 9.0.37 ve sonrası";
            this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem
            // 
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem.Name = "stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem";
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem.Text = "Stok Bakiye Getir - Vers. 9.0.37 ve sonrası";
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1
            // 
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1.Name = "stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1";
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1.Size = new System.Drawing.Size(471, 26);
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1.Text = "Stok Bakiye Getir - Vers. 9.0.37 ve sonrası";
            this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1.Click += new System.EventHandler(this.stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1_Click);
            // 
            // cariHareketKontrolVers9037VeSonrasıToolStripMenuItem
            // 
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem.Name = "cariHareketKontrolVers9037VeSonrasıToolStripMenuItem";
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem.Text = "Cari Hareket Kontrol - Vers. 9.0.37 ve sonrası";
            this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.cariHareketKontrolVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem
            // 
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Name = "cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem";
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Text = "Cari Kodu Değiştir - Vers. 9.0.37 ve sonrası";
            this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // ePostaGönderVers9037VeSonrasıToolStripMenuItem
            // 
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem.Name = "ePostaGönderVers9037VeSonrasıToolStripMenuItem";
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem.Text = "E-Posta Gönder - Vers. 9.0.37 ve sonrası";
            this.ePostaGönderVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.ePostaGönderVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem
            // 
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem.Name = "yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem";
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem.Text = "Yevmiye Fiş Numara Değişikliği - Vers. 9.0.37 ve sonrası";
            this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem
            // 
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem.Name = "görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem";
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem.Text = "Görsel Rapor Çalıştır - Vers. 9.0.37 ve sonrası";
            this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem
            // 
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem.Name = "stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem";
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem.Text = "Stok Bağlantı Oluştur - Vers. 9.0.37 ve sonrası";
            this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // stokHareketKontrolVers9037VeSonrasıToolStripMenuItem
            // 
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem.Name = "stokHareketKontrolVers9037VeSonrasıToolStripMenuItem";
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem.Text = "Stok Hareket Kontrol - Vers. 9.0.37 ve sonrası";
            this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.stokHareketKontrolVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem
            // 
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Name = "stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem";
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Text = "Stok Kodu Değiştir - Vers. 9.0.37 ve sonrası";
            this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem
            // 
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem.Name = "yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem";
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem.Size = new System.Drawing.Size(471, 26);
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem.Text = "Yevmiye Kontrol - Vers. 9.0.37 ve sonrası";
            this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem.Click += new System.EventHandler(this.yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem_Click);
            // 
            // kERNELToolStripMenuItem
            // 
            this.kERNELToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hataKoduYorumlamaToolStripMenuItem});
            this.kERNELToolStripMenuItem.Name = "kERNELToolStripMenuItem";
            this.kERNELToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.kERNELToolStripMenuItem.Text = "KERNEL ";
            // 
            // hataKoduYorumlamaToolStripMenuItem
            // 
            this.hataKoduYorumlamaToolStripMenuItem.Name = "hataKoduYorumlamaToolStripMenuItem";
            this.hataKoduYorumlamaToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.hataKoduYorumlamaToolStripMenuItem.Text = "Hata Kodu Yorumlama";
            this.hataKoduYorumlamaToolStripMenuItem.Click += new System.EventHandler(this.hataKoduYorumlamaToolStripMenuItem_Click);
            // 
            // tOKENToolStripMenuItem
            // 
            this.tOKENToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tokenAlmaToolStripMenuItem});
            this.tOKENToolStripMenuItem.Name = "tOKENToolStripMenuItem";
            this.tOKENToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.tOKENToolStripMenuItem.Text = "TOKEN";
            // 
            // tokenAlmaToolStripMenuItem
            // 
            this.tokenAlmaToolStripMenuItem.Name = "tokenAlmaToolStripMenuItem";
            this.tokenAlmaToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.tokenAlmaToolStripMenuItem.Text = "Token Alma";
            this.tokenAlmaToolStripMenuItem.Click += new System.EventHandler(this.tokenAlmaToolStripMenuItem_Click);
            // 
            // yARDIMCIPROGRAMLARToolStripMenuItem
            // 
            this.yARDIMCIPROGRAMLARToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kAYITToolStripMenuItem});
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Name = "yARDIMCIPROGRAMLARToolStripMenuItem";
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.yARDIMCIPROGRAMLARToolStripMenuItem.Text = "YARDIMCI PROGRAMLAR";
            // 
            // kAYITToolStripMenuItem
            // 
            this.kAYITToolStripMenuItem.Name = "kAYITToolStripMenuItem";
            this.kAYITToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.kAYITToolStripMenuItem.Text = "KAYIT";
            // 
            // üRETİMToolStripMenuItem
            // 
            this.üRETİMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iŞEMRİToolStripMenuItem,
            this.mRPToolStripMenuItem,
            this.üRETİMAKIŞKONTROLToolStripMenuItem,
            this.pLANLAMAKAYITLARIToolStripMenuItem,
            this.sERBESTSUSKToolStripMenuItem,
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem,
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem,
            this.mAKİNEBAKIMToolStripMenuItem});
            this.üRETİMToolStripMenuItem.Name = "üRETİMToolStripMenuItem";
            this.üRETİMToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.üRETİMToolStripMenuItem.Text = "ÜRETİM";
            // 
            // iŞEMRİToolStripMenuItem
            // 
            this.iŞEMRİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işEmriKayıtToolStripMenuItem});
            this.iŞEMRİToolStripMenuItem.Name = "iŞEMRİToolStripMenuItem";
            this.iŞEMRİToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.iŞEMRİToolStripMenuItem.Text = "İŞ EMRİ";
            // 
            // işEmriKayıtToolStripMenuItem
            // 
            this.işEmriKayıtToolStripMenuItem.Name = "işEmriKayıtToolStripMenuItem";
            this.işEmriKayıtToolStripMenuItem.Size = new System.Drawing.Size(173, 26);
            this.işEmriKayıtToolStripMenuItem.Text = "İş Emri Kayıt";
            this.işEmriKayıtToolStripMenuItem.Click += new System.EventHandler(this.işEmriKayıtToolStripMenuItem_Click);
            // 
            // mRPToolStripMenuItem
            // 
            this.mRPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem,
            this.malzemeGereksinimPlanlamaToolStripMenuItem,
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem,
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem});
            this.mRPToolStripMenuItem.Name = "mRPToolStripMenuItem";
            this.mRPToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.mRPToolStripMenuItem.Text = "MRP";
            // 
            // malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem
            // 
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem.Name = "malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem";
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(419, 26);
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem.Text = "Malzeme Gereksinim Planlama Oluşturma";
            this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem_Click);
            // 
            // malzemeGereksinimPlanlamaToolStripMenuItem
            // 
            this.malzemeGereksinimPlanlamaToolStripMenuItem.Name = "malzemeGereksinimPlanlamaToolStripMenuItem";
            this.malzemeGereksinimPlanlamaToolStripMenuItem.Size = new System.Drawing.Size(419, 26);
            this.malzemeGereksinimPlanlamaToolStripMenuItem.Text = "Malzeme Gereksinim Planlama";
            this.malzemeGereksinimPlanlamaToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimPlanlamaToolStripMenuItem_Click);
            // 
            // malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem
            // 
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem.Name = "malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem";
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem.Size = new System.Drawing.Size(419, 26);
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem.Text = "Malzeme Gereksiniminden Talep Liste Hazırlamak";
            this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem_Click);
            // 
            // malzemeGereksinimindenTalepOluşturmaToolStripMenuItem
            // 
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Name = "malzemeGereksinimindenTalepOluşturmaToolStripMenuItem";
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(419, 26);
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Text = "Malzeme Gereksiniminden Talep Oluşturma";
            this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.malzemeGereksinimindenTalepOluşturmaToolStripMenuItem_Click);
            // 
            // üRETİMAKIŞKONTROLToolStripMenuItem
            // 
            this.üRETİMAKIŞKONTROLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEÇETEToolStripMenuItem,
            this.rAPORToolStripMenuItem,
            this.pROSESKONTROLToolStripMenuItem});
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Name = "üRETİMAKIŞKONTROLToolStripMenuItem";
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.üRETİMAKIŞKONTROLToolStripMenuItem.Text = "ÜRETİM, AKIŞ KONTROL";
            // 
            // rEÇETEToolStripMenuItem
            // 
            this.rEÇETEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reçeteKayıtToolStripMenuItem,
            this.reçetedenİşEmriOluşturmaToolStripMenuItem});
            this.rEÇETEToolStripMenuItem.Name = "rEÇETEToolStripMenuItem";
            this.rEÇETEToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.rEÇETEToolStripMenuItem.Text = "REÇETE";
            // 
            // reçeteKayıtToolStripMenuItem
            // 
            this.reçeteKayıtToolStripMenuItem.Name = "reçeteKayıtToolStripMenuItem";
            this.reçeteKayıtToolStripMenuItem.Size = new System.Drawing.Size(282, 26);
            this.reçeteKayıtToolStripMenuItem.Text = "Reçete Kayıt";
            this.reçeteKayıtToolStripMenuItem.Click += new System.EventHandler(this.reçeteKayıtToolStripMenuItem_Click);
            // 
            // reçetedenİşEmriOluşturmaToolStripMenuItem
            // 
            this.reçetedenİşEmriOluşturmaToolStripMenuItem.Name = "reçetedenİşEmriOluşturmaToolStripMenuItem";
            this.reçetedenİşEmriOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(282, 26);
            this.reçetedenİşEmriOluşturmaToolStripMenuItem.Text = "Reçeteden İş Emri Oluşturma";
            this.reçetedenİşEmriOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.reçetedenİşEmriOluşturmaToolStripMenuItem_Click);
            // 
            // rAPORToolStripMenuItem
            // 
            this.rAPORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raporÇalıştırVeKaydetToolStripMenuItem});
            this.rAPORToolStripMenuItem.Name = "rAPORToolStripMenuItem";
            this.rAPORToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.rAPORToolStripMenuItem.Text = "RAPOR";
            // 
            // raporÇalıştırVeKaydetToolStripMenuItem
            // 
            this.raporÇalıştırVeKaydetToolStripMenuItem.Name = "raporÇalıştırVeKaydetToolStripMenuItem";
            this.raporÇalıştırVeKaydetToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.raporÇalıştırVeKaydetToolStripMenuItem.Text = "Rapor Çalıştır Ve Kaydet";
            this.raporÇalıştırVeKaydetToolStripMenuItem.Click += new System.EventHandler(this.raporÇalıştırVeKaydetToolStripMenuItem_Click);
            // 
            // pROSESKONTROLToolStripMenuItem
            // 
            this.pROSESKONTROLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prosesKontrolGirişiToolStripMenuItem,
            this.prosesKontrolGirişiOkumaToolStripMenuItem,
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem});
            this.pROSESKONTROLToolStripMenuItem.Name = "pROSESKONTROLToolStripMenuItem";
            this.pROSESKONTROLToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.pROSESKONTROLToolStripMenuItem.Text = "PROSES KONTROL";
            // 
            // prosesKontrolGirişiToolStripMenuItem
            // 
            this.prosesKontrolGirişiToolStripMenuItem.Name = "prosesKontrolGirişiToolStripMenuItem";
            this.prosesKontrolGirişiToolStripMenuItem.Size = new System.Drawing.Size(306, 26);
            this.prosesKontrolGirişiToolStripMenuItem.Text = "Proses Kontrol Girişi";
            this.prosesKontrolGirişiToolStripMenuItem.Click += new System.EventHandler(this.prosesKontrolGirişiToolStripMenuItem_Click);
            // 
            // prosesKontrolGirişiOkumaToolStripMenuItem
            // 
            this.prosesKontrolGirişiOkumaToolStripMenuItem.Name = "prosesKontrolGirişiOkumaToolStripMenuItem";
            this.prosesKontrolGirişiOkumaToolStripMenuItem.Size = new System.Drawing.Size(306, 26);
            this.prosesKontrolGirişiOkumaToolStripMenuItem.Text = "Proses Kontrol Girişi Okuma";
            this.prosesKontrolGirişiOkumaToolStripMenuItem.Click += new System.EventHandler(this.prosesKontrolGirişiOkumaToolStripMenuItem_Click);
            // 
            // prosesKontrolGirişiGüncellemeToolStripMenuItem
            // 
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem.Name = "prosesKontrolGirişiGüncellemeToolStripMenuItem";
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem.Size = new System.Drawing.Size(306, 26);
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem.Text = "Proses Kontrol Girişi Güncelleme";
            this.prosesKontrolGirişiGüncellemeToolStripMenuItem.Click += new System.EventHandler(this.prosesKontrolGirişiGüncellemeToolStripMenuItem_Click);
            // 
            // pLANLAMAKAYITLARIToolStripMenuItem
            // 
            this.pLANLAMAKAYITLARIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem,
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem,
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem});
            this.pLANLAMAKAYITLARIToolStripMenuItem.Name = "pLANLAMAKAYITLARIToolStripMenuItem";
            this.pLANLAMAKAYITLARIToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.pLANLAMAKAYITLARIToolStripMenuItem.Text = "PLANLAMA KAYITLARI";
            // 
            // sTOKPLANLAMAKAYITLARIToolStripMenuItem
            // 
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokPlanlamaKayıtlarıToolStripMenuItem,
            this.stokPlanlamaKayıtOkumaToolStripMenuItem,
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem,
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem});
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem.Name = "sTOKPLANLAMAKAYITLARIToolStripMenuItem";
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem.Size = new System.Drawing.Size(319, 26);
            this.sTOKPLANLAMAKAYITLARIToolStripMenuItem.Text = "STOK PLANLAMA KAYITLARI";
            // 
            // stokPlanlamaKayıtlarıToolStripMenuItem
            // 
            this.stokPlanlamaKayıtlarıToolStripMenuItem.Name = "stokPlanlamaKayıtlarıToolStripMenuItem";
            this.stokPlanlamaKayıtlarıToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.stokPlanlamaKayıtlarıToolStripMenuItem.Text = "Stok Planlama Kayıtları";
            this.stokPlanlamaKayıtlarıToolStripMenuItem.Click += new System.EventHandler(this.stokPlanlamaKayıtlarıToolStripMenuItem_Click);
            // 
            // stokPlanlamaKayıtOkumaToolStripMenuItem
            // 
            this.stokPlanlamaKayıtOkumaToolStripMenuItem.Name = "stokPlanlamaKayıtOkumaToolStripMenuItem";
            this.stokPlanlamaKayıtOkumaToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.stokPlanlamaKayıtOkumaToolStripMenuItem.Text = "Stok Planlama Kayıt Okuma";
            this.stokPlanlamaKayıtOkumaToolStripMenuItem.Click += new System.EventHandler(this.stokPlanlamaKayıtOkumaToolStripMenuItem_Click);
            // 
            // stokPlanlamaKayıtlarıGüncelleToolStripMenuItem
            // 
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem.Name = "stokPlanlamaKayıtlarıGüncelleToolStripMenuItem";
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem.Text = "Stok Planlama Kayıtları Güncelle";
            this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem.Click += new System.EventHandler(this.stokPlanlamaKayıtlarıGüncelleToolStripMenuItem_Click);
            // 
            // stokPlanlamaKayıtlarıSilToolStripMenuItem
            // 
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem.Name = "stokPlanlamaKayıtlarıSilToolStripMenuItem";
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem.Text = "Stok Planlama Kayıtları Sil";
            this.stokPlanlamaKayıtlarıSilToolStripMenuItem.Click += new System.EventHandler(this.stokPlanlamaKayıtlarıSilToolStripMenuItem_Click);
            // 
            // mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem
            // 
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem,
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem,
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem,
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem});
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem.Name = "mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem";
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem.Size = new System.Drawing.Size(319, 26);
            this.mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem.Text = "MÜŞTERİ - SATICI STOK KAYITLARI";
            // 
            // müşteriSatıcıStokKayıtlarıToolStripMenuItem
            // 
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem.Name = "müşteriSatıcıStokKayıtlarıToolStripMenuItem";
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem.Size = new System.Drawing.Size(356, 26);
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem.Text = "Müşteri-Satıcı Stok Kayıtları";
            this.müşteriSatıcıStokKayıtlarıToolStripMenuItem.Click += new System.EventHandler(this.müşteriSatıcıStokKayıtlarıToolStripMenuItem_Click);
            // 
            // müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem
            // 
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem.Name = "müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem";
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem.Size = new System.Drawing.Size(356, 26);
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem.Text = "Müşteri-Satıcı Stok Kayıtları Okuma";
            this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem.Click += new System.EventHandler(this.müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem_Click);
            // 
            // müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem
            // 
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem.Name = "müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem";
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem.Size = new System.Drawing.Size(356, 26);
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem.Text = "Müşteri-Satıcı Stok Kayıtları Güncelleme";
            this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem.Click += new System.EventHandler(this.müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem_Click);
            // 
            // müşteriSatıcıStokKayıtlarıSilToolStripMenuItem
            // 
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem.Name = "müşteriSatıcıStokKayıtlarıSilToolStripMenuItem";
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem.Size = new System.Drawing.Size(356, 26);
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem.Text = "Müşteri-Satıcı Stok Kayıtları Sil";
            this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem.Click += new System.EventHandler(this.müşteriSatıcıStokKayıtlarıSilToolStripMenuItem_Click);
            // 
            // cARİPLANLAMAKAYITLARIToolStripMenuItem
            // 
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cariPlanlamaKayıtlarıToolStripMenuItem,
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem,
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem,
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem});
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem.Name = "cARİPLANLAMAKAYITLARIToolStripMenuItem";
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem.Size = new System.Drawing.Size(319, 26);
            this.cARİPLANLAMAKAYITLARIToolStripMenuItem.Text = "CARİ PLANLAMA KAYITLARI";
            // 
            // cariPlanlamaKayıtlarıToolStripMenuItem
            // 
            this.cariPlanlamaKayıtlarıToolStripMenuItem.Name = "cariPlanlamaKayıtlarıToolStripMenuItem";
            this.cariPlanlamaKayıtlarıToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.cariPlanlamaKayıtlarıToolStripMenuItem.Text = "Cari Planlama Kayıtları";
            this.cariPlanlamaKayıtlarıToolStripMenuItem.Click += new System.EventHandler(this.cariPlanlamaKayıtlarıToolStripMenuItem_Click);
            // 
            // cariPlanlamaKayıtlarıOkuToolStripMenuItem
            // 
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem.Name = "cariPlanlamaKayıtlarıOkuToolStripMenuItem";
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem.Text = "Cari Planlama Kayıtları Oku";
            this.cariPlanlamaKayıtlarıOkuToolStripMenuItem.Click += new System.EventHandler(this.cariPlanlamaKayıtlarıOkuToolStripMenuItem_Click);
            // 
            // cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem
            // 
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem.Name = "cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem";
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem.Text = "Cari Planlama Kayıtları Güncelleme";
            this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem.Click += new System.EventHandler(this.cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem_Click);
            // 
            // cariPlanlamaKayıtlarıSilToolStripMenuItem
            // 
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem.Name = "cariPlanlamaKayıtlarıSilToolStripMenuItem";
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem.Text = "Cari Planlama Kayıtları Sil";
            this.cariPlanlamaKayıtlarıSilToolStripMenuItem.Click += new System.EventHandler(this.cariPlanlamaKayıtlarıSilToolStripMenuItem_Click);
            // 
            // sERBESTSUSKToolStripMenuItem
            // 
            this.sERBESTSUSKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.suskKaydıToolStripMenuItem,
            this.suskKayıtOkumaToolStripMenuItem,
            this.suskKayıtSilmeToolStripMenuItem,
            this.suskKalemSilmeToolStripMenuItem});
            this.sERBESTSUSKToolStripMenuItem.Name = "sERBESTSUSKToolStripMenuItem";
            this.sERBESTSUSKToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.sERBESTSUSKToolStripMenuItem.Text = "SERBEST SUSK";
            // 
            // suskKaydıToolStripMenuItem
            // 
            this.suskKaydıToolStripMenuItem.Name = "suskKaydıToolStripMenuItem";
            this.suskKaydıToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.suskKaydıToolStripMenuItem.Text = "Susk Kaydı";
            this.suskKaydıToolStripMenuItem.Click += new System.EventHandler(this.suskKaydıToolStripMenuItem_Click);
            // 
            // suskKayıtOkumaToolStripMenuItem
            // 
            this.suskKayıtOkumaToolStripMenuItem.Name = "suskKayıtOkumaToolStripMenuItem";
            this.suskKayıtOkumaToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.suskKayıtOkumaToolStripMenuItem.Text = "Susk Kayıt Okuma";
            this.suskKayıtOkumaToolStripMenuItem.Click += new System.EventHandler(this.suskKayıtOkumaToolStripMenuItem_Click);
            // 
            // suskKayıtSilmeToolStripMenuItem
            // 
            this.suskKayıtSilmeToolStripMenuItem.Name = "suskKayıtSilmeToolStripMenuItem";
            this.suskKayıtSilmeToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.suskKayıtSilmeToolStripMenuItem.Text = "Susk Kayıt Silme";
            this.suskKayıtSilmeToolStripMenuItem.Click += new System.EventHandler(this.suskKayıtSilmeToolStripMenuItem_Click);
            // 
            // suskKalemSilmeToolStripMenuItem
            // 
            this.suskKalemSilmeToolStripMenuItem.Name = "suskKalemSilmeToolStripMenuItem";
            this.suskKalemSilmeToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.suskKalemSilmeToolStripMenuItem.Text = "Susk Kalem Silme";
            this.suskKalemSilmeToolStripMenuItem.Click += new System.EventHandler(this.suskKalemSilmeToolStripMenuItem_Click);
            // 
            // üRÜNMALİYETOLUŞTURMAToolStripMenuItem
            // 
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ürünMaliyetOluşturmaToolStripMenuItem});
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem.Name = "üRÜNMALİYETOLUŞTURMAToolStripMenuItem";
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.üRÜNMALİYETOLUŞTURMAToolStripMenuItem.Text = "ÜRÜN MALİYET OLUŞTURMA";
            // 
            // ürünMaliyetOluşturmaToolStripMenuItem
            // 
            this.ürünMaliyetOluşturmaToolStripMenuItem.Name = "ürünMaliyetOluşturmaToolStripMenuItem";
            this.ürünMaliyetOluşturmaToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.ürünMaliyetOluşturmaToolStripMenuItem.Text = "Ürün Maliyet Oluşturma";
            this.ürünMaliyetOluşturmaToolStripMenuItem.Click += new System.EventHandler(this.ürünMaliyetOluşturmaToolStripMenuItem_Click);
            // 
            // yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem
            // 
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem});
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem.Name = "yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem";
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem.Text = "YAŞLANDIRMALI ÖZEL HESAP KAPATMA";
            // 
            // yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem
            // 
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem.Name = "yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem";
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem.Text = "Yaşlandırmalı Özel Hesap Kapatma";
            this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem.Click += new System.EventHandler(this.yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem_Click);
            // 
            // mAKİNEBAKIMToolStripMenuItem
            // 
            this.mAKİNEBAKIMToolStripMenuItem.Name = "mAKİNEBAKIMToolStripMenuItem";
            this.mAKİNEBAKIMToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.mAKİNEBAKIMToolStripMenuItem.Text = "MAKİNE BAKIM";
            // 
            // mUHASEBEToolStripMenuItem
            // 
            this.mUHASEBEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mUHASEBEToolStripMenuItem1,
            this.dÖVİZToolStripMenuItem,
            this.eNTEGREToolStripMenuItem,
            this.mALİYETMUHASEBESİToolStripMenuItem});
            this.mUHASEBEToolStripMenuItem.Name = "mUHASEBEToolStripMenuItem";
            this.mUHASEBEToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.mUHASEBEToolStripMenuItem.Text = "MUHASEBE";
            // 
            // mUHASEBEToolStripMenuItem1
            // 
            this.mUHASEBEToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aydanAyaFişAktarımı9037ToolStripMenuItem,
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem});
            this.mUHASEBEToolStripMenuItem1.Name = "mUHASEBEToolStripMenuItem1";
            this.mUHASEBEToolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.mUHASEBEToolStripMenuItem1.Text = "MUHASEBE";
            // 
            // aydanAyaFişAktarımı9037ToolStripMenuItem
            // 
            this.aydanAyaFişAktarımı9037ToolStripMenuItem.Name = "aydanAyaFişAktarımı9037ToolStripMenuItem";
            this.aydanAyaFişAktarımı9037ToolStripMenuItem.Size = new System.Drawing.Size(357, 26);
            this.aydanAyaFişAktarımı9037ToolStripMenuItem.Text = "Aydan Aya Fiş Aktarımı - 9.0.37";
            this.aydanAyaFişAktarımı9037ToolStripMenuItem.Click += new System.EventHandler(this.aydanAyaFişAktarımı9037ToolStripMenuItem_Click);
            // 
            // muhasebeHesapKoduAktarımı9037ToolStripMenuItem
            // 
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem.Name = "muhasebeHesapKoduAktarımı9037ToolStripMenuItem";
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem.Size = new System.Drawing.Size(357, 26);
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem.Text = "Muhasebe Hesap Kodu Aktarımı - 9.0.37";
            this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem.Click += new System.EventHandler(this.muhasebeHesapKoduAktarımı9037ToolStripMenuItem_Click);
            // 
            // dÖVİZToolStripMenuItem
            // 
            this.dÖVİZToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dövizKaydıOkuToolStripMenuItem,
            this.dövizKaydıOluşturToolStripMenuItem,
            this.dövizKaydıSilToolStripMenuItem,
            this.dövizKaydıGüncellemeToolStripMenuItem});
            this.dÖVİZToolStripMenuItem.Name = "dÖVİZToolStripMenuItem";
            this.dÖVİZToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.dÖVİZToolStripMenuItem.Text = "DÖVİZ";
            // 
            // dövizKaydıOkuToolStripMenuItem
            // 
            this.dövizKaydıOkuToolStripMenuItem.Name = "dövizKaydıOkuToolStripMenuItem";
            this.dövizKaydıOkuToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.dövizKaydıOkuToolStripMenuItem.Text = "Döviz Kaydı Oku";
            this.dövizKaydıOkuToolStripMenuItem.Click += new System.EventHandler(this.dövizKaydıOkuToolStripMenuItem_Click);
            // 
            // dövizKaydıOluşturToolStripMenuItem
            // 
            this.dövizKaydıOluşturToolStripMenuItem.Name = "dövizKaydıOluşturToolStripMenuItem";
            this.dövizKaydıOluşturToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.dövizKaydıOluşturToolStripMenuItem.Text = "Döviz Kaydı Oluştur";
            this.dövizKaydıOluşturToolStripMenuItem.Click += new System.EventHandler(this.dövizKaydıOluşturToolStripMenuItem_Click);
            // 
            // dövizKaydıSilToolStripMenuItem
            // 
            this.dövizKaydıSilToolStripMenuItem.Name = "dövizKaydıSilToolStripMenuItem";
            this.dövizKaydıSilToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.dövizKaydıSilToolStripMenuItem.Text = "Döviz Kaydı Sil";
            this.dövizKaydıSilToolStripMenuItem.Click += new System.EventHandler(this.dövizKaydıSilToolStripMenuItem_Click);
            // 
            // dövizKaydıGüncellemeToolStripMenuItem
            // 
            this.dövizKaydıGüncellemeToolStripMenuItem.Name = "dövizKaydıGüncellemeToolStripMenuItem";
            this.dövizKaydıGüncellemeToolStripMenuItem.Size = new System.Drawing.Size(253, 26);
            this.dövizKaydıGüncellemeToolStripMenuItem.Text = "Döviz Kaydı Güncelleme";
            this.dövizKaydıGüncellemeToolStripMenuItem.Click += new System.EventHandler(this.dövizKaydıGüncellemeToolStripMenuItem_Click);
            // 
            // eNTEGREToolStripMenuItem
            // 
            this.eNTEGREToolStripMenuItem.Name = "eNTEGREToolStripMenuItem";
            this.eNTEGREToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.eNTEGREToolStripMenuItem.Text = "ENTEGRE";
            // 
            // mALİYETMUHASEBESİToolStripMenuItem
            // 
            this.mALİYETMUHASEBESİToolStripMenuItem.Name = "mALİYETMUHASEBESİToolStripMenuItem";
            this.mALİYETMUHASEBESİToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.mALİYETMUHASEBESİToolStripMenuItem.Text = "MALİYET MUHASEBESİ";
            // 
            // btnAnaMenu
            // 
            this.btnAnaMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAnaMenu.Location = new System.Drawing.Point(1177, 728);
            this.btnAnaMenu.Name = "btnAnaMenu";
            this.btnAnaMenu.Size = new System.Drawing.Size(86, 25);
            this.btnAnaMenu.TabIndex = 2;
            this.btnAnaMenu.Text = "Ana Menü";
            this.btnAnaMenu.UseVisualStyleBackColor = true;
            this.btnAnaMenu.Click += new System.EventHandler(this.btnAnaMenu_Click);
            // 
            // btnCıkıs
            // 
            this.btnCıkıs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCıkıs.Location = new System.Drawing.Point(880, 728);
            this.btnCıkıs.Name = "btnCıkıs";
            this.btnCıkıs.Size = new System.Drawing.Size(75, 25);
            this.btnCıkıs.TabIndex = 19;
            this.btnCıkıs.Text = "Çıkış";
            this.btnCıkıs.UseVisualStyleBackColor = true;
            this.btnCıkıs.Click += new System.EventHandler(this.btnCıkıs_Click);
            // 
            // chkRemember
            // 
            this.chkRemember.AutoSize = true;
            this.chkRemember.Location = new System.Drawing.Point(151, 220);
            this.chkRemember.Name = "chkRemember";
            this.chkRemember.Size = new System.Drawing.Size(98, 20);
            this.chkRemember.TabIndex = 18;
            this.chkRemember.Text = "Beni Hatırla";
            this.chkRemember.UseVisualStyleBackColor = true;
            // 
            // btnGiris
            // 
            this.btnGiris.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGiris.Location = new System.Drawing.Point(799, 728);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(75, 25);
            this.btnGiris.TabIndex = 17;
            this.btnGiris.Text = "Giriş";
            this.btnGiris.UseVisualStyleBackColor = true;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            // 
            // txtServisCalismaAdresi
            // 
            this.txtServisCalismaAdresi.Location = new System.Drawing.Point(151, 192);
            this.txtServisCalismaAdresi.Name = "txtServisCalismaAdresi";
            this.txtServisCalismaAdresi.Size = new System.Drawing.Size(276, 22);
            this.txtServisCalismaAdresi.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Servis Çalışma Adresi";
            // 
            // txtBranch
            // 
            this.txtBranch.AutoSize = true;
            this.txtBranch.Location = new System.Drawing.Point(6, 167);
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.Size = new System.Drawing.Size(39, 16);
            this.txtBranch.TabIndex = 14;
            this.txtBranch.Text = "Şube";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Netsis Şifre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "Netsis Kullanıcı Adı";
            // 
            // txtVTPassword
            // 
            this.txtVTPassword.AutoSize = true;
            this.txtVTPassword.Location = new System.Drawing.Point(6, 89);
            this.txtVTPassword.Name = "txtVTPassword";
            this.txtVTPassword.Size = new System.Drawing.Size(55, 16);
            this.txtVTPassword.TabIndex = 11;
            this.txtVTPassword.Text = "VT Şifre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "VT Kullanıcı Adı";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "DB Name";
            // 
            // txtSube
            // 
            this.txtSube.Location = new System.Drawing.Point(151, 164);
            this.txtSube.Name = "txtSube";
            this.txtSube.Size = new System.Drawing.Size(117, 22);
            this.txtSube.TabIndex = 9;
            // 
            // txtNetsisPassword
            // 
            this.txtNetsisPassword.Location = new System.Drawing.Point(150, 136);
            this.txtNetsisPassword.Name = "txtNetsisPassword";
            this.txtNetsisPassword.PasswordChar = '*';
            this.txtNetsisPassword.Size = new System.Drawing.Size(117, 22);
            this.txtNetsisPassword.TabIndex = 8;
            // 
            // txtNetsisUserName
            // 
            this.txtNetsisUserName.Location = new System.Drawing.Point(150, 108);
            this.txtNetsisUserName.Name = "txtNetsisUserName";
            this.txtNetsisUserName.Size = new System.Drawing.Size(117, 22);
            this.txtNetsisUserName.TabIndex = 7;
            // 
            // txtVTsifre
            // 
            this.txtVTsifre.Location = new System.Drawing.Point(151, 83);
            this.txtVTsifre.Name = "txtVTsifre";
            this.txtVTsifre.PasswordChar = '*';
            this.txtVTsifre.Size = new System.Drawing.Size(116, 22);
            this.txtVTsifre.TabIndex = 6;
            // 
            // txtVTuserName
            // 
            this.txtVTuserName.Location = new System.Drawing.Point(151, 55);
            this.txtVTuserName.Name = "txtVTuserName";
            this.txtVTuserName.Size = new System.Drawing.Size(116, 22);
            this.txtVTuserName.TabIndex = 5;
            // 
            // txtDbName
            // 
            this.txtDbName.Location = new System.Drawing.Point(151, 27);
            this.txtDbName.Name = "txtDbName";
            this.txtDbName.Size = new System.Drawing.Size(116, 22);
            this.txtDbName.TabIndex = 4;
            // 
            // grpCompanyInfos
            // 
            this.grpCompanyInfos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.grpCompanyInfos.Controls.Add(this.label1);
            this.grpCompanyInfos.Controls.Add(this.chkRemember);
            this.grpCompanyInfos.Controls.Add(this.label2);
            this.grpCompanyInfos.Controls.Add(this.txtSube);
            this.grpCompanyInfos.Controls.Add(this.label3);
            this.grpCompanyInfos.Controls.Add(this.txtServisCalismaAdresi);
            this.grpCompanyInfos.Controls.Add(this.txtVTPassword);
            this.grpCompanyInfos.Controls.Add(this.txtDbName);
            this.grpCompanyInfos.Controls.Add(this.txtNetsisPassword);
            this.grpCompanyInfos.Controls.Add(this.txtVTuserName);
            this.grpCompanyInfos.Controls.Add(this.label4);
            this.grpCompanyInfos.Controls.Add(this.txtBranch);
            this.grpCompanyInfos.Controls.Add(this.txtNetsisUserName);
            this.grpCompanyInfos.Controls.Add(this.txtVTsifre);
            this.grpCompanyInfos.Controls.Add(this.label5);
            this.grpCompanyInfos.Location = new System.Drawing.Point(799, 451);
            this.grpCompanyInfos.Name = "grpCompanyInfos";
            this.grpCompanyInfos.Size = new System.Drawing.Size(464, 271);
            this.grpCompanyInfos.TabIndex = 5;
            this.grpCompanyInfos.TabStop = false;
            this.grpCompanyInfos.Text = "Şirket Bilgileri";
            // 
            // grpCompantInfos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1275, 781);
            this.Controls.Add(this.btnCıkıs);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.grpCompanyInfos);
            this.Controls.Add(this.btnAnaMenu);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "grpCompantInfos";
            this.Text = "NetOpenX REST";
            this.Load += new System.EventHandler(this.frmNetOpenXREST_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpCompanyInfos.ResumeLayout(false);
            this.grpCompanyInfos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button btnAnaMenu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txtBranch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label txtVTPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem lOJİSTİKSATIŞToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fİNANSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gENELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRETİMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mUHASEBEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fATURAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tALEPTEKLİFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dİNAMİKDEPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dATToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hIZLITAHSİLATToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dIŞTİCARETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kALİTEKONTROLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kANTARTARTIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mÜHTAHSİLFATURASIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kARGOGÖNDERİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cARİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEKONTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bANKAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kASAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çEKSENETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yARDIMCIPROGRAMLARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem şİRKETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kERNELToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tOKENToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iŞEMRİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mRPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRETİMAKIŞKONTROLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLANLAMAKAYITLARIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sERBESTSUSKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üRÜNMALİYETOLUŞTURMAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yAŞLANDIRMALIÖZELHESAPKAPATMAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mAKİNEBAKIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mUHASEBEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dÖVİZToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eNTEGREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mALİYETMUHASEBESİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iŞLEMLERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ambarGirişFişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ambarÇıkışFişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaNumaraDeğişikliğiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dövizliFaturaKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışFaturasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışİrsaliyeKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışTeklifKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sipariştenFaturaOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem talepTeklifOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parçalıSiparişTeslimatıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faturaOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişKopyalamaVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişRevizyonVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem halFaturasıVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFATURAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaKaydetmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaTaslakOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eFaturaGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eİRSALİYEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIrsaliyeKaydetmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIrsaliyeTaslakOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIrsaliyeGöndermeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIrsaliyeGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBELGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBelgeCariGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBelgeKabulRetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBelgeKalemKabulRetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eBelgeİptalFaturasıOluşturToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniEArsivNumaraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bASIMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irsaliyeFaturaBasımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irsaliyeFaturaKalemBasımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rAPORLARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokHareketKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokDüzenlemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinamikDepoHücreYerleştirmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem depolarArasıTransferKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lokalDepolarArasıTransferKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hızlıTahsilatKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hızlıTahsilatOluşturToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hızlıTahsilatSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hızlıTahsilatGetirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariBağlantıAnaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariÇağırmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cARİHAREKETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariHareketOluşturToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariHareketGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem belirliBirCariHareketiGetirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tümCariHareketleriGetirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariHareketiSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniNumaraAlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokDekontKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bANKAHAREKETKAYITLARIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHareketKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHareketGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHareketSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHareketGetirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bANKAHAVALEEFTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHavaleEftKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHavaleEftGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankaHavaleEftSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kURToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kurKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaCariÖdemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaÇekÖdemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaÇokluKalemGirişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaMuhtelifİşlemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaTransferToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kasaBankaHareketKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetOluşturToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetÇağırToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetParametrelereGöreÇağırToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetParametrelereGöreSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borçÇekiÖdentisiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çekSenetTahsilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cariHareketKontrolVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ePostaGönderVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokHareketKontrolVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hataKoduYorumlamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tokenAlmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kAYITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işEmriKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimPlanlamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeGereksinimindenTalepOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEÇETEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reçeteKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reçetedenİşEmriOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rAPORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raporÇalıştırVeKaydetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROSESKONTROLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prosesKontrolGirişiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prosesKontrolGirişiOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prosesKontrolGirişiGüncellemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOKPLANLAMAKAYITLARIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokPlanlamaKayıtlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokPlanlamaKayıtOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokPlanlamaKayıtlarıGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stokPlanlamaKayıtlarıSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mÜŞTERİSATICISTOKKAYITLARIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriSatıcıStokKayıtlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem müşteriSatıcıStokKayıtlarıSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cARİPLANLAMAKAYITLARIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariPlanlamaKayıtlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariPlanlamaKayıtlarıOkuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cariPlanlamaKayıtlarıSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suskKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suskKayıtOkumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suskKayıtSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suskKalemSilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ürünMaliyetOluşturmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aydanAyaFişAktarımı9037ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muhasebeHesapKoduAktarımı9037ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dövizKaydıOkuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dövizKaydıOluşturToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dövizKaydıSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dövizKaydıGüncellemeToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpCompanyInfos;
        public System.Windows.Forms.TextBox txtServisCalismaAdresi;
        public System.Windows.Forms.TextBox txtSube;
        public System.Windows.Forms.TextBox txtNetsisPassword;
        public System.Windows.Forms.TextBox txtNetsisUserName;
        public System.Windows.Forms.TextBox txtVTsifre;
        public System.Windows.Forms.TextBox txtVTuserName;
        public System.Windows.Forms.TextBox txtDbName;
        public System.Windows.Forms.Button btnGiris;
        public System.Windows.Forms.CheckBox chkRemember;
        public System.Windows.Forms.Button btnCıkıs;
    }
}