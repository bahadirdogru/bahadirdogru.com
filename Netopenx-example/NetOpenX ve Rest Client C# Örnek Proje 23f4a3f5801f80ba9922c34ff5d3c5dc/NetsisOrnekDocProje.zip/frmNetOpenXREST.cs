﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using NetOpenX.Rest.Client;
using NetOpenX.Rest.Client.BLL;
using NetOpenX50;
using NetOpenX.Rest.Client.Model;
using NetOpenX.Rest.Client.Model.NetOpenX;
using NetOpenX.Rest.Client.Model.Custom;
using NetOpenX.Rest.Client.Model.Enums;
using System.IO;

namespace DocProje
{
    public partial class grpCompantInfos : Form
    {
     
        public grpCompantInfos()
        {
            InitializeComponent();
        }

        private void btnAnaMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAnaMenu AnaMenu = new frmAnaMenu();
            AnaMenu.ShowDialog();
            this.Close();
        }
        
        private void btnGiris_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (chkRemember.Checked == true)
                {
                    sirketNetOpenXREST.Default.dbName = txtDbName.Text;
                    sirketNetOpenXREST.Default.vtUserName = txtVTuserName.Text;
                    sirketNetOpenXREST.Default.vtUserPsw = txtVTsifre.Text;
                    sirketNetOpenXREST.Default.netsisUserName = txtNetsisUserName.Text;
                    sirketNetOpenXREST.Default.netsisUserPsw = txtNetsisPassword.Text;
                    sirketNetOpenXREST.Default.host = txtServisCalismaAdresi.Text;
                    sirketNetOpenXREST.Default.branch = Convert.ToInt32(txtSube.Text);
                    sirketNetOpenXREST.Default.Save();


                }

                Global.SirketTanımRest();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                MessageBox.Show("Giriş Başarılı");
                Cursor.Current = Cursors.Default;
            }


        }

        private void frmNetOpenXREST_Load(object sender, EventArgs e)
        {
            txtDbName.Text = sirketNetOpenXREST.Default.dbName;
            txtVTuserName.Text = sirketNetOpenXREST.Default.vtUserName;
            txtVTsifre.Text = sirketNetOpenXREST.Default.vtUserPsw;
            txtNetsisUserName.Text = sirketNetOpenXREST.Default.netsisUserName;
            txtNetsisPassword.Text = sirketNetOpenXREST.Default.netsisUserPsw;
            txtServisCalismaAdresi.Text = sirketNetOpenXREST.Default.host;
            txtSube.Text = Convert.ToString(sirketNetOpenXREST.Default.branch);
        }

        private void btnCıkıs_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                MessageBox.Show("Çıkış yapıldı");
            }
        }

        private void faturaSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();


            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi

            var Result = _manager.DeleteInternalById("ftSFat;R00000000000171;1");  //Silme işleminin yapıldığı fonksiyon
        }

        private void ambarGirişFişiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips fatura = new ItemSlips()
            {

                FaturaTip = JTFaturaTip.ftAmbarG,
                FatUst = new ItemSlipsHeader()
                {

                    FATIRS_NO = "333334444488888",
                    AMBHARTUR = JTAmbarHarTur.htUretim,
                    CikisYeri = JTCikisYeri.cyMasrafMer,
                    KOD1 = "GARNIER",


                    KOD2 = "A-FIYAT",
                    Tarih = DateTime.Now,
                    ENTEGRE_TRH = DateTime.Now,
                    FiiliTarih = DateTime.Now,
                    DOVIZTIP = 1,



                    KDV_DAHILMI = true,
                    EFatOzelKod = 2,

                }
            };

            fatura.Kalems = new List<ItemSlipLines>();
            fatura.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "A-FIYAT",
                STra_GCMIK = 1,
                DEPO_KODU = 11,
                STra_BF = 15,
                MuhasebeKodu = "191 - 01 - 003",
                ReferansKodu = "3",
            });

            var result = _manager.PostInternal(fatura);
        }

        private void ambarÇıkışFişiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips fatura = new ItemSlips()
            {
                FaturaTip = JTFaturaTip.ftAmbarC,
                FatUst = new ItemSlipsHeader()
                {
                    FATIRS_NO = "222221117766687",
                    AMBHARTUR = JTAmbarHarTur.htUretim,
                    CikisYeri = JTCikisYeri.cyMasrafMer,
                    CariKod = "Üretim", //Masraf Kodu.
                    Tarih = DateTime.Now,
                    FiiliTarih = DateTime.Now,
                    ODEMETARIHI = DateTime.Now,

                    KDV_DAHILMI = true

                },
            };


            fatura.Kalems = new List<ItemSlipLines>();
            fatura.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "A-MAMUL",

                STra_GCMIK = 1,
                DEPO_KODU = 11,
                STra_BF = 15


            });

            var result = _manager.PostInternal(fatura);
        }

        private void faturaNumaraDeğişikliğiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi

            ItemSlipsChangeNumberParam changeprm = new ItemSlipsChangeNumberParam();

            var result = _manager.ChangeNumber(new ItemSlipsChangeNumberParam
            {

                DocumentNumber = "R00000000000173",
                NewDocumentNumber = "R00000000000174",
                CustomerCode = "1",
                NewCustomerCode = "M-0007",
                DocumentType = JTFaturaTip.ftSFat
            });
        }

        private void dövizliFaturaKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips fatura = new ItemSlips();

            ItemSlipsHeader FatUst = new ItemSlipsHeader();
            ItemSlipLines faturaKalem = new ItemSlipLines();



            FatUst.TIPI = JTFaturaTipi.ft_YurtIci;
            FatUst.CariKod = "1";
            FatUst.Tarih = DateTime.Now;
            FatUst.KDV_DAHILMI = false;
            fatura.FaturaTip = JTFaturaTip.ftSFat;

            fatura.FatUst = FatUst;
            fatura.KayitliNumaraOtomatikGuncellensin = true;
            fatura.Seri = "S";
            fatura.Kalems = new List<ItemSlipLines>();


            fatura.Kalems.Add(new ItemSlipLines
            {

                STra_GCMIK = 1,
                StokKodu = "A-MAMUL",
                STra_DOVTIP = 1,
                STra_DOVFIAT = 150,
                STra_BF = 150,
            });

            var result = _manager.PostInternal(fatura);
        }

        private void satışFaturasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi
            CompanyManager _CompanyManager = new CompanyManager(Global._oAuth2);
            
            
            ItemSlips slips = new ItemSlips();
            slips.FaturaTip = JTFaturaTip.ftSFat;
            slips.SeriliHesapla = false;
            
            //***Ortak işlem tipi ataması 9.0.40 seti ile eklenmiştir***********
            //modulislemTipi burada set ediliyor ve yeni token alınmadığı sürece mevcut _oAuth2 nesnesi ile oluşturulan tip managerlarda set edilen değer kullanılıyor
            slips.OtomatikIslemTipiGetir = false;
           // _CompanyManager.SetModuleProcessType(new ModuleProcessTypeParam { ModuleProcessType = "SF" });
            //******************************************************************
            slips.KayitliNumaraOtomatikGuncellensin = true;
            slips.FatUst = new ItemSlipsHeader
            {
               

                CariKod = "J0001",
                Tarih = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Ihracat,
                KDV_DAHILMI = false,
                Tip = JTFaturaTip.ftSFat
            };

            slips.Kalems = new List<ItemSlipLines>();

            slips.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "STOK1",
                Gir_Depo_Kodu = 2,
                STra_NF = 5,
                STra_BF = 8,
                DEPO_KODU = 1,
                STra_GCMIK = 3,
            });

            var RESULT = _manager.PostInternal(slips);
            if (RESULT.IsSuccessful)
            {
                MessageBox.Show("KAYIT BAŞARILI" + " " + RESULT.Data.FatUst.FATIRS_NO);
            }
            else
            {
                MessageBox.Show(RESULT.ErrorDesc);

            } 
        }

        private void satışİrsaliyeKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips slips = new ItemSlips();
            slips.FaturaTip = JTFaturaTip.ftSIrs;
            slips.SeriliHesapla = false;
            slips.KayitliNumaraOtomatikGuncellensin = true;
            slips.FatUst = new ItemSlipsHeader
            {
                CariKod = "1",
                Tarih = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Ihracat,
                KDV_DAHILMI = false,
                Tip = JTFaturaTip.ftSIrs
            };

            slips.Kalems = new List<ItemSlipLines>();

            slips.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "001",
                Gir_Depo_Kodu = 2,
                STra_NF = 5,
                STra_BF = 5,
                DEPO_KODU = 1,
                STra_GCMIK = 5,
            });

            var RESULT = _manager.PostInternal(slips); 
        }

        private void satışTeklifKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips slips = new ItemSlips();
            slips.FaturaTip = JTFaturaTip.ftSatTeklif;
            slips.SeriliHesapla = false;
            slips.KayitliNumaraOtomatikGuncellensin = true;
            slips.FatUst = new ItemSlipsHeader

            {
                CariKod = "00001",
                Tarih = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Ihracat,
                KDV_DAHILMI = false,
                Tip = JTFaturaTip.ftSatTeklif
            };


            slips.Kalems = new List<ItemSlipLines>();



            slips.Kalems.Add(new ItemSlipLines
            {

                StokKodu = "STK-1",
                Gir_Depo_Kodu = 1,
                STra_NF = 5,
                STra_BF = 5,
                DEPO_KODU = 1,
                STra_GCMIK = 5,
            });

            var RESULT = _manager.PostInternal(slips); 
        }

        private void sipariştenFaturaOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips Siparis = new ItemSlips();

            ItemSlipsHeader FatUst = new ItemSlipsHeader();

            var result_fat2 = _manager.GetInternalById("ftASip;999999999999999"); //Fat numarası değişir
            var data = result_fat2.Data;

            Siparis.FatUst = data.FatUst;
            Siparis.KayitliNumaraOtomatikGuncellensin = true;
            Siparis.Seri = "S";


            Siparis.FatUst.Tip = JTFaturaTip.ftSFat;
            Siparis.Kalems = new List<ItemSlipLines>();
            Siparis.Kalems.Add(new ItemSlipLines
            {

                StokKodu = data.Kalems[0].StokKodu.ToString(),
                STra_BF = data.Kalems[0].STra_BF,
                STra_GCMIK = data.Kalems[0].STra_GCMIK,
                DEPO_KODU = data.Kalems[0].DEPO_KODU,
                Stra_FiiliTar = data.Kalems[0].Stra_FiiliTar
            });

            var result = _manager.PostInternal(Siparis);
        }

        private void talepTeklifOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi

            var oku = _manager.GetInternalById("ftSatTalep;000000000000025");
            var data = oku.Data;

            ItemSlips fatura = new ItemSlips();
            fatura.FaturaTip = JTFaturaTip.ftSFat;
            ItemSlipsHeader FatUst = new ItemSlipsHeader();
            ItemSlipLines faturaKalem = new ItemSlipLines();
            fatura.KayitliNumaraOtomatikGuncellensin = true;
            fatura.FatUst = FatUst;

            FatUst.TIPI = JTFaturaTipi.ft_YurtIci;
            FatUst.CariKod = "1";
            FatUst.Aciklama = data.FatUst.FATIRS_NO.ToString();
            FatUst.Tarih = DateTime.Now;
            FatUst.KDV_DAHILMI = false;

            fatura.Kalems = new List<ItemSlipLines>();

            fatura.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "A-MAMUL",
                STra_GCMIK = 1,
                STra_DOVTIP = 1,
                STra_DOVFIAT = 150,
                STra_BF = 150,
            });



            var result = _manager.PostInternal(fatura);
        }

        private void parçalıSiparişTeslimatıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips slips = new ItemSlips();
            slips.FaturaTip = JTFaturaTip.ftSFat;
            ItemSlipsHeader fatUst = new ItemSlipsHeader();

            fatUst.FATIRS_NO = "000000000SDFKH1";
            fatUst.TIPI = JTFaturaTipi.ft_YurtDisi;
            fatUst.CariKod = "1";
            fatUst.Tarih = DateTime.Now;
            fatUst.SIPARIS_TEST = DateTime.Now;

            slips.FatUst = fatUst;

            slips.Kalems = new List<ItemSlipLines>();

            slips.Kalems.Add(new ItemSlipLines
            {

                StokKodu = "A-MAMUL",
                STra_GCMIK = 55,
                STra_BF = 21110000,
                STra_SIPNUM = "000000000SNGL12",
                STra_SIPKONT = 5,

            });

            var result = _manager.PostInternal(slips);
        }

        private void değişkenÖlçüBirimlerininKullanılmasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips fatura = new ItemSlips();
            fatura.FaturaTip = JTFaturaTip.ftSFat;
            ItemSlipsHeader faturaUst = new ItemSlipsHeader();
            ItemSlipLines faturaKalem = new ItemSlipLines();


            faturaUst.TIPI = JTFaturaTipi.ft_Acik;
            faturaUst.CariKod = "1";
            fatura.Seri = "A";
            fatura.KayitliNumaraOtomatikGuncellensin = true;
            fatura.FatUst = faturaUst;
            fatura.SeriliHesapla = false;
            fatura.Kalems = new List<ItemSlipLines>();

            fatura.OtomatikCevrimYapilsin = false;

            fatura.Kalems.Add(new ItemSlipLines
            {

                Olcubr = 2,
                StokKodu = "A-MAMUL",
                STra_GCMIK = 25,
                STra_GCMIK2 = 0,
                CEVRIM = 0.2,
                STra_BF = 1,

            });

            fatura.OtomatikCevrimYapilsin = true;

            fatura.Kalems.Add(new ItemSlipLines
            {
                Olcubr = 2,
                StokKodu = "01",
                STra_GCMIK = 5,
                STra_GCMIK2 = 25,
                STra_BF = 1

            });

            fatura.OtomatikCevrimYapilsin = true;

            var result = _manager.PostInternal(fatura);
        }

        private void faturaOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);  //_oAuth2 token bilgisi


            ItemSlips fatura = new ItemSlips();

            ItemSlipLines fatKalem = new ItemSlipLines();


            var fat = _manager.GetInternalById("ftSFat;R00000000000173;1");
            if (fat.Data != null) ////Fatura okunabiliyorsa güncelle
            {


                fatura = fat.Data;
                fatura.FaturaTip = JTFaturaTip.ftSFat;
                fatura.Seri = "S";
                fatura.FatUst.GIB_FATIRS_NO = "GR00000000000174";
                fatura.KayitliNumaraOtomatikGuncellensin = true;

                var result = _manager.PostInternal(fatura);
            }
        }

        private void siparişKopyalamaVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            CopyItemSlipParam param = new CopyItemSlipParam();

            param.DocumentType = JTFaturaTip.ftSFat;
            param.OldDocNumber = "S52201500072511";
            param.NewDocNumber = "S52201500072512";
            param.NewGIBDocNumber = "S522021000072512";
            param.DomesticTransaction = true;

            TResult<string> result = _manager.CopyItemSlip(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı.");
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void siparişRevizyonVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            OrderRevisionParam revisionParam = new OrderRevisionParam();

            revisionParam.ItemSlip = new ItemSlips();
            revisionParam.ItemSlip.FatUst = new ItemSlipsHeader
            {
                FATIRS_NO = "M00000000000695",
                CariKod = "1",
                Tarih = DateTime.Now,
                Tip = JTFaturaTip.ftSSip,
            };

            revisionParam.ItemSlip.Kalems = new List<ItemSlipLines>();
            revisionParam.ItemSlip.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "2",
                DEPO_KODU = 1,
                STra_GCMIK = 1,
                STra_BF = 10,
            });

            revisionParam.RevisionOrderNumber = "M00000000000694";
            revisionParam.DeliverStartingDate = DateTime.Now;

            TResult<string> result = _manager.OrderRevision(revisionParam);
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı.");
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void halFaturasıVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager InvoiceManager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips invoice = new ItemSlips();
            invoice.Seri = "CLK";
            invoice.FatUst = new ItemSlipsHeader
            {
                CariKod = "EFAT",
                Tarih = DateTime.Now,
                SIPARIS_TEST = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Acik,
                KDV_DAHILMI = false,
                Tip = JTFaturaTip.ftSFat,
                HalFaturasi = JTHalFatTipi.hftHalKomisyon,
            };
            invoice.Kalems = new List<ItemSlipLines>();
            invoice.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "barkod",
                DEPO_KODU = 1,
                STra_DOVTIP = 0,
                STra_GCMIK = 1,
                STra_NF = 10,
                KunyeNo = "1234567890123456878"
            });
            invoice.HalFaturaMasraflari = (new FruitVegMarketBillInfo
            {
                HKSKOMISYONKDVORAN = 1,
                HKSKOMISYONKDVTUTAR = 1.1,
                HKSKOMISYONORAN = 1.2,
                HKSKOMISYONTUTAR = 1.3,
                HKSNAVLUNKDVORAN = 2,
                HKSNAVLUNKDVTUTAR = 2.1,
                HKSNAVLUNORAN = 2.2,
                HKSNAVLUNTUTAR = 2.3,
                HKSHAMMALIYEKDVORAN = 3,
                HKSHAMMALIYEKDVTUTAR = 3.1,
                HKSHAMMALIYEORAN = 3.2,
                HKSHAMMALIYETUTAR = 3.3,
                HKSGELIRVERGORAN = 4,
                HKSGELIRVERKDVORAN = 4.1,
                HKSGELIRVERKDVTUTAR = 4.2,
                HKSGELIRVERTUTAR = 4.3,
                HKSBAGTEVGORAN = 5,
                HKSBAGTEVKDVORAN = 5.1,
                HKSBAGTEVKDVTUTAR = 5.2,
                HKSBAGTEVTUTAR = 5.3,
                HKSRUSUMKDVORAN = 6,
                HKSRUSUMKDVTUTAR = 6.1,
                HKSRUSUMORAN = 6.2,
                HKSRUSUMTUTAR = 6.3,
                HKSTICBORSASI = 7,
                HKSTICBORSASIKDVORAN = 7.1,
                HKSTICBORSASIKDVTUTAR = 7.2,
                HKSTICBORSASITUTAR = 7.3,
                HKSMILLISAVUNMAFON = 8,
                HKSMILLISAVUNMAFONKDVORAN = 8.1,
                HKSMILLISAVUNMAFONKDVTUTAR = 8.2,
                HKSMILLISAVUNMAFONTUTAR = 8.3,
                HKSDIGERFON = 9,
                HKSDIGERKDVORAN = 9.1,
                HKSDIGERKDVTUTAR = 9.2,
                HKSDIGERTUTAR = 9.3,
                HKSNAKLIYE = 10,
                HKSNAKLIYEKDVORAN = 10.1,
                HKSNAKLIYEKDVTUTAR = 10.2,
                HKSNAKLIYETUTAR = 10.3
            });

            TResult<ItemSlips> RESULT = InvoiceManager.PostInternal(invoice);
            if (RESULT.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı." + RESULT.Data.FatUst.FATIRS_NO);
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void eBelgeCariGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            EDocumentManager eBelge = new EDocumentManager(Global._oAuth2);

            TResult<bool> result = eBelge.EDocCurrentUpdate();
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem bitti.");
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void eBelgeKabulRetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            EDocumentManager eBelge = new EDocumentManager(Global._oAuth2);
            EDocumentResponseParam param = new EDocumentResponseParam();

            param.GIBDocumentNumber = "AAA";
            param.EDocumentType = JTEBelgeTip.ebtEFatura;
            param.ResponseType = JTEBelgeYanitTipi.ytKabul;

            TResult<string> result = eBelge.EDocumentResponse(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Sonuç: " + result.Data);
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void eBelgeKalemKabulRetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            EDocumentManager eBelge = new EDocumentManager(Global._oAuth2);
            EDocumentItemResponseParam param = new EDocumentItemResponseParam();

            param.GIBDocumentNumber = "AAA";
            param.EDocumentType = JTEBelgeTip.ebtEFatura;
            param.ItemResponses = new List<EDocumentResponseItem>();
            param.ItemResponses.Add(new EDocumentResponseItem
            {
                YanitKalemSiraNo = 1,
                YanitRetMiktar = 2,
                YanitRetOlcuBr = "AD",
                YanitKalemAciklama = "Ret kalem"
            });
            param.ItemResponses.Add(new EDocumentResponseItem
            {
                YanitKalemSiraNo = 2,
                YanitTeslimMiktar = 5,
                YanitTeslimOlcuBr = "AD",
                YanitKalemAciklama = "Kabul Kalem"
            });

            TResult<string> result = eBelge.EDocumentItemResponse(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Sonuç: " + result.Data);
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void eBelgeİptalFaturasıOluşturToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            EDocumentManager eBelge = new EDocumentManager(Global._oAuth2);
            EArchiveCancelInvoiceParam param = new EArchiveCancelInvoiceParam();

            param.DocumentNumber = "AAAA";

            TResult<bool> result = eBelge.EArchiveCancellationInvoice(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Sonuç: " + result.Data);
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void yeniEArsivNumaraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);

            TResult<string> result = _manager.NewEArchiveNumber("EAR");
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı.");
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı.");
            }
        }

        private void eIrsaliyeKaydetmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            ItemSlipsManager InvoiceManager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips tmpSlip = new ItemSlips();
            tmpSlip.FaturaTip = JTFaturaTip.ftSIrs;
            tmpSlip.SeriliHesapla = false;
            //tmpSlip.KayitliNumaraOtomatikGuncellensin = true;
            //tmpSlip.Seri = "EIR";

            var fatNo = InvoiceManager.NewEWaybillNumber(new NetOpenX.Rest.Client.Model.Custom.ItemSlipsCodeParam()
            {
                DocumentType = JTFaturaTip.ftSIrs,
                Code = "EIR"
            });

            tmpSlip.FatUst = new ItemSlipsHeader
            {
                //FATIRS_NO = "EIR000000000112",
                FATIRS_NO = fatNo.Data.ToString(),
                CariKod = "120-01-014",
                Tarih = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Acik,
                KDV_DAHILMI = false,
                Tip = JTFaturaTip.ftSIrs
            };

            tmpSlip.Kalems = new List<ItemSlipLines>();

            tmpSlip.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "MAMUL1",
                DEPO_KODU = 1,
                STra_GCMIK = 5
            });


            //tmpSlip.FatUst.EIrsaliye = true;
            tmpSlip.EIrsEkBilgi = new EWaybillInfo
            {
                PLAKA = "35IUP35",
                TASIYICIVKN = "0010079308",
                TASIYICIADI = "Ahmet",
                TASIYICIILCE = "Bornova",
                TASIYICIIL = "İzmir",
                TASIYICIULKE = "TR",
                TASIYICIPOSTAKODU = "35100",
                SOFOR1ADI = "Mehmet",
                SOFOR1SOYADI = "Ata",
                SOFOR1ACIKLAMA = "Kamyoncu",
                SOFOR1TCKN = "12345678910",
                SEVKTAR = DateTime.Parse("2019-07-23 10:30:23"),
                DORSEPLAKA1 = "35IUP35",
                DORSEPLAKA2 = "35MRP35"
            };
            var tmpResult = InvoiceManager.PostInternal(tmpSlip);

            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Yapıldı" + tmpResult.Data.FatUst.FATIRS_NO);

            }
            else
            {
                MessageBox.Show(tmpResult.ErrorDesc);
            }
        }

        private void eIrsaliyeTaslakOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocument tmpEDoc = new EDocument();
            tmpEDoc.Tip = JTEBelgeTip.ebtEIrs;
            tmpEDoc.BelgeNo = "EIR000000000112";
            tmpEDoc.DizaynKontrol = false;

            var tmpResult = EDocumentManager.PostInternal(tmpEDoc);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + tmpResult.Data.BelgeNo);
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void eIrsaliyeGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocumentSendParam tmpEDocParam = new EDocumentSendParam
            {
                EDocumentType = JTEBelgeTip.ebtEIrs,
                DocumentNumber = "EIR000000000112",
                CustomerCode = "120-01-014",
                DocumentType = JTFaturaTip.ftSIrs
            };

            var tmpResult = EDocumentManager.SendEDocument(tmpEDocParam);
        }

        private void eIrsaliyeGörüntülemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocumentShowParam tmpEDocParam = new EDocumentShowParam
            {
                EDocumentType = JTEBelgeTip.ebtEIrs,
                GIBDocumentNumber = "EIR2020000000112",
                DocumentBoxType = JTEBelgeBoxType.ebAll,
                HtmlPath = "C://TEMP",
                EnvelopeId = ""
            };

            var tmpResult = EDocumentManager.ShowEDocument(tmpEDocParam);
        }

        private void eFaturaKaydetmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
           

            ItemSlipsManager InvoiceManager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips tmpSlip = new ItemSlips();
            tmpSlip.FaturaTip = JTFaturaTip.ftSFat;
            tmpSlip.SeriliHesapla = false;
            tmpSlip.KayitliNumaraOtomatikGuncellensin = true;
            tmpSlip.Seri = "CLK";
            tmpSlip.FatUst = new ItemSlipsHeader
            {
                CariKod = "EFAT",
                Tarih = DateTime.Now,
                TIPI = JTFaturaTipi.ft_Acik,
                KDV_DAHILMI = true,
                Tip = JTFaturaTip.ftSFat,
                Proje_Kodu = "1"
            };

            tmpSlip.Kalems = new List<ItemSlipLines>();

            tmpSlip.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "MAMUL1",
                DEPO_KODU = 1,
                STra_GCMIK = 5
            });

            var tmpResult = InvoiceManager.PostInternal(tmpSlip);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Yapıldı" + tmpResult.Data.FatUst.FATIRS_NO);

            }
            else
            {
                MessageBox.Show(tmpResult.ErrorDesc);
            }
        }

        private void eFaturaTaslakOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocument tmpEDoc = new EDocument();
            tmpEDoc.Tip = JTEBelgeTip.ebtEFatura;
            tmpEDoc.BelgeNo = "CLK000000000081";
            tmpEDoc.DizaynKontrol = false;

            var tmpResult = EDocumentManager.PostInternal(tmpEDoc);
            if (tmpResult.IsSuccessful)
            {

                MessageBox.Show("Taslak Oluşturuldu");

            }
            else
            {
                MessageBox.Show(tmpResult.ErrorDesc);

            }
        }

        private void eFaturaGöndermeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocumentSendParam tmpEDocParam = new EDocumentSendParam
            {
                EDocumentType = JTEBelgeTip.ebtEFatura,
                DocumentNumber = "CLK000000000081",
                CustomerCode = "EFAT",
                DocumentType = JTFaturaTip.ftSFat
            };

            var tmpResult = EDocumentManager.SendEDocument(tmpEDocParam);
        }

        private void eFaturaGörüntülemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;
            EDocumentManager EDocumentManager = new EDocumentManager(Global._oAuth2);

            EDocumentShowParam tmpEDocParam = new EDocumentShowParam
            {
                EDocumentType = JTEBelgeTip.ebtEFatura,
                GIBDocumentNumber = "CLK2020000000081",
                DocumentBoxType = JTEBelgeBoxType.ebAll,
                HtmlPath = "C://TEMP",
                EnvelopeId = ""
            };

            var tmpResult = EDocumentManager.ShowEDocument(tmpEDocParam);
        }

        private void irsaliyeFaturaBasımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
         
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\test.pdf"; //Verilen dizayn kodu görsel dizaynsa byte array PDF olarak oluşur, değilse text dosyası olarak. 
            PrintManager printMan = new PrintManager(Global._oAuth2);
            ItemSlipsItemsBatchBarcodePrintParam param = new ItemSlipsItemsBatchBarcodePrintParam();
            param.DocumentNumber = "R00000000002130";
            param.DocumentType = JTFaturaTip.ftSFat;
            param.DesignCode = "BRKD1";
            param.PrintCount = 1;
            var result = printMan.ItemSlipsItemsBatchBarcodePrinting(param);
            if (result.IsSuccessful)
            {
                File.WriteAllBytes(desktopPath, result.Data); //istenilen dizine yazılır. 
            } 
        }

        private void irsaliyeFaturaKalemBasımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\test.pdf"; //Verilen dizayn kodu görsel dizaynsa byte array PDF olarak oluşur, değilse text dosyası olarak.             
            PrintManager printMan = new PrintManager(Global._oAuth2);
            ItemSlipsItemBarcodePrintParam param = new ItemSlipsItemBarcodePrintParam();
            param.DocumentNumber = "R00000000002130";
            param.DocumentType = JTFaturaTip.ftSFat;
            param.DesignCode = "BRKD1";
            param.PrintCount = 1;
            param.ItemNumber = 1;
            var result = printMan.ItemSlipsItemBarcodePrinting(param);
            if (result.IsSuccessful)
            { 
                File.WriteAllBytes(desktopPath, result.Data); //istenilen dizine yazılır. 
            } 
        }

        private void stokKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Global.SirketTanımRest();

            ItemsManager _manager = new ItemsManager(Global._oAuth2);

            Items items = new Items();
            items.StokTemelBilgi = new ItemsPrimInfo()

            {

                Stok_Kodu = "ST4",
                Stok_Adi = "Stok Adi",
                KDV_Orani = 18,
                Alis_Kdv_Kodu = 18,
                Satis_Fiat1 = 120,
                Satis_Fiat2 = 125,
                Alis_Fiat1 = 110,
                Alis_Fiat2 = 115,
                Giris_Seri = "E",
                Cikis_Seri = "E",
                Pay_1 = 1,
                Payda_1 = 1,
                Pay2 = 1,
                Payda2 = 1,


            };

            items.StokEkBilgi = new ItemsSuppInfo()
            {
                Stok_Kodu = "ST4",
                Ingisim = items.StokTemelBilgi.Stok_Kodu,
                I_Yedek1 = 40000,

            };

            var result = _manager.PostInternal(items);
        }

        private void stokHareketKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            ItemTransactionsManager _manager = new ItemTransactionsManager(Global._oAuth2);

            ItemTransactions StHar = new ItemTransactions();

            StHar.Stok_Kodu = "STOK-1";
            StHar.Sthar_Tarih = DateTime.Now;
            StHar.Sthar_Htur = "M";
            StHar.Sthar_Bf = 12;
            StHar.Sthar_Gckod = "G";
            StHar.DEPO_KODU = 1;
            StHar.Sthar_Gcmik = 6;
            //StHar.Plasiyer_Kodu = "02";
            StHar.Proje_Kodu = "101-002";


            var result = _manager.PostInternal(StHar); 
        }

        private void stokDüzenlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemsManager _manager = new ItemsManager(Global._oAuth2);
            var id = "asdasddsa";

            var result = _manager.PutInternal(id, new Items
            {
                StokTemelBilgi = new ItemsPrimInfo
                {
                    Satis_Fiat1 = 100,
                    Satis_Fiat2 = 105,
                    Alis_Fiat1 = 100,
                    Alis_Fiat2 = 115,
                }
            });
        }

        private void talepTeklifYeniNumaraVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();


            DemandOfferManager offer = new DemandOfferManager(Global._oAuth2);
            ItemSlipsCodeParam code = new ItemSlipsCodeParam();
            code.DocumentType = JTFaturaTip.ftSatTalep;
            code.Code = "T";
            var Result = offer.NewNumber(code);
            if (Result.IsSuccessful)
            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void satışSatınAlmaTalepTeklifleştirmeVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            DemandOfferManager offer = new DemandOfferManager(Global._oAuth2);
            ConvertToOfferParam param = new ConvertToOfferParam();
            List<DemandOfferConversionDocument> docList = new List<DemandOfferConversionDocument>();

            ItemSlipsCodeParam code = new ItemSlipsCodeParam();
            code.DocumentType = JTFaturaTip.ftSatTeklif;
            code.Code = "T";
            TResult<string> docNumber = offer.NewNumber(code);

            param.KaynakBelgeTipi = JTFaturaTip.ftSatTalep;
            param.Parametreler = new DemandOffer
            {
                BelgeTipi = JTFaturaTip.ftSatTeklif,
                BelgeNo = docNumber.Data
            };

            docList.Add(new DemandOfferConversionDocument //Burada teklifleştirilecek belge ve kalemler for döngüsüyle bir listeye doldurulur.
            {
                DocumentNumber = "A00000000000010",
                CurrentCode = "120-01-014",
                ItemOrderNo = 1
            });
            param.Belgeler = docList;
            TResult<string> result = offer.ConvertToOffer(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı." + result.Data);
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı." + result.ErrorDesc);
            }
        }

        private void satışSatınAlmaTeklifSiparişleştirmeVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            DemandOfferManager order = new DemandOfferManager(Global._oAuth2);
            ConvertToOrderParam param = new ConvertToOrderParam();
            List<DemandOfferConversionDocument> docList = new List<DemandOfferConversionDocument>();

            ItemSlipsCodeParam code = new ItemSlipsCodeParam();
            code.DocumentType = JTFaturaTip.ftSSip;
            code.Code = "S";
            TResult<string> docNumber = order.NewNumber(code);

            param.KaynakBelgeTipi = JTFaturaTip.ftSatTeklif;
            param.Parametreler = new DemandOffer
            {
                BelgeTipi = JTFaturaTip.ftSSip,
                BelgeNo = docNumber.Data
            };

            docList.Add(new DemandOfferConversionDocument //Burada siparişleştirecek belge ve kalemler for döngüsüyle bir listeye doldurulur.
            {
                DocumentNumber = "000000000000091",
                CurrentCode = "120-01-014",
                ItemOrderNo = 1
            });
            param.Belgeler = docList;
            TResult<string> result = order.ConvertToOrder(param);
            if (result.IsSuccessful)
            {
                MessageBox.Show("İşlem tamamlandı.");
            }
            else
            {
                MessageBox.Show("İşlem tamamlanamadı." + result.ErrorDesc);
            }
        }

        private void dinamikDepoHareketGirişindeSeriDesteğiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            DynamicWarehsSlipsManager _manager = new DynamicWarehsSlipsManager(Global._oAuth2);
            DynamicWarehsSlips tmpData = new DynamicWarehsSlips();

            tmpData.BelgeNumarasi = "000000000000194";
            tmpData.BelgeTipi = JTDepoBelgeTipi.dbtAlisFaturasi;
            tmpData.CariKodu = "ALICI 4";
            tmpData.HareketTipi = JTDepoIslemTipi.ditYerlestirme;
            tmpData.HareketAdedi = 1;

            tmpData.Harekets = new List<DynWarehsSlipLines>();
            DynWarehsSlipLines tmpHareket = new DynWarehsSlipLines();
            tmpHareket.Miktar = 5;
            tmpHareket.StokKodu = "SS_SERI_M1";
            tmpHareket.GirisDepoKodu = 4;

            tmpHareket.HucreHareketKalems = new List<DynWarehsSlipCellLines>();
            DynWarehsSlipCellLines tmpHucreHarKalem = new DynWarehsSlipCellLines();
            tmpHucreHarKalem.StokKodu = "SS_SERI_M1";
            tmpHucreHarKalem.HucreKodu = "H3";
            tmpHucreHarKalem.NetMiktar = 5;

            tmpHucreHarKalem.SeriList = new List<ItemSlipLineSeries>();
            ItemSlipLineSeries tmpSeri = new ItemSlipLineSeries();
            tmpSeri.Seri1 = "X1";
            tmpSeri.Miktar = 5;
            tmpHucreHarKalem.SeriList.Add(tmpSeri);

            tmpHareket.HucreHareketKalems.Add(tmpHucreHarKalem);
            tmpData.Harekets.Add(tmpHareket);
            _manager.PostInternal(tmpData);
        }

        private void dinamikDepoHücreYerleştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            DynamicWarehsSlipsManager _manager = new DynamicWarehsSlipsManager(Global._oAuth2);
            DynamicWarehsSlips depo = new DynamicWarehsSlips();
            DynWarehsSlipLines hareket = new DynWarehsSlipLines();
            DynWarehsSlipCellLines harKalem = new DynWarehsSlipCellLines();

            depo.BelgeTipi = JTDepoBelgeTipi.dbtDepolarArasiTransfer;
            depo.HareketTipi = JTDepoIslemTipi.ditYerlestirme;
            depo.BelgeNumarasi = "0000000000000X1";
            depo.CariKodu = "00001";
            harKalem.NetMiktar = hareket.Miktar;
            harKalem.HareketTipi = JTDepoHareketTipi.dhtNormal;
            depo.Harekets = new List<DynWarehsSlipLines>()
                {
                    new DynWarehsSlipLines()
                    {
                        HucreHareketKalems = new List<DynWarehsSlipCellLines>()
                        {
                            new DynWarehsSlipCellLines()
                            {
                                HucreKodu = "33",
                                NetMiktar = 5,
                                HareketTipi = JTDepoHareketTipi.dhtNormal,
                                StokKodu = "STOK-1"
                            }
                        }
                    }
                };

            var result = _manager.PostInternal(depo); 
        }

        private void depolarArasıTransferKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);

            ItemSlips fatura = new ItemSlips()
            {
                FaturaTip = JTFaturaTip.ftDepo,

                FatUst = new ItemSlipsHeader()
                {

                    TIPI = JTFaturaTipi.ft_Bos,
                    Tarih = DateTime.Today,
                    KDV_DAHILMI = true,
                    //Hareket türü
                    AMBHARTUR = JTAmbarHarTur.htDepolar,
                    Sube_Kodu = 1,
                    //GCKOD_CIKIS = 100,
                    ////Gideceği depo
                    //GCKOD_GIRIS = 200,
                    //Cari Kodu Fatura Tipi ftLokalDepo ise doldurulmamalıdır
                    CariKod = "M-10",
                    //Ambar
                    CARI_KOD2 = "320-01-041"

                }
            };


            fatura.Seri = "D";
            fatura.KayitliNumaraOtomatikGuncellensin = true;


            fatura.Kalems = new List<ItemSlipLines>();
            fatura.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "A-MAMUL",
                //Giriş Depo Kodu
                Gir_Depo_Kodu = 1001,
                //Depo Kodu
                DEPO_KODU = 1,
                STra_GCMIK = 20,
                STra_BF = 100,
                ReferansKodu = "3"


            });

            var result = _manager.PostInternal(fatura);
        }

        private void lokalDepolarArasıTransferKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            ItemSlips fatura = new ItemSlips();

            fatura.FaturaTip = JTFaturaTip.ftSFat;

            fatura.FatUst = new ItemSlipsHeader();
            fatura.FatUst.CariKod = "M-0007";

            fatura.FatUst.TIPI = JTFaturaTipi.ft_Acik;
            fatura.FatUst.AMBHARTUR = JTAmbarHarTur.htDepolar;
            fatura.FatUst.Tarih = DateTime.Now;
            fatura.FatUst.FiiliTarih = DateTime.Now;
            // fatura.FatUst.PLA_KODU = "S001";
            // fatura.FatUst.Proje_Kodu = "P001";
            fatura.FatUst.KDV_DAHILMI = true;

            fatura.Kalems = new List<ItemSlipLines>();
            fatura.Kalems.Add(new ItemSlipLines
            {
                StokKodu = "A-MAMUL",
                ReferansKodu = "1",
                Gir_Depo_Kodu = 2,
                DEPO_KODU = 1,
                STra_GCMIK = 20,
                STra_BF = 10,
                MuhasebeKodu = "3"

            });
            var result = _manager.PostInternal(fatura);
        }

        private void hızlıTahsilatKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            MixedReceiptsMainManager _manager = new MixedReceiptsMainManager(Global._oAuth2);
            MixedReceiptsMain TahsilAna = new MixedReceiptsMain()
            {
                IslemTarihi = DateTime.Today,
                BelgeNo = "3",
                CariKod = "M-0007",
                KasaKod = "00"



            };
            TahsilAna.Tahsilats = new List<MixedReceipts>();
            TahsilAna.Tahsilats.Add(new MixedReceipts
            {

                SozKodu = "NAKİT",
                Tutar = 12,
                Referans_Kodu = "01"

            });

            var result = _manager.PostInternal(TahsilAna);
        }

        private void hızlıTahsilatOluşturToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _manager = new MixedReceiptsMainManager(Global._oAuth2);
            var _dummyMixedReceiptsMain = new MixedReceiptsMain()
            {
                IslemTarihi = new DateTime(2015, 10, 27),
                KasaKod = "01",
                BelgeNo = "56565656",
                CariKod = "00001",
                DOVTIP = 0,
                Tahsilats = new List<MixedReceipts>()
                {
                    new MixedReceipts()
                    {
                        Aciklama = "a",
                        SozKodu = "NAKIT",
                        Tutar = 15,
                        PLA_KODU = "1",
                        Referans_Kodu = "1",
                        TaksitSay = 0,
                        DovTutar = 3,
                        Kur = 4,
                        Proje_Kodu = "1"
                    },
                    new MixedReceipts()
                    {
                        Aciklama = "b",
                        SozKodu = "NAKIT",
                        Tutar = 20,
                        PLA_KODU = "1",
                        Referans_Kodu = "1",
                        TaksitSay = 0,
                        DovTutar = 6,
                        Kur = 8,
                        Proje_Kodu = "1"
                    }
                }
            };

            var postResult = _manager.PostInternal(_dummyMixedReceiptsMain);
        }

        private void hızlıTahsilatSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _manager = new MixedReceiptsMainManager(Global._oAuth2);
            var _dummyMixedReceiptsMain = new MixedReceiptsMain()
            {
                IslemTarihi = new DateTime(2015, 10, 27),
                KasaKod = "01",
                BelgeNo = "56565656",
                CariKod = "00001",
                DOVTIP = 0,
                Tahsilats = new List<MixedReceipts>()
                {
                    new MixedReceipts()
                    {
                        Aciklama = "a",
                        SozKodu = "NAKIT",
                        Tutar = 15,
                        PLA_KODU = "1",
                        Referans_Kodu = "1",
                        TaksitSay = 0,
                        DovTutar = 3,
                        Kur = 4,
                        Proje_Kodu = "1"
                    },
                    new MixedReceipts()
                    {
                        Aciklama = "b",
                        SozKodu = "NAKIT",
                        Tutar = 20,
                        PLA_KODU = "1",
                        Referans_Kodu = "1",
                        TaksitSay = 0,
                        DovTutar = 6,
                        Kur = 8,
                        Proje_Kodu = "1"
                    }
                }
            };
            var deleteResult = _manager.DeleteInternalByParam(new MixedReceiptsMainParam()
            {
                KasaKod = _dummyMixedReceiptsMain.KasaKod,
                BelgeNo = _dummyMixedReceiptsMain.BelgeNo,
                CariKod = _dummyMixedReceiptsMain.CariKod,
                IslemTarihi = _dummyMixedReceiptsMain.IslemTarihi.Value
            });
        }

        private void hızlıTahsilatGetirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _manager = new MixedReceiptsMainManager(Global._oAuth2);

            // KasaKod;BelgeNo;CariKod;IslemTarihi
            var result = _manager.GetInternalById("01;45454545;00001;2015-10-27");
            var data = result.Data;
        }

        private void cariDövizFarkıKapamaVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ARPsExRatesInfo tmpParam = new ARPsExRatesInfo();
            tmpParam.CariKodu1 = "120-01-013";
            tmpParam.CariKodu2 = "120-01-014";
            tmpParam.HareketTipbas = JTHareketTipAraligi.Devir;
            tmpParam.HareketTipson = JTHareketTipAraligi.Muhtelif;
            tmpParam.TarihAraligi = JTTarihAraligi.TKayit;
            tmpParam.KurTarihi = DateTime.Now;
            tmpParam.DovTipBas = 1;
            tmpParam.DovTipSon = 100;
            tmpParam.ReferansKodu = string.Empty;
            tmpParam.BorcAlacak = JTBorcAlacak.cdHepsi;
            tmpParam.DovizCevrimTipi = JTDovCevrimTipi.DovizSatis;
            tmpParam.SifirBakiyeDahilMi = true;
            tmpParam.SubeKirilimli = true;
            tmpParam.SadeceDovizliCariler = true;
            tmpParam.DovizBakiyesiSifirOlanlarDahil = true;
            tmpParam.ProjeKoduKirilimli = true;
            tmpParam.BasTarih = Convert.ToDateTime(DateTime.Now.AddDays(-100).ToString("dd/MM/yyyy"));
            tmpParam.BitTarih = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));

            var Result = _manager.ArpsBalanceExchangeDiff(tmpParam);

            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void muhasebeAydanAyaFişAktarımıVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            MontlyVoucherTransferParam tmpParam = new MontlyVoucherTransferParam();
            tmpParam.AktEskiFisSilinsin = false;
            tmpParam.AktYeniAcik = "rest aciklama";
            tmpParam.KaynakFisNo = "000000000000056";
            tmpParam.KaynakAy = 9;
            tmpParam.HedefAy = 9;
            tmpParam.HedefFisNo = "000000000000057";
            tmpParam.AktEskiFisSilinsin = true;
            tmpParam.DegisecekAcik = "xxxx";
            tmpParam.EvrakTarHedefTarOlsun = true;
            var Result = _manager.MontlyVoucherTransfer(tmpParam);
            if (Result.IsSuccessful)
            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void muhasebeHesapKoduAktarımıVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            AccountTransferParam tmpParam = new AccountTransferParam();
            tmpParam.AktarimTuru = JTMuhAktTuru.atAlacak;
            tmpParam.AktBasTarih = Convert.ToDateTime(DateTime.Now.AddDays(-100).ToString("dd/MM/yyyy"));
            tmpParam.AktBitTarih = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
            tmpParam.AktIlkFisNo = "000000000000052";
            tmpParam.AktSonFisNo = "000000000000055";
            tmpParam.AktSubeDahil = true;
            tmpParam.EskiMuavin = "600-01-001";
            tmpParam.YeniMuavin = "320-01-041";
            var Result = _manager.AccountTransfer(tmpParam);
            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void açıkReçeteAnaliziÇalıştırVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ExecuteOpenRecipeAnalysisParam tmpParam = new ExecuteOpenRecipeAnalysisParam();
            tmpParam.BaslangicStokKodu = "MMLX1";
            tmpParam.BitisStokKodu = "MMLX1";
            tmpParam.Sira = JTAcikReceteBilesenSirasi.arbsGirisSirasi;
            var Result = _manager.ExecuteOpenRecipeAnalysis(tmpParam);

            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ItemBalances tmpParam = new ItemBalances();

            tmpParam.Stok_Kodu = "stok1";
            var tmpResult = _manager.BringBalance(tmpParam);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("İşlem Tamamlandı:");
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void stokBakiyeGetirVers9037VeSonrasıToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ArpsMovementControlParam tmpParam = new ArpsMovementControlParam();
            tmpParam.CariKodu = "120-01-013";
            var Result = _manager.ArpsMovementControl(tmpParam);

            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void cariHareketKontrolVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ArpsMovementControlParam tmpParam = new ArpsMovementControlParam();
            tmpParam.CariKodu = "120-01-013";
            var Result = _manager.ArpsMovementControl(tmpParam);

            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void cariKoduDeğiştirVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ChangeArpsCodeParam tmpParam = new ChangeArpsCodeParam();
            tmpParam.EskiKod = "120-01-025";
            tmpParam.YeniKod = "120-01-024";
            tmpParam.VirmanSonrasiEskiKodSilinsin = false;
            tmpParam.VirmanYapilsin = true;
            var Result = _manager.ChangeArpsCode(tmpParam);

            if (Result.IsSuccessful)
            {
                MessageBox.Show("Tamamlandı");
            }
            else
                MessageBox.Show(Result.ErrorDesc + " " + Result.ErrorCode);
        }

        private void ePostaGönderVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            SendEmailParam tmpParam = new SendEmailParam();
            tmpParam.EMailTO = "deneme@logo.com.tr";
            tmpParam.EMailBody = "Bu bir Rest deneme Mailidir.";
            tmpParam.EMailKonu = "Rest Deneme Konu";
            var Result = _manager.SendEmail(tmpParam);

            if (Result.IsSuccessful)
            {
                MessageBox.Show("Tamamlandı");
            }
            else
                MessageBox.Show(Result.ErrorDesc + " " + Result.ErrorCode);
        }

        private void yevmiyeFişNumaraDeğişikliğiVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ChangeItemSlipNumberParam tmpParam = new ChangeItemSlipNumberParam();
            tmpParam.AyKodu = 11;
            tmpParam.FisNumara = "000000000000078";
            tmpParam.YeniFisNumara = "000000000000079";
            var Result = _manager.ChangeItemSlipNumber(tmpParam);

            if (Result.IsSuccessful)
            {
                MessageBox.Show("Tamamlandı");
            }
            else
                MessageBox.Show(Result.ErrorDesc + " " + Result.ErrorCode);
        }

        private void görselRaporÇalıştırVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            ExecuteVisualReportDraftParam tmpParam = new ExecuteVisualReportDraftParam();
            tmpParam.TaslakId = 9;
            tmpParam.DosyaYolu = "C:/TEMP/Files";

            var tmpResult = _manager.ExecuteVisualReportDraft(tmpParam);

            if (tmpResult.IsSuccessful)

            { MessageBox.Show("İşlem Tamamlandı:" + tmpResult.Data); }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void stokBağlantıOluşturVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            var Result = _manager.RecipeStockLinkCreate();

            if (Result.IsSuccessful)
            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void stokHareketKontrolVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            StockMotionCheckParam tmpParam = new StockMotionCheckParam();
            tmpParam.BaslangicStokKodu = "WMS2";
            tmpParam.BitisStokKodu = "WMS2";
            var tmpResult = _manager.StockMotionCheck(tmpParam);

            if (tmpResult.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + tmpResult.Data);
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void stokKoduDeğiştirVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            StockCodeChangeParam tmpParam = new StockCodeChangeParam();
            tmpParam.EskiKod = "DEGISIM1";
            tmpParam.YeniKod = "DEGISIM2";
            tmpParam.VirmanYapilsin = true;
            tmpParam.YapKodGuncelle = false;
            tmpParam.VirmanSonrasiEskiKodSilinsin = false;
            var Result = _manager.StockCodeChange(tmpParam);

            if (Result.IsSuccessful)
            {
                MessageBox.Show("Tamamlandı");
            }
            else
                MessageBox.Show(Result.ErrorDesc + " " + Result.ErrorCode);
        }

        private void yevmiyeKontrolVers9037VeSonrasıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            JournalCheckParam tmpParam = new JournalCheckParam();
            tmpParam.YevSubeDahil = true;

            var Result = _manager.JournalCheck(tmpParam);

            if (Result.IsSuccessful)
            {
                MessageBox.Show("Tamamlandı");
            }
            else
                MessageBox.Show(Result.ErrorDesc + " " + Result.ErrorCode);
        }

        private void hataKoduYorumlamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ItemSlipsManager _manager = new ItemSlipsManager(Global._oAuth2);
            JKernel kernel = new JKernel();
            ItemSlips fatura = new ItemSlips();

            fatura.FaturaTip = JTFaturaTip.ftSFat;
            var fatResult = _manager.GetInternal(JTFaturaTip.ftSFat);

            if (kernel.SonNetsisHata != null)
            {
                if (kernel.SonNetsisHata.Kod == 401)
                {
                    Console.WriteLine("Fatura bilgileri bulunamadı");
                }
            }
        }

        private void tokenAlmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            string token = Global._oAuth2.AccessToken;
        }

        private void işEmriKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            ProductionOrderManager POM = new ProductionOrderManager(Global._oAuth2);

            JIsEmri jemir = new JIsEmri();

            jemir.IsEmriNo = "X00000000000018";
            jemir.Tarih = Convert.ToDateTime("2015-01-01");
            jemir.StokKodu = "M1";
            jemir.Miktar = 100;
            jemir.SipKont = 0;
            jemir.DepoKodu = 2;
            jemir.CikisDepoKodu = 1;
            jemir.TeslimTarihi = Convert.ToDateTime("2015-01-02");
            jemir.Kapali = false;

            var result = POM.PostInternal(jemir);
        }

        private void malzemeGereksinimPlanlamaOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            MrpManager _manager = new MrpManager(Global._oAuth2);

            JMrpGereksinimPlanOlusturPrm MrpParam = new JMrpGereksinimPlanOlusturPrm();

            MrpParam.BaslangicTarihi = Convert.ToDateTime(DateTime.Now.AddYears(-10).ToString("dd/MM/yyyy"));
            MrpParam.BitisTarihi = Convert.ToDateTime(DateTime.Now.AddYears(1).ToString("dd/MM/yyyy"));
            MrpParam.BazTarihi = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
            MrpParam.BaslangicOncesiSipTarih = Convert.ToDateTime(DateTime.Now.AddYears(-10).ToString("dd/MM/yyyy"));
            MrpParam.PlanlamaTipi = 0;
            MrpParam.UrunTipi = JTMrpUrunTipi.mutSiparisBakiye;
            MrpParam.Aciklama = "Test";
            MrpParam.BaslangicSiparisNo = "";
            MrpParam.SadeceOnayliSiparisler = false;
            MrpParam.SiparisBazindaAyrim = true;
            MrpParam.BaslangicSiparisNo = String.Empty;
            MrpParam.BitisSiparisNo = String.Empty;
            //MrpParam.FabrikaKodu = "ISTANBUL";
            MrpParam.Siparis = JTMrpSiparis.msHepsi;

            _manager.GenerateRequirementPlan(MrpParam);
        }

        private void malzemeGereksinimPlanlamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            MrpManager _manager = new MrpManager(Global._oAuth2);

            JMrp tmpMrp = new JMrp();

            tmpMrp.BASTAR = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
            tmpMrp.BITTAR = Convert.ToDateTime(DateTime.Now.AddDays(2).ToString("dd/MM/yyyy"));
            tmpMrp.Detayli = true;
            tmpMrp.BakKont = true;
            tmpMrp.GnlYapKodDestek = false;
            tmpMrp.YapKodKontrol = false;
            tmpMrp.IsEmrHaricNoBas = string.Empty;
            tmpMrp.IsEmrHaricNoBit = string.Empty;
            tmpMrp.IsEmriKont = true;
            tmpMrp.MamKont = true;
            tmpMrp.MinStokBak = true;
            tmpMrp.SipKont = true;
            //netStrList.Add("MRP");
            //tmpMrp.SirketListesi = netStrList;

            _manager.MaterialRequirementsPlanning(tmpMrp);
        }

        private void malzemeGereksinimindenTalepListeHazırlamakToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _MrpManager = new MrpManager(Global._oAuth2);

            RequisitionBalancingPrm TalepDenPrm = new RequisitionBalancingPrm();
            TalepDenPrm.FabrikaKodu = "00000";
            TalepDenPrm.Oturum = "1";
            TalepDenPrm.SaticiKoduBosIhtiyaclar = JTSaticiKoduBosIhtiyaclar.biGetirilsin;
            TalepDenPrm.TalepBaslangicNo = "T00000000000041";
            TalepDenPrm.TalepKayitTarihi = DateTime.ParseExact("2021-03-10 00:00:00", "yyyy-MM-dd hh:mm:ss", null);
            TalepDenPrm.SaticiKodu = "320-01-049";
            TalepDenPrm.MalKabulDepoKodu = 1;
            TalepDenPrm.MevcutMrpYedeklensin = false;
            TalepDenPrm.MrpIleriKisit = "";
            TalepDenPrm.StokIleriKisit = "";
            //TalepDenPrm.StokKodu = "EB_HM1";
            TalepDenPrm.YapKod = "";
            TalepDenPrm.GruplamaSecenegi = JTGruplamaSecenekTipi.gsHicbiri;

            var tmpResult = _MrpManager.PrepareRequisitionBalancing(TalepDenPrm);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("ok");
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
            List<RequisitionBalancingResult> tmpRequisitionBalancingResultList = tmpResult.Data;
            foreach (var item in tmpRequisitionBalancingResultList)

            { MessageBox.Show(item.StokKodu); }
        }

        private void malzemeGereksinimindenTalepOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _MrpManager = new MrpManager(Global._oAuth2);

            RequisitionBalancingPrm TalepDenPrm = new RequisitionBalancingPrm();
            //TalepDenPrm.FabrikaKodu = "00000";
            TalepDenPrm.Oturum = "1";
            TalepDenPrm.SaticiKoduBosIhtiyaclar = JTSaticiKoduBosIhtiyaclar.biGetirilsin;
            TalepDenPrm.TalepBaslangicNo = "T00000000000041";
            TalepDenPrm.TalepKayitTarihi = DateTime.ParseExact("2021-03-10 00:00:00", "yyyy-MM-dd hh:mm:ss", null);
            TalepDenPrm.SaticiKodu = "320-01-049";
            TalepDenPrm.MalKabulDepoKodu = 1;
            TalepDenPrm.MevcutMrpYedeklensin = false;
            TalepDenPrm.MrpIleriKisit = "";
            TalepDenPrm.StokIleriKisit = "";
            //TalepDenPrm.StokKodu = "EB_HM1";
            TalepDenPrm.YapKod = "";
            TalepDenPrm.GruplamaSecenegi = JTGruplamaSecenekTipi.gsHicbiri;

            var tmpResult = _MrpManager.PrepareRequisitionBalancing(TalepDenPrm);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("ok");
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);

            List<RequisitionBalancingResult> tmpRequisitionBalancingResultList = tmpResult.Data;
            foreach (var item in tmpRequisitionBalancingResultList)

            { item.Secim = true; }
            tmpResult = _MrpManager.SaveRequisitionBalancing(new SaveRequisitionBalancingParam() { RequisitionBalancingParam = TalepDenPrm, RequisitionBalancingResultList = tmpRequisitionBalancingResultList });
            tmpRequisitionBalancingResultList = tmpResult.Data;
            foreach (var item in tmpRequisitionBalancingResultList)

            { MessageBox.Show(item.SiparisNo); }
        }

        private void reçeteKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            BOMManager BM = new BOMManager(Global._oAuth2);

            BOM newBOM = new BOM();
            newBOM.PrmMamulKodu = "MMLX3";
            newBOM.ReceteToplami = 1;
            newBOM.BOMItemList = new List<BOMItem>();
            newBOM.BOMItemList.Add(new BOMItem
            {
                OpNo = "0001",
                Opr_Bil = "B",
                Ham_Kodu = "HM1",
                Miktar = 1
            });
            newBOM.BOMItemList.Add(new BOMItem
            {
                OpNo = "0002",
                Opr_Bil = "O",
                Ham_Kodu = "OP1",
                Miktar = 1
            });
            newBOM.BOMItemList.Add(new BOMItem
            {
                OpNo = "0003",
                Opr_Bil = "O",
                Ham_Kodu = "OP2",
                Miktar = 1,
                SonOperasyon = true
            });

            var result = BM.PostInternal(newBOM);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı");
            }
            else
                MessageBox.Show(result.ErrorCode + " " + result.ErrorDesc);
        }

        private void reçetedenİşEmriOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ProductionOrderFromBOMManager POFBManager = new ProductionOrderFromBOMManager(Global._oAuth2);
            ProductionOrderFromBOMParam tmpPOFBParam = new ProductionOrderFromBOMParam();
            tmpPOFBParam.ProductionOrderNumber = "000000000000041";
            var tmpResult = POFBManager.PrepareProductionOrderItemList(tmpPOFBParam);
            if (tmpResult.IsSuccessful)
            {
                List<ProductionOrderItemFromBOM> tmpPOIList = tmpResult.Data;
                foreach (var item in tmpPOIList)
                {
                    if (item.StokKodu == "YARIMAMUL")
                        item.Secim = true;
                    else
                        item.Secim = false;
                }
                tmpPOFBParam.ProductionOrderItemList = tmpPOIList;
                tmpResult = POFBManager.GenerateProductionOrderItems(tmpPOFBParam);
                if (tmpResult.IsSuccessful)
                    MessageBox.Show("Başarılı");
            }
        }

        private void raporÇalıştırVeKaydetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            CompanyManager cm = new CompanyManager(Global._oAuth2);
            var result = cm.ExecuteReport(new ExecuteReportParam
            {
                ModuleNo = 4,
                ProgramNo = 268,
                DesignNo = 13,
                ReportResultFileType = NetOpenX.Rest.Client.Model.Enums.JTRaporSonucuCiktiTipi.rsctExcel

            });
        }

        private void prosesKontrolGirişiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ProcessControlManager PCM = new ProcessControlManager(Global._oAuth2);
            ProcessControl tmpProcessControl = new ProcessControl();
            tmpProcessControl.TanimTipi = JTProsesKontrolTanimTipi.pkIstasyon;
            tmpProcessControl.TanimKodu = "IST2";
            tmpProcessControl.GrupKodu = "2";
            tmpProcessControl.RevizyonNo = 1;
            tmpProcessControl.Tarih = DateTime.Now;
            tmpProcessControl.PersonelId = 1003;
            tmpProcessControl.Aciklama = "KONTROL AÇIKLAMASI";

            tmpProcessControl.ProcessControlMeasurementList = new List<ProcessControlMeasurement>();
            ProcessControlMeasurement tmpProcessControlMeasurement = new ProcessControlMeasurement();
            tmpProcessControlMeasurement.OlcumKodu = "1";
            tmpProcessControlMeasurement.OlcumDegeri = "12";
            tmpProcessControlMeasurement.OlcumSiraNo = 1;
            tmpProcessControl.ProcessControlMeasurementList.Add(tmpProcessControlMeasurement);
            var tmpResult = PCM.PostInternal(tmpProcessControl);

            string ResultStr = tmpResult.IsSuccessful == true ? "Kayıt Başarılı:" + tmpResult.Data.ProsesKontrolNo : tmpResult.ErrorDesc;
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + tmpResult.Data.ProsesKontrolNo);
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void prosesKontrolGirişiOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            ProcessControlManager PCM = new ProcessControlManager(Global._oAuth2);
            ProcessControl _tmpProcessControl = new ProcessControl();

            var tmpResult = PCM.GetInternal(new SelectFilter() { Filter = "BELGENO ='000000000000001'", ExpandLevel = "Full" });
            foreach (ProcessControl tmpProcessControl in tmpResult.Data)
            {
                foreach (ProcessControlMeasurement processControlMeasurement in tmpProcessControl.ProcessControlMeasurementList)
                {
                    string ResultStr = processControlMeasurement.OlcumSiraNo + "- " + processControlMeasurement.OlcumKodu + ": " + processControlMeasurement.OlcumDegeri;
                    MessageBox.Show(ResultStr.ToString());
                }
            }

            //Bir id ile okumak için aşağıdaki kısım kullanılmalıdır.

           // var tmpResult = PCM.GetInternalById("000000000000001");
            //ProcessControl tmpProcessControl = tmpResult.Data;
            //foreach (ProcessControlMeasurement processControlMeasurement in tmpProcessControl.ProcessControlMeasurementList)
            //{
              //  string ResultStr = processControlMeasurement.OlcumSiraNo + "- " + processControlMeasurement.OlcumKodu + ": " + processControlMeasurement.OlcumDegeri;
               // MessageBox.Show(ResultStr.ToString());
            //} 
        }

        private void prosesKontrolGirişiGüncellemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ProcessControlManager PCM = new ProcessControlManager(Global._oAuth2);
            var tmpResult1 = PCM.GetInternalById("000000000000001");
            ProcessControl tmpProcessControl = tmpResult1.Data;
            tmpProcessControl.Aciklama = "KONTROL AÇIKLAMASI 2";
            ProcessControlMeasurement tmpProcessControlMeasurement = tmpProcessControl.ProcessControlMeasurementList[1];
            tmpProcessControlMeasurement.OlcumDegeri = "33";
            tmpProcessControlMeasurement.Aciklama = "ölçüm güncellendi: 12->15";
            var tmpResult = PCM.PutInternal(tmpProcessControl.ProsesKontrolNo, tmpProcessControl);

            string ResultStr = tmpResult.IsSuccessful == true ? "Kayıt Başarılı:" + tmpResult.Data.ProsesKontrolNo : tmpResult.ErrorDesc;
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + tmpResult.Data.ProsesKontrolNo);
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void stokPlanlamaKayıtlarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = new PlanningRecord();
            tmpPlanningRecord.Stok_Kodu = "SER1X";
            tmpPlanningRecord.SIPARISKARSILAMA = "M";
            tmpPlanningRecord.SIPARISTAKIP = "H";
            tmpPlanningRecord.PlanlamaTipi = "P";
            tmpPlanningRecord.TEDARIKCITERCIH = "K";
            tmpPlanningRecord.REZERV_BAK_TAKIP = "E";
            tmpPlanningRecord.ONEMSIZ_STOK = "H";
            tmpPlanningRecord.KESINLESEN_GUNCELLENMESIN = "H";
            tmpPlanningRecord.SIPARIS_ONAYLI = "V";
            tmpPlanningRecord.REC_ISEM_OLUS = "E";

            var result = _manager.PostInternal(tmpPlanningRecord);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı");
            }
            else
                MessageBox.Show(result.ErrorDesc);
        }

        private void stokPlanlamaKayıtOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            var result = _manager.GetItemPlanningRecord("SER1X");

            MessageBox.Show(result.Data.Stok_Kodu);
        }

        private void stokPlanlamaKayıtlarıGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetItemPlanningRecord("SER1X");

            if (result.IsSuccessful)
            {
                tmpPlanningRecord = result.Data;
                tmpPlanningRecord.NAKLIYE_SURESI = 4;

                result = _manager.PutInternal(";SER1X", tmpPlanningRecord);
            }
        }

        private void stokPlanlamaKayıtlarıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            var result = _manager.GetItemPlanningRecord("SER1X");

            if (result.IsSuccessful)
            {
                ItemPlanningRecordParam tmpItemPlanningRecordParam = new ItemPlanningRecordParam { STOK_KODU = "SER1X" };
                var result2 = _manager.DeleteItemPlanningRecord(tmpItemPlanningRecordParam);
                MessageBox.Show("Kayıt Silindi");
            }
            else
                MessageBox.Show(result.ErrorDesc);
        }

        private void cariPlanlamaKayıtlarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = new PlanningRecord();
            tmpPlanningRecord.CARI_KOD = "320-01-046";
            tmpPlanningRecord.NAKLIYE_SURESI = 2;
            tmpPlanningRecord.SIPARISKARSILAMA = "M";
            tmpPlanningRecord.SIPARISTAKIP = "H";
            tmpPlanningRecord.PlanlamaTipi = "P";
            tmpPlanningRecord.TEDARIKCITERCIH = "K";
            tmpPlanningRecord.REZERV_BAK_TAKIP = "E";
            tmpPlanningRecord.ONEMSIZ_STOK = "H";
            tmpPlanningRecord.KESINLESEN_GUNCELLENMESIN = "H";
            tmpPlanningRecord.SIPARIS_ONAYLI = "V";
            tmpPlanningRecord.REC_ISEM_OLUS = "E";

            var result = _manager.PostInternal(tmpPlanningRecord);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı");
            }
            else
                MessageBox.Show(result.ErrorDesc);
        }

        private void cariPlanlamaKayıtlarıOkuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCurAccPlanningRecord("320-01-046");
            if (result.IsSuccessful)
            {
                MessageBox.Show("OK");
                MessageBox.Show(result.Data.CARI_KOD);
            }
            else
                MessageBox.Show("no");
        }

        private void cariPlanlamaKayıtlarıGüncellemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCurAccPlanningRecord("320-01-046");

            if (result.IsSuccessful)
            {
                tmpPlanningRecord = result.Data;
                tmpPlanningRecord.NAKLIYE_SURESI = 1;
                tmpPlanningRecord.YUKLEME_GUNU = 2;

                result = _manager.PutInternal("320-01-046", tmpPlanningRecord);
            } 
        }

        private void cariPlanlamaKayıtlarıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCurAccPlanningRecord("320-01-046");

            if (result.IsSuccessful)
            {
                tmpPlanningRecord = result.Data;
                tmpPlanningRecord.YUKLEME_GUNU = 3;
                CurAccPlanningRecordParam tmpCurAccPlanningRecordParam =
                    new CurAccPlanningRecordParam { CARI_KOD = "320-01-046" };
                var result2 = _manager.DeleteCurAccPlanningRecord(tmpCurAccPlanningRecordParam);
                if (result2.IsSuccessful)
                {
                    MessageBox.Show("kayıt silindi");
                }
            }
        }

        private void müşteriSatıcıStokKayıtlarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = new PlanningRecord();
            tmpPlanningRecord.CARI_KOD = "320-01-046";
            tmpPlanningRecord.Stok_Kodu = "SER1X";
            tmpPlanningRecord.CARISTOK_KODU = "SER1X";
            tmpPlanningRecord.NAKLIYE_SURESI = 2;
            tmpPlanningRecord.SIPARISKARSILAMA = "M";
            tmpPlanningRecord.SIPARISTAKIP = "H";
            tmpPlanningRecord.PlanlamaTipi = "P";
            tmpPlanningRecord.TEDARIKCITERCIH = "K";
            tmpPlanningRecord.REZERV_BAK_TAKIP = "E";
            tmpPlanningRecord.ONEMSIZ_STOK = "H";
            tmpPlanningRecord.KESINLESEN_GUNCELLENMESIN = "H";
            tmpPlanningRecord.SIPARIS_ONAYLI = "V";
            tmpPlanningRecord.REC_ISEM_OLUS = "E";

            var result = _manager.PostInternal(tmpPlanningRecord);
            if (result.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı");
            }
            else
                MessageBox.Show(result.ErrorDesc);
        }

        private void müşteriSatıcıStokKayıtlarıOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCustomerSupplierItemPlanningRecord("320-01-046;SER1X");
            if (result.IsSuccessful)
            {
                MessageBox.Show("OK");
                MessageBox.Show(result.Data.CARI_KOD);
            }
            else
                MessageBox.Show("no");
        }

        private void müşteriSatıcıStokKayıtlarıGüncellemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCustomerSupplierItemPlanningRecord("320-01-046;SER1X");

            if (result.IsSuccessful)
            {
                tmpPlanningRecord = result.Data;
                tmpPlanningRecord.NAKLIYE_SURESI = 1;

                result = _manager.PutInternal("320-01-046;SER1X", tmpPlanningRecord);
            }
        }

        private void müşteriSatıcıStokKayıtlarıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            PlanningRecordManager _manager = new PlanningRecordManager(Global._oAuth2);
            PlanningRecord tmpPlanningRecord = null;
            var result = _manager.GetCustomerSupplierItemPlanningRecord("320-01-046;SER1X");

            if (result.IsSuccessful)
            {
                tmpPlanningRecord = result.Data;
                tmpPlanningRecord.YUKLEME_GUNU = 3;
                CustomerSupplierItemPlanningRecordParam tmpCustomerSupplierItemPlanningRecordParam =
                   new CustomerSupplierItemPlanningRecordParam { CARI_KOD = "320-01-046", STOK_KODU = "SER1X" };
                var result2 = _manager.DeleteCustomerSupplierItemPlanningRecord(tmpCustomerSupplierItemPlanningRecordParam);
                if (result2.IsSuccessful)
                {
                    MessageBox.Show("kayıt silindi");
                }
            }
        }

        private void suskKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            FinishedGoodsReceiptWChangesManager _manager = new FinishedGoodsReceiptWChangesManager(Global._oAuth2);
            FinishedGoodsReceiptWChanges susk = new FinishedGoodsReceiptWChanges();

            //susk.FisSeri ="A";
            susk.UretSon_Mamul = "SERI_MAMUL1";
            susk.UretSon_Depo = 2; //giriş depo
            susk.I_Yedek1 = 1;   //çıkış depo
            susk.UretSon_Miktar = 10;
            susk.F_Yedek1 = 1;
            susk.UretSon_Tarih = DateTime.Now;
            susk.Aciklama = "mamul açıklama";
            susk.Proje_Kodu = "b";
            susk.BAKIYE_DEPO = 0;

            //FİRE DETAY GİRİŞİ (NetOpenX FireDetayEkle)
            susk.ShrinkageDetailList = new List<ShrinkageDetail>();
            ShrinkageDetail shrinkageDetail = new ShrinkageDetail
            { FireKodu = "FIRE_004", Miktar = 1 };
            susk.ShrinkageDetailList.Add(shrinkageDetail);

            susk.Seri = new List<ItemSlipLineSeries>();
            ItemSlipLineSeries tmpMamulSeri = new ItemSlipLineSeries()

            {
                Seri1 = "s8",
                Seri2 = "s2",
                Seri3 = "s3",
                Seri4 = "s4",
                Aciklama1 = "a1",
                Aciklama2 = "a2",
                ACIKLAMA3 = "a3",
                Aciklama4 = "a4",
                Miktar = 9,
                Miktar2 = 0,
                SonKulTar = Convert.ToDateTime("01.01.2022")

            }
            ;
            susk.Seri.Add(tmpMamulSeri);

            var Result = _manager.ReceiptProduce(susk);

            for (int i = 0; i < Result.Data.Kalem.Count; i++)
            {
                FinishedGoodsReceiptWChangesLines kalem = Result.Data.Kalem[i];
                if (kalem.GC == JTGirisCikis.gcCikis)
                {
                    MessageBox.Show(kalem.StokKodu);
                    kalem.Miktar2 = 1;
                    kalem.ShrinkageDetailList = new List<ShrinkageDetail>();
                    ShrinkageDetail shrinkageDetail1 = new ShrinkageDetail
                    { FireKodu = "FIRE_003", Miktar = 1 };
                    kalem.ShrinkageDetailList.Add(shrinkageDetail1);

                    kalem.KalemSeri = new List<ItemSlipLineSeries>();
                    ItemSlipLineSeries tmpSeri = new ItemSlipLineSeries();
                    tmpSeri.Seri1 = "SS";
                    tmpSeri.Miktar = 11;
                    kalem.KalemSeri.Add(tmpSeri);
                }
            }

            var yeniREsult = _manager.Save(Result.Data);
            if (yeniREsult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + yeniREsult.Data.UretSon_FisNo);
            }
            else
                MessageBox.Show(yeniREsult.ErrorCode + " " + yeniREsult.ErrorDesc);
        }

        private void suskKayıtOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            FinishedGoodsReceiptWChangesManager _manager = new FinishedGoodsReceiptWChangesManager(Global._oAuth2);
            FinishedGoodsReceiptWChanges susk = new FinishedGoodsReceiptWChanges();


            var fat = _manager.GetInternalById("A00000000000003");
            susk = fat.Data;
            susk.Kalem = new List<FinishedGoodsReceiptWChangesLines>();

            susk.UretSon_Miktar = susk.UretSon_Miktar + 1;
            susk.Aciklama = "Miktar Güncellendi";
            susk.FisSeri = "A";
            var result = _manager.ReceiptProduce(susk);
        }

        private void suskKayıtSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            FinishedGoodsReceiptWChangesManager _manager = new FinishedGoodsReceiptWChangesManager(Global._oAuth2);
            FinishedGoodsReceiptWChanges susk = new FinishedGoodsReceiptWChanges();

            _manager.GetInternalById("000000000000001");
            var result = _manager.DeleteInternalById("000000000000001");
        }

        private void suskKalemSilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            FinishedGoodsReceiptWChangesManager _manager = new FinishedGoodsReceiptWChangesManager(Global._oAuth2);
            FinishedGoodsReceiptWChanges susk = new FinishedGoodsReceiptWChanges();

            var fat = _manager.GetInternalById("Uretim fiş numarası");
            susk = fat.Data;
            var tmpKalem = susk.Kalem.Where(x => x.StokKodu == "Silinmek istenen stok kodu").FirstOrDefault();
            if (tmpKalem != null)
            {
                susk.Kalem.Remove(tmpKalem);
            }
            var result = _manager.Save(susk);
        }

        private void ürünMaliyetOluşturmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ProductMaterialCostManager pmcm = new ProductMaterialCostManager(Global._oAuth2);
            var result = pmcm.GenerateProductMaterialCosts(new GenerateProductMaterialCostsParam
            {
                StartDate = DateTime.ParseExact("2020-01-01 00:00:00", "yyyy-MM-dd hh:mm:ss", null),
                EndDate = DateTime.ParseExact("2022-01-01 00:00:00", "yyyy-MM-dd hh:mm:ss", null),
                PhaseCount = 1,
                ItemCode = "URUNM2"
                //EvaluateSalesReturnsUsingThisPeriodAveragePrice = true,
                //Code1 = "K1",
                //Code2 = "K2",
                //Code3 = "K3",
                //Code4 = "K4",
                //Code5 = "K5",
                //GroupCode = "GRP1",
                //IncludingBranches = true,
                //SQLWhereClause = " STOK_ADI LIKE '%ABC%'"
            });
            if (result.IsSuccessful)
            {
                MessageBox.Show(result.Data.ToString());
            }
            else
                MessageBox.Show(result.ErrorDesc);
        }

        private void yaşlandırmalıÖzelHesapKapatmaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Global.SirketTanımRest();

            ARPsAgingManager _manager = new ARPsAgingManager(Global._oAuth2);

            ARPsAging TmpARPsAging = new ARPsAging();

            TmpARPsAging.CariKod = "120-01-011";

            var tmpResult = _manager.SettlementByAging(TmpARPsAging);
            if (tmpResult.IsSuccessful)

            { MessageBox.Show("İşlem Tamamlandı:" + tmpResult.Data); }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void aydanAyaFişAktarımı9037ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            MontlyVoucherTransferParam tmpParam = new MontlyVoucherTransferParam();
            tmpParam.AktEskiFisSilinsin = false;
            tmpParam.AktYeniAcik = "rest aciklama";
            tmpParam.KaynakFisNo = "000000000000056";
            tmpParam.KaynakAy = 9;
            tmpParam.HedefAy = 9;
            tmpParam.HedefFisNo = "000000000000057";
            tmpParam.AktEskiFisSilinsin = true;
            tmpParam.DegisecekAcik = "xxxx";
            tmpParam.EvrakTarHedefTarOlsun = true;
            var Result = _manager.MontlyVoucherTransfer(tmpParam);
            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void muhasebeHesapKoduAktarımı9037ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CompanyManager _manager = new CompanyManager(Global._oAuth2);
            AccountTransferParam tmpParam = new AccountTransferParam();
            tmpParam.AktarimTuru = JTMuhAktTuru.atAlacak;
            tmpParam.AktBasTarih = Convert.ToDateTime(DateTime.Now.AddDays(-100).ToString("dd/MM/yyyy"));
            tmpParam.AktBitTarih = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
            tmpParam.AktIlkFisNo = "000000000000052";
            tmpParam.AktSonFisNo = "000000000000055";
            tmpParam.AktSubeDahil = true;
            tmpParam.EskiMuavin = "600-01-001";
            tmpParam.YeniMuavin = "320-01-041";
            var Result = _manager.AccountTransfer(tmpParam);
            if (Result.IsSuccessful)

            {
                MessageBox.Show("İşlem Tamamlandı:" + Result.Data);
            }
            else
                MessageBox.Show(Result.ErrorDesc);
        }

        private void dövizKaydıOkuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            var _manager = new ForExsManager(Global._oAuth2);

            #region WithoutAnyFilter
            var resultWithoutFilter = _manager.GetInternal();
            var data = resultWithoutFilter.Data;

            #endregion
            #region FilterTest
            var resultFilter = _manager.GetInternal(new SelectFilter
            {
                Filter = @"NETSISSIRA >= 9"
            });

            var resultFilter2 = _manager.GetInternal(new SelectFilter
            {
                Filter = @"ISIM LIKE '%e%'"
            });
            #endregion


            #region Sort
            var resultSortAsc = _manager.GetInternal(new SelectFilter()
            {
                Sort = new List<SortParam>()
                {
                    new SortParam() { Column = "NETSISSIRA", SortType = SortParamType.ASC }
                }
            });
           // var sortedAscList = resultSortAsc.Data.OrderBy(e => e.NETSISSIRA);
            var resultSortDesc = _manager.GetInternal(new SelectFilter()
            {
                Sort = new List<SortParam>()
                {
                    new SortParam() { Column = "Sira", SortType = SortParamType.DESC }
                }
            });
           // var sortedDescList = resultSortDesc.Data.OrderByDescending(e => e.Sira);
            #endregion

            #region OffsetTest
            var resultOffset = _manager.GetInternal(new SelectFilter()
            {
                Offset = 3,
                Limit = 7
            });
            #endregion

            #region LimitTest
            var resultLimit = _manager.GetInternal(new SelectFilter()
            {
                Limit = 5
            });
            #endregion

            #region Id'ye göre döviz kaydı
            var result = _manager.GetInternalById(1); //1 = Id
            var isim = result.Data.ISIM.Contains("USD");
            #endregion */
        }

        private void dövizKaydıOluşturToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Global.SirketTanımRest();

            var _dummyForExs = new ForExs()
            {
                BIRIM = 8,
                ISIM = "Kron",
                NETSISSIRA = 15
            };

            var _manager = new ForExsManager(Global._oAuth2);

            var result = _manager.PostInternal(_dummyForExs);
        }

        private void dövizKaydıGüncellemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            ForExsManager _manager = new ForExsManager(Global._oAuth2);
            ForExs döviz = new ForExs();

            var id = 1;
            var result = _manager.PutInternal(id, new ForExs
            {

                BIRIM = 2,
                ISIM = "Ali",


            });
        }

        private void dövizKaydıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();
            ForExs _dummyForExs = new ForExs();

            var _manager = new ForExsManager(Global._oAuth2);
            int sira =5;
            var result = _manager.DeleteInternalById(sira);
            
        }

        private void bankaHavaleEftKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            string token = Global._oAuth2.AccessToken;

            BankRemittanceTransferManager BRTManager = new BankRemittanceTransferManager(Global._oAuth2);

            BankRemittanceTransfer tmpBRT = new BankRemittanceTransfer();
            tmpBRT.IslemTipi = (int)JTBankaHavaleEftTip.tbBankaHvl;
            tmpBRT.GelGidBA = "A"; //Gönderilen
            tmpBRT.NetHesKodu = "001015";
            tmpBRT.KarsiHesKod = "AKB-01-VDSZ-1";
            tmpBRT.Tutar = 1;
            tmpBRT.Sube_Kodu = 0;
            tmpBRT.PlasiyerKodu = "1";

            var tmpResult = BRTManager.PostInternal(tmpBRT);
        }

        private void bankaHavaleEftGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            BankRemittanceTransferManager BRTManager = new BankRemittanceTransferManager(Global._oAuth2);

            BankRemittanceTransfer tmpBRT = new BankRemittanceTransfer();

            tmpBRT.Aciklama = "zzz";

            var tmpResult = BRTManager.PutInternal(JTBankaHavaleEftTip.tbVirman.ToString() + ";1;;000000000000032", tmpBRT);
        }

        private void bankaHavaleEftSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            BankRemittanceTransferManager BRTManager = new BankRemittanceTransferManager(Global._oAuth2);

            var tmpResult = BRTManager.DeleteInternalById(JTBankaHavaleEftTip.tbBankaHvl.ToString() + ";1;;000000000000032");

        }

        private void kasaCariÖdemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            string token = Global._oAuth2.AccessToken;

            SafeDepositsManager _maneger2 = new SafeDepositsManager(Global._oAuth2);

            SafeDeposits kasa = new SafeDeposits();

            kasa.KsMas_Kod = "01";  //Kasa Kodu
            kasa.IO = "G";
            kasa.Tip = "C";
            kasa.Kod = "00001";     //Cari Kodu
            kasa.Fisno = "3";
            kasa.Tutar = 50;
            kasa.ReferansKodu = "01";
            kasa.Tarih = DateTime.Today;


            var result = _maneger2.PostInternal(kasa); 
        }

        private void kasaÇekÖdemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            string token = Global._oAuth2.AccessToken;

            SafeDepositsManager _manager2 = new SafeDepositsManager(Global._oAuth2);

            SafeDeposits kasa = new SafeDeposits();

            kasa.KsMas_Kod = "01";              //Kasa Kodu
            kasa.IO = "G";
            kasa.Tip = "C";
            kasa.Tutar = 700;
            kasa.Fisno = "H00000000000390";     //Çek numarasi
            kasa.Cari_Muh = "C";
            kasa.Kod = "1";                 //Veren Cari Kodu
            //.Proje_Kodu = "1";
            kasa.Tarih = DateTime.Today;


            var result = _manager2.PostInternal(kasa);
        }

        private void kasaÇokluKalemGirişiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            string token = Global._oAuth2.AccessToken;

            SafeDepositsManager _manager2 = new SafeDepositsManager(Global._oAuth2);

            SafeDeposits kasa = new SafeDeposits();
            JKasaKdv kasaKdv = new JKasaKdv();

            kasa.KsMas_Kod = "00"; //Kasa Kodu
            kasa.DovizTipi = 1;
            kasa.IO = "G";
            kasa.Tip = "F";
            kasa.ReferansKodu = "01";
            kasa.Kod = "600-01-001"; //Muhasebe Karsilik Kodu
            kasa.Fisno = "x10";
            kasa.Tarih = DateTime.Today;

            kasa.KdvKalems = new List<JKasaKdv>();

            kasa.KdvKalems.Add(new JKasaKdv
            {
                Kdv_Dahil = true,
                Kod = "600-01-001",
                Tutar = 200,
                KdvMuhKod = "600-01-001",
                Kdv_Oran = 8,
                Miktar = 1,

            });
            kasa.KdvKalems.Add(new JKasaKdv
            {
                Kdv_Dahil = true,
                Kod = "600-01-001",
                Tutar = 400,
                KdvMuhKod = "600-01-001",
                Kdv_Oran = 8,
                Miktar = 1,


            });

            var result = _manager2.PostInternal(kasa);
        }

        private void kasaMuhtelifİşlemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            SafeDepositsManager _manager = new SafeDepositsManager(Global._oAuth2);
            SafeDeposits kasa = new SafeDeposits()
            {
                KsMas_Kod = "01",    //Kasa Kodu
                IO = "G",
                Tip = "M",
                Kod = "100-02-001",   //Muhasebe Karsilik Kodu
                Fisno = "141",
                ReferansKodu = "01",
                Tutar = 500,
                Tarih = DateTime.Today


            };

            var result = _manager.PostInternal(kasa);
        }

        private void kasaTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            string token = Global._oAuth2.AccessToken;

            SafeDepositsManager _manager2 = new SafeDepositsManager(Global._oAuth2);

            SafeDeposits kasa = new SafeDeposits();

            kasa.KsMas_Kod = "01";         //Transfer Kasasi (kaynak kasa)
            kasa.Yedek1 = "00";            //Çalisilan Kasa  (hedef kasa) 
            kasa.IO = "C";
            kasa.Tip = "T";
            kasa.Fisno = "9";
            kasa.DovizTut = 300;           //Transfer Kasasi dovizli ise Doviz Tutar miktari girilir
            kasa.Tutar = 450;
            kasa.Plasiyer_Kodu = "1";
            kasa.Proje_Kodu = "1";
            kasa.Tarih = DateTime.Today;


            var result = _manager2.PostInternal(kasa);
        }

        private void kasaBankaHareketKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            SafeDepositsManager _manager = new SafeDepositsManager(Global._oAuth2);
            SafeDeposits banka_hareket = new SafeDeposits()
            {
                KsMas_Kod = "01",
                IO = "G",
                Tip = "B",
                Kod = "61",
                Fisno = "25",
                DovizTut = 300,
                Tutar = 450,
                Tarih = DateTime.Today
            };

            var result = _manager.PostInternal(banka_hareket);
        }

        private void çekSenetOluşturToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            var _manager = new CheckAndPNotesMainManager(Global._oAuth2);
            var _dummyCheckAndPNotesMain = new CheckAndPNotesMain()
            {
                Tip = JTCekSenType.csMCEK,
                CekSenEvrakKaydetmeTip = JTCekSenetEvrakKaydetmeTipi.ektCekSenAlma,
                OtoNumaraGetir = true,
                Evraklar = new List<CheckAndPNotes>()
                {
                    new CheckAndPNotes()
                    {
                        CEKSERI = "H",
                        SC_GIRTRH = DateTime.Now.Date,
                        SC_VERENK = "00002",
                        AS_C = "A",
                        SC_YERI = "P",
                        VADETRH = DateTime.Now.AddMonths(1),
                        SC_ODETRH = DateTime.Now.AddMonths(1),
                        Proje_Kodu = "1",
                        Plasiyer_Kodu = "02",
                        Tutar = 500
                    },

                    new CheckAndPNotes()
                    {
                        CEKSERI = "H",
                        SC_GIRTRH = DateTime.Now.Date,
                        SC_VERENK = "00002",
                        AS_C = "A",
                        SC_YERI = "P",
                        VADETRH = DateTime.Now.AddMonths(1),
                        SC_ODETRH = DateTime.Now.AddMonths(1),
                        Proje_Kodu = "1",
                        Plasiyer_Kodu = "02",
                        Tutar = 100
                    }
                }
            };
            var result = _manager.PostInternal(_dummyCheckAndPNotesMain);
            var data = result.Data;
            var bordroNo = data.BordroNo; 
        }

        private void çekSenetÇağırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();
            var _manager = new CheckAndPNotesMainManager(Global._oAuth2);

            //CekSenType enum degerlerinden biri ve TBLMCEK, TBLMSEN, TBLBCEK or TBLBSENtablolarindan gelecek SC_ALB_NOdegerini alir
            var result = _manager.GetInternalById("csMCEK;A00000000000001");
            var data = result.Data; 
        }

        private void çekSenetParametrelereGöreÇağırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();
            var _manager = new CheckAndPNotesMainManager(Global._oAuth2);


            var result = _manager.GetInternalByParam(new CheckAndPNotesMainParam()
            {
                Tip = JTCekSenType.csMCEK,
                BordroNo = "A00000000000001"
            });
            var data = result.Data; 

        }

        private void çekSenetParametrelereGöreSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();
            var _manager = new CheckAndPNotesMainManager(Global._oAuth2);

            var result = _manager.DeleteInternalByParam(new CheckAndPNotesMainParam()
            {
                BordroNo = "5",
                Tip = JTCekSenType.csMCEK
            }); 
        }

        private void çekSenetSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
             
            Global.SirketTanımRest();
            var _manager = new CheckAndPNotesMainManager(Global._oAuth2);
            var result = _manager.DeleteInternalById("csMCEK;B20000000000006");
            
        }

        private void borçÇekiÖdentisiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CheckAndPNoteStatementsManager CPSManager = new CheckAndPNoteStatementsManager(Global._oAuth2);
            DebitCheckPNotesStatementPaymentParam tmpDebitCheckPNotesStatementPaymentParam = new DebitCheckPNotesStatementPaymentParam();
            CheckAndPNoteStatements tmpCheckAndPNoteStatement = new CheckAndPNoteStatements();

            tmpCheckAndPNoteStatement.SC_NO = "X00000000000024";
            tmpCheckAndPNoteStatement.Seri = "CS";
            tmpCheckAndPNoteStatement.C_M = "B";
            tmpCheckAndPNoteStatement.Aciklama = "NetopenX-Rest";
            tmpCheckAndPNoteStatement.Banka_Kodu = "001015";
            tmpCheckAndPNoteStatement.Dekont_Tarihi = DateTime.Now;
            tmpCheckAndPNoteStatement.Islem_Tarihi = DateTime.Now;
            tmpCheckAndPNoteStatement.DovizTipi = 1;
            tmpDebitCheckPNotesStatementPaymentParam.CheckPNoteType = JTCekSenType.csBCEK;
            tmpDebitCheckPNotesStatementPaymentParam.CheckAndPNoteStatementData = tmpCheckAndPNoteStatement;

            var tmpResult = CPSManager.DebitCheckPNotesStatementPayment(tmpDebitCheckPNotesStatementPaymentParam);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + tmpResult.Data.ToString());
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void çekSenetTahsilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            CheckAndPNoteStatementsManager CPSManager = new CheckAndPNoteStatementsManager(Global._oAuth2);
            CheckPNotesStatementPaymentParam tmpCheckPNotesStatementPaymentParam = new CheckPNotesStatementPaymentParam();
            CheckAndPNoteStatements tmpCheckAndPNoteStatement = new CheckAndPNoteStatements();

            tmpCheckAndPNoteStatement.SC_NO = "V00000000000009";
            tmpCheckAndPNoteStatement.Seri = "CS";
            tmpCheckAndPNoteStatement.C_M = "B";
            tmpCheckAndPNoteStatement.Aciklama = "NetopenX-Rest";
            tmpCheckAndPNoteStatement.VirmanHesapKodu = "001015";
            tmpCheckAndPNoteStatement.Dekont_Tarihi = DateTime.Now;

            tmpCheckPNotesStatementPaymentParam.CheckAndPNoteStatementData = tmpCheckAndPNoteStatement;

            var tmpResult = CPSManager.CheckPNotesStatementPayment(tmpCheckPNotesStatementPaymentParam);
            if (tmpResult.IsSuccessful)
            {
                MessageBox.Show("Kayıt Tamamlandı" + tmpResult.Data.ToString());
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void kurKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();


            ExRatesManager _manager = new ExRatesManager(Global._oAuth2);
            ExRates kur = new ExRates();


            kur.DOV_ALIS = 15;
            kur.DOV_SATIS = 15;
            kur.EFF_ALIS = 30;
            kur.EFF_SATIS = 30;

            _manager.PostInternal(kur);
        }

        private void yeniNumaraAlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            StatementsHeaderManager _manager = new StatementsHeaderManager(Global._oAuth2);
            StatementsHeaderParam TmpstatementsHeader = new StatementsHeaderParam();
            TmpstatementsHeader.Seri_No = "A";

            var tmpResult = _manager.NewNumber(TmpstatementsHeader);
            if (tmpResult.IsSuccessful == true)
            {
                MessageBox.Show("İşlem Tamamlandı:" + tmpResult.Data);
            }
            else
                MessageBox.Show(tmpResult.ErrorDesc);
        }

        private void cariDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            StatementsHeaderManager _manager = new StatementsHeaderManager(Global._oAuth2);
            StatementsHeader Dekontbas = new StatementsHeader();
            Statements Dekont = new Statements();



            Dekontbas.Seri_No = "GD";

            //kasa.KdvKalems = new List<JKasaKdv>();
            Dekontbas.Kalemler = new List<Statements>();

            Dekontbas.Kalemler.Add(new Statements
            {
                Seri_No = "GD",
                Tutar = 500,
                B_A = "B",
                DovTL = "T",
                Kod = "1",
                C_M = "C",
                ValorTrh = DateTime.Now,
                Fisno = "5",
                Tarih = DateTime.Now,
                DEPO_KODU = 0,
                DekontTip = JTDekontTip.dekCari

            });


            var result = _manager.PostInternal(Dekontbas);
        }

        private void stokDekontKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            StatementsHeaderManager _manager = new StatementsHeaderManager(Global._oAuth2);
            StatementsHeader Dekontbas = new StatementsHeader();
            Statements Dekont = new Statements();



            Dekontbas.Seri_No = "GD";

            //kasa.KdvKalems = new List<JKasaKdv>();
            Dekontbas.Kalemler = new List<Statements>();

            Dekontbas.Kalemler.Add(new Statements
            {
                Seri_No = "GD",
                Tutar = 500,
                B_A = "B",
                DovTL = "T",
                Kod = "1",
                C_M = "C",
                ValorTrh = DateTime.Now,
                Fisno = "5",
                Tarih = DateTime.Now,
                DEPO_KODU = 0,
                DekontTip = JTDekontTip.dekStok  //Stok yada Cari gibi tip alanları bu nesneden belirlenir.

            });


            var result = _manager.PostInternal(Dekontbas);
        }

        private void cariBağlantıAnaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();
            var _manager = new PrintManager(Global._oAuth2);
            var result = _manager.SafeDepositsPrinting(new SafeDepositPrintParam()
            {
                DesignNumber = 1046,
                PrintingType = JTKasaBasimTipi.kbMSen,
                Sira = 9592
            });
            var data = result.Data; 
        }

        private void cariÇağırmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();
            var _ARPsManager = new ARPsManager(Global._oAuth2);
            var resultAllCM = _ARPsManager.GetInternal();

            /// C0001 carisi kodunun bilgilerini dondurmektedir.
            var resultCMById = _ARPsManager.GetInternalById("C0001");


            // kisit , kolon ismi ve siralama ile ilgili ornek. 
            var resultFilterCM = _ARPsManager.GetInternal(new SelectFilter()
            {
                Limit = 10,
                Offset = 0,
                Filter = "CARI_KOD like '%CARI%'",
                Fields = new List<string>() { "CARI_KOD", "CARI_ISIM", "Plasiyer_Kodu" }
                ,
                Sort = new List<SortParam>()
                 {
                      new SortParam(){ Column = "CARI_KOD",  SortType= SortParamType.ASC}
                 }
            });
        }

 
        private void cariGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _ARPsManager = new ARPsManager(Global._oAuth2);

            var result = _ARPsManager.PutInternal("J0001", new ARPs
            {
                CariTemelBilgi = new ARPsPrimInfo
                {
                    CARI_ILCE = "NARLIDERE",
                    CARI_KOD = "J0001"
                }
            });

            var cariIlce = result.Data.CariTemelBilgi.CARI_ILCE;
            if (result.IsSuccessful)
            {
                MessageBox.Show("Güncelleme Tamamlandı" + " / " + result.Data.CariTemelBilgi.CARI_ILCE);
            }
            else
            {
                MessageBox.Show(result.ErrorDesc);

            }
        }

        private void cariKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {


            Global.SirketTanımRest();
            

            var _ARPsManager = new ARPsManager(Global._oAuth2);
            
            var resultPostDataCM = _ARPsManager.PostInternal(new ARPs()
            {
                CariTemelBilgi = new ARPsPrimInfo()
                {
                    CARI_KOD = "J0005",
                    CARI_ISIM = "Rest Cari 1",
                    CARI_TIP = "S",
                    Sube_Kodu = 0,
                    ACIK1 = "acik1",
                    ACIK2 = "acik2",
                    ACIK3 = "acik3",
                    CARI_ADRES = "izmir",
                    CARI_IL = "izmir",
                    CARI_TEL = "2322225566",
                    CARI_ILCE = "ksk",
                    EMAIL = "oner.kaya@logo.com.tr",
                    WEB = "www.logo.com.tr",
                    CM_RAP_TARIH = DateTime.Now.AddMonths(1)
                },
                CariEkBilgi = new ARPsSuppInfo()
                {
                    CARI_KOD = "J0001",
                    TcKimlikNo = "12345678911",
                    Kull1N = 1,
                    Kull1S = "1",
                    S_Yedek1 = "syedek1"
                }
            });

            if (resultPostDataCM.IsSuccessful)
            {
                MessageBox.Show("KAYIT BAŞARILI" + " " + resultPostDataCM.Data.CariTemelBilgi.CARI_KOD);
            }
            else
            {
                MessageBox.Show(resultPostDataCM.ErrorDesc);

            }
        }
        
        private void cariSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _ARPsManager = new ARPsManager(Global._oAuth2);
            //Cari kodu C001 olan cariyi siler
            var result = _ARPsManager.DeleteInternalById("J0001");
            if (result.IsSuccessful)
            {
                MessageBox.Show("Silme İşlemi Tamamlandı");
            }
            else
            {
                MessageBox.Show(result.ErrorDesc);

            }
        }

        private void cariOkumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            //_oAuth2 sinifi ile geçerli token alinmasi gerekir.
            var _ARPsManager = new ARPsManager(Global._oAuth2);
            //Cari kodu J0001 olan cari bilgilerini getir
            var result = _ARPsManager.GetInternalById("J0001");
            if (result.IsSuccessful)
            {
                MessageBox.Show(result.Data.CariEkBilgi.TcKimlikNo + " / " + result.Data.CariTemelBilgi.CARI_ISIM);
            }
            else
            {
                MessageBox.Show(result.ErrorDesc);

            }
        }

        private void cariHareketOluşturToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Global.SirketTanımRest();

            var _manager = new ARPTransactionsManager(Global._oAuth2);
            var _dummyArpTransaction = new ARPTransactions()
            {
                CARI_KOD = "00123",
                Tarih = DateTime.Now.Date,
                Hka = "A",
                Aciklama = "rest post",
                SonKayitNoAl = true
            };
            var result = _manager.PostInternal(_dummyArpTransaction);
            var data = result.Data; 
        }

        private void cariHareketGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
             
            Global.SirketTanımRest();

            var _manager = new ARPTransactionsManager(Global._oAuth2);
            int inckey = 179;
            var result = _manager.PutInternal(inckey, new ARPTransactions()
            {
                Aciklama = "str"
            });
            var data = result.Data; 
        }

        private void belirliBirCariHareketiGetirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            var _manager = new ARPTransactionsManager(Global._oAuth2);
            //IncKeyNo 178 olani getir
            var result = _manager.GetInternalById(178);
            var data = result.Data; 
        }

        private void tümCariHareketleriGetirToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Global.SirketTanımRest();

            var _manager = new ARPTransactionsManager(Global._oAuth2);
            var result = _manager.GetInternal();
            var data = result.Data;
            foreach (var arpTransaction in data)
            {
                Console.WriteLine(arpTransaction.CARI_KOD);
                Console.WriteLine(arpTransaction.Inc_Key_Number);
                Console.WriteLine(arpTransaction.Aciklama);
            } 
        }

        private void cariHareketiSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Global.SirketTanımRest();

            var _manager = new ARPTransactionsManager(Global._oAuth2);
            //id : Inckeyno
            int inckey = 179;
            var result = _manager.DeleteInternalById(inckey);
        }
    } 
}